---
name: product-technology-research
description: "Deep-dive on external products, platforms, and technologies — scrape docs/blogs/GitHub via curl when web_search unavailable, synthesize findings, and map to our infrastructure."
version: 1.0.0
---

# Product & Technology Deep-Dive Research

Systematic approach for researching external products, platforms, or technologies when the user asks "what is X" or "can we build something like Y."

## When to Use

- User asks "What is [product/technology]?" — no web_search tool available
- User asks "Can we build something similar?" and needs architecture comparison
- User mentions a project/service/startup you're unfamiliar with
- Any time you need to evaluate external tech against our Pantheon infrastructure

## The Research Pipeline (4 Phases)

### Phase 1: Source Discovery

Hit multiple surfaces in parallel:

```
# Product homepage — primary positioning
curl -sL "https://product.io"

# Blog / announcements — detailed technical content
curl -sL "https://product.io/blog/introducing-foo/"

# GitHub — actual code, stars, README
curl -sL "https://api.github.com/repos/owner/repo"

# Docs — architecture, API reference
curl -sL "https://docs.product.io"
```

**Always scrape at least 3 sources** (homepage, blog, docs/GitHub) to cross-validate claims vs reality. A homepage hypes; a blog post explains trade-offs; a GitHub README tells you what's actually shipped.

### Phase 2: Information Extraction

Raw HTML is noisy. Extract meaning by:

- **Banner/hero sections** — the core positioning: "X is a [category] for [audience] that [value prop]"
- **Feature lists** — `<section>`, cards, grid layouts, comparison tables
- **Metrics/quotes** — numbers, benchmarks, customer results
- **Tags/pills** — what category they claim ("Knowledge Engine for agents", "serverless vector database")

For GitHub API responses, extract: `description`, `language`, `topics`, `stars`, `license`, `created_at`.

### Phase 3: Synthesis Structure

Always output in this order:

1. **One-sentence definition** — what it *is* (not what it *does*)
2. **Core idea/insight** — the key architectural insight or design philosophy
3. **Key components** — bullet list of major subsystems/features
4. **Performance/evidence** — benchmarks, metrics (use a simple key:value list or bullets; NO pipe tables for Telegram)
5. **Architecture comparison table** — map their components to ours (if relevant):
   - Their thing | Our equivalent | Gap
6. **Availability** — is it released? Early access? Open source?

### Phase 4: Feasibility Assessment (if user asks "can we build this?")

Structure as:
1. **What's easy** — we already have the pieces
2. **What's hard** — gaps we'd need to build
3. **What's not worth it** — proprietary data, network effects, infra scale
4. **Recommended approach** — build a lean version vs. wait/watch

## Pitfalls

- **Don't trust the homepage alone** — it's marketing. Cross-reference with docs and GitHub
- **Raw HTML is huge** — pipe to `head -200` or `grep` for early cuts. Don't dump 200k chars of JS framework garbage
- **404 pages are informative too** — a 404 on a blog post URL might mean the thing hasn't launched yet
- **Rate limiting** — GitHub API is 60 req/hr unauthenticated. Batch calls or use `?per_page=1` for minimal responses
- **No web_search tool** — accept this constraint and use direct curl + heuristic URL patterns
- **Page is client-side rendered (Next.js)** — you'll get JS not content. Look for `<script id="__NEXT_DATA__"` or `<!--$!-->` SSR bailout markers. If it's client-only, try the `/md/` alternate endpoint (Pinecone blog supports this pattern)
- **JSON within script tags** — many modern sites embed data as JSON in `<script type="application/json">` or `__NEXT_DATA__`. Extract with: `grep -oP '"description":"[^"]*"'` or similar patterns

## Verification

Before reporting, ask yourself:
- Did I find the actual *mechanism* (how it works) or just the *marketing* (what it claims)?
- Can I map at least one component to something in our stack?
- Do I know the licensing/pricing model?
- If it's open source, did I check the repo?
