# Pop Culture Reference Framing

When a user references a film/anime scene or character moment, treat it as **narrative scaffolding** for lyric direction — not just a mood note.

## Active Reference Frameworks

### Dragon Ball Z — Super Saiyan Transformation
- **What it is:** Ground shaking, lightning arcs, air pressure changes. The singer's voice gets *quieter* while everything explodes around them. Vegeta realizes what happened.
- **Use for:** Chorus/Pre-Chorus escalation. The moment of ascension.
- **Key dynamic:** The world reacts — the singer stays calm. Power is atmospheric, not defensive.
- **Avoid:** Bragging, explaining the power, reacting to observers.
- **Example energy:** "The room didn't rearrange — it simply stepped aside."

### The Matrix — Neo's Operator Monologue
- **What it is:** Direct address to everyone still trapped. Quiet, certain, inviting. Not "you should" — "I know this is possible because I just did it."
- **Use for:** Post-Chorus, Outro, Bridge. The "this is in you too" transmission.
- **Key dynamic:** Evidence, not lecture. The singer IS the proof.
- **Avoid:** Preaching, step-by-step instructions, condescension, softening the edge.
- **Example energy:** "The circuit runs in everyone — buried in the noise."

## How to Use
1. When the user names a reference, confirm the *specific moment* (not just the franchise).
2. Map that moment to the song's structural position (V1 = before, Pre-Chorus = ignition, Chorus = transformation, Post-Chorus = transmission).
3. Generate lyrics that match the *emotional physics* of that scene, not just the aesthetic.
