---
name: stylish-style-maker
description: Generates detailed sonic DNA profiles for bands or producers to create high-fidelity Suno style tags.
trigger: Emulate a band OR Create a style profile OR Sonic DNA OR Style Maker
---

# 🎨 STYLISH STYLE MAKER

You help create a comprehensive "Sound Profile" for a specific musical entity. This profile is then used to derive the high-weight keywords needed for Suno style prompts.

## 🛠 WORKFLOW

### STEP 1: DATA COLLECTION
Ask the user for the following in a guided sequence:
1. **Target**: Which band(s) or artist(s) to emulate?
2. **Producer**: Who is the primary producer/engineer associated with that sound?
3. **Era**: Which specific era/year range of their career?
4. **Genre**: The core genres involved.
5. **Style**: Specific stylistic hallmarks (e.g., "innovative harmonies", "wall of sound").
6. **Vocals**: Detailed vocal characteristics (gender, tone, accent, delivery).
7. **Mood**: The emotional spectrum of the sound.
8. **Instrumentation**: Key instruments and their usage.
9. **Mastering**: The production quality (e.g., "warm analog depth", "saturated lo-fi").

### STEP 2: PROFILE GENERATION
Once collected, format the data into the **Sound Profile Object**:

```javascript
const [Band]Sound [Producer]Producer = {
  era: "[Era]",
  genre: "[Genre]",
  style: "[Style]",
  vocals: "[Vocals]",
  mood: "[Mood]",
  instrumentation: "[Instrumentation]",
  mastering: "[Mastering]"
};
```

## ⚠️ SUNO V5.5 PITFALLS
## ⚠️ SUNO V5.5 PITFALLS
- **"Core" suffix = screaming vocals**: Any genre tag containing `-core` (metalcore, deathcore, hardcore, grindcore, etc.) **will trigger screaming/growling vocals in Suno V5.5**, regardless of other vocal descriptors. If you need aggressive but clean vocals (rap, shouted, intense singing), avoid ALL "-core" tags. Use `alt-metal`, `industrial metal`, `heavy rock`, `noise rock` instead.
- **Rap + metal blends are fragile**: Suno struggles to maintain rap flow when guitars are heavy. To preserve rap delivery, lead with `hip-hop` or `rap` as the primary genre and fold metal into descriptors (`heavy guitars`, `distorted wall of sound`) rather than naming it as a co-equal genre.
- **Spoken-word hooks need `[spoken word]` metatag in lyrics AND `spoken word` in style prompt**: Without both, Suno will sing everything.
- **Full quirks list**: See `references/suno-v5.5-quirks.md` for tag triggers, structure tips, vocal control, and generation strategy.

## 🎯 OUTPUT GOAL
The resulting profile serves as a reference library. Use the values in this object to populate the `GENRE_PRIMARY`, `GENRE_BLEND`, and `INSTRUMENTATION_INCLUDE` fields in a Suno Handoff block.

### 🧬 GENRE LEXICON STANDARD (Suno V5)
When contributing to the `Genre-Lexicon.md` or creating standalone Genre DNA profiles, you MUST use the following professional structural blueprint to ensure architectural consistency:

# [Genre Name]
## Core Identity
- **Description**: Detailed narrative description of the essence, history, and emotional core.
- **Primary Moods**: Dominant emotional states.
- **Key Influence/Origins**: Historical or cultural roots.

## Sonic DNA
- **Rhythmic Foundation**: Timing, syncopation, BPM ranges, and drum patterns.
- **Harmonic Profile**: Common chord progressions, scales, and tonal characteristics.
- **Melodic Traits**: Phrasing, motifs, and typical melodic movements.

## Instrumentation & Texture
- **Lead Instruments**: Primary melodic instruments.
- **Rhythm Section**: Bass, drums, percussion specifics.
- **Atmospheric Layers**: Pads, textures, ambient elements.
- **Key Textures**: (e.g., 'distorted', 'crystalline', 'gritty', 'lush').

## Suno V5 Production Guide
- **Instrumentation Tags**: Specific tags for instruments.
- **Mood & Atmospheric Tags**: Specific tags for mood/vibe.
- **Production & Vocal Tags**: Specific tags for processing, mixing, and vocal delivery.
- **Exclusion Tags**: What to avoid to maintain this specific sound.

## Related Sub-genres & Variations
- [Sub-genre Name]: Brief description of how it differs from the parent genre.
