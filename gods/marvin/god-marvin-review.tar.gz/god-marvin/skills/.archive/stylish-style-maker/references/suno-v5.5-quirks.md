# Suno V5.5 Known Quirks

## Tag Triggers
- **"-core" suffix → screaming vocals**: metalcore, deathcore, hardcore, grindcore, etc. all trigger harsh vocals automatically. No override exists. Use alt-metal, industrial metal, heavy rock, noise rock for aggressive-but-clean.
- **"Rap" + heavy guitars → rap gets buried**: Lead with hip-hop/rap as primary genre, describe metal via instrumentation tags rather than genre tags.
- **Spoken word**: Requires BOTH `[spoken word]` in lyrics metatag AND `spoken word` in style prompt. One without the other fails.

## Structure
- **Hook/Chorus length**: Suno tends to repeat the last section if it's short. Keep hooks to 1-3 lines.
- **Instrumental tags**: `[Instrumental]` works but `[no vocals]` is more reliable.
- **Silence**: `[silence]` or `[dead silence]` sometimes works; `[break]` is more consistent for short pauses.

## Vocal Control
- **Autotune**: `autotune` tag adds subtle pitch correction. `heavy autotune` or `T-Pain style` pushes it further.
- **Male/female vocal**: Explicitly state gender. Suno defaults to female for many genres.
- **Layered vocals**: `layered vocals` or `choir` creates harmonies but can muddy the lead.

## Generation Strategy
- Generate 4-6 variations per prompt — the variance is high.
- If the verse vocal style is wrong but chorus is right, the genre prompt is too broad. Narrow the primary genre.
- If the vocal delivery is right but instrumentation is wrong, the problem is in the instrumentation tags, not the genre.
