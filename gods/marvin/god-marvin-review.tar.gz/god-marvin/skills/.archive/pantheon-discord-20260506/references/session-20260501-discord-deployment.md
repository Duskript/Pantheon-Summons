# Session Log: Discord Multi-God Deployment — May 1, 2026

## Problem
Konan noticed Hephaestus was responding in #the-herald (Hermes's channel). Both gods shared the same Discord server and both gateways were receiving all messages.

## Root Cause
Hephaestus's `config.yaml` had `allowed_channels: '1499854046138204170'` (The Forge) set, but this only filtered **outbound** responses, not inbound message receipt. Since `require_mention: true` was NOT set (at the time), Hephaestus's gateway still picked up messages from the herald channel and responded to them.

## Fix Applied

### Hephaestus — Lock to The Forge, free response
```
config.yaml change:
  require_mention: true  →  false  (free response in his channel)
  allowed_channels: '1499854046138204170'  (already set — kept)

.env state (restored after accidental overwrite):
  DISCORD_BOT_TOKEN=MTQ5OTg1NzQyMjc1NDI1MDg0Mg.GYS53A.wFDpzY4rUkSPlHjb9AMIL4zH-NcwIwntd8rp8o
  DISCORD_HOME_CHANNEL=1499851385704022088
  (Telegram removed — no longer needed)
```

### Apollo — New Discord deploy to Muse's Mount
```
config.yaml:
  discord:
    require_mention: false
    allowed_channels: '1499965318599016508'   # #muses-mount
    auto_thread: false
    reactions: true

.env:
  DISCORD_BOT_TOKEN=MTQ5OTg1OTQwNDM1MzMxMDk4Mg.Gl3EKi.ks8B9M-PwlmX31SUo_IYKa2VmlBixWqDTOfG9A
  DISCORD_HOME_CHANNEL=1499965318599016508
  TELEGRAM_BOT_TOKEN=8442957829:AAF2UHpHRk3x6Cme8ZqShDocMFhzZxorWlk   (kept — Apollo still on Telegram)
  GATEWAY_ALLOW_ALL_USERS=true

systemd:
  Enabled on boot: systemctl --user enable hermes-gateway-apollo
```

## Channel ID Reference (Pantheon Server)
| Channel | ID |
|---------|-----|
| #the-herald | 1499868497180889158 |
| The Forge | 1499854046138204170 |
| #general | 1499851385704022088 |
| #muses-mount | 1499965318599016508 |

## Lessons
- `allowed_channels` is an outbound filter only — gods still receive inbound from everywhere
- `require_mention: true` is the real isolation mechanism for shared servers
- Gateway restart often hangs on the first attempt due to MCP child processes — use `kill -9` + `reset-failed` as fallback
- Gateway logs are canonical for bot status (Discord UI showing offline is unreliable)
