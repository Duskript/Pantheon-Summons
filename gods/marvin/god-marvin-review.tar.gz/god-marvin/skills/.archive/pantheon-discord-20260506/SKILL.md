---
name: pantheon-discord
description: "Deploy multiple Pantheon gods on Discord, each with isolated channel territory, profile config, and per-god behavior settings."
version: 1.0.0
---

# Pantheon Discord — Multi-God Deployment

Deploying multiple Pantheon gods (Hermes, Hephaestus, Apollo, etc.) on the **same Discord server**, each with their own channel and independent behavior.

This covers the full setup: Discord bot tokens per profile, channel-ID locks, mention vs free-response behavior, and cross-god isolation on a shared server.

## Architecture

```
Pantheon Discord Server
├── #the-herald       ← Hermes (free response, home channel)
├── #forge-or-name    ← Hephaestus (free response, own channel)
├── #muses-mount      ← Apollo (free response, own channel)
└── #general          ← (unused by gods / or specific god)
```

Each god runs as a **separate Hermes profile** with its own:
- **Discord bot token** (from discord.com/developers/applications)
- **`config.yaml`** with channel restrictions and behavior
- **`.env`** with platform tokens
- **`hermes-gateway-<profile>.service`** systemd unit

## Per-God Config

Each profile's `config.yaml` needs a `discord:` section:

```yaml
discord:
  require_mention: false       # true = respond only when @mentioned; false = respond freely in allowed channel
  free_response_channels: ''   # override: channels where god responds without @mention (overrides require_mention)
  allowed_channels: 'CHANNEL_ID_AS_STRING'  # ONLY channel(s) the god will respond in
  auto_thread: false
  reactions: true
  channel_prompts: {}
  server_actions: ''
```

### Behavior Matrix

| require_mention | allowed_channels set | Behavior |
|:---------------:|:-------------------:|----------|
| `false` | `'CHANNEL_ID'` | Responds freely in that channel only |
| `true` | `'CHANNEL_ID'` | Responds only when @mentioned, only in that channel |
| `false` | `''` (empty) | Responds freely in ALL channels it can see (⚠️ messy on shared server) |
| `true` | `''` (empty) | Responds only when @mentioned, in any channel |

### Per-Profile `.env`

```env
# Discord
DISCORD_BOT_TOKEN=MTQ5OTg...yourTokenHere
DISCORD_HOME_CHANNEL=1499868497180889158

# Other platforms (optional — gods can be multi-platform)
TELEGRAM_BOT_TOKEN=...
GATEWAY_ALLOW_ALL_USERS=true
```

### Systemd Service Naming

Each profile gets its own gateway service:

```
hermes-gateway.service              # default/main profile
hermes-gateway-hephaestus.service   # hephaestus profile
hermes-gateway-apollo.service       # apollo profile
```

## Setup Steps

1. **Create Discord bot** at https://discord.com/developers/applications
   - Enable **Message Content Intent** in Bot → Privileged Gateway Intents
   - Copy the bot token
   - Invite bot to server with `bot` + `applications.commands` scopes

2. **Create or reuse a Hermes profile**:
   ```bash
   hermes profile create my-god-name
   ```

3. **Add Discord config** to the profile's `config.yaml`

4. **Add Discord token** to the profile's `.env`

5. **Restart the gateway**:
   ```bash
   systemctl --user restart hermes-gateway-my-god-name
   ```

6. **Verify**:
   ```bash
   cat ~/.hermes/profiles/<profile>/logs/gateway.log | grep "discord"
   ```
   Look for: `✓ discord connected` and `Connected as BotName#1234`

## Pitfalls

### `allowed_channels` is NOT a hard block
The setting filters **outbound** (which channels the bot responds in) but does NOT prevent the bot from **receiving** inbound messages from other channels. Gods can still see messages across the server — they just won't reply. This matters when debugging "why is god X seeing what I said in god Y's channel."

- **Fix:** Set `require_mention: true` on gods that shouldn't listen to anything outside their channel, OR remove the bot from channels it doesn't need via Discord server settings.

### Gateway restart can hang
If the gateway has child processes (MCP server, etc.), `systemctl restart` may time out waiting for the process tree to stop.

- **Force kill:** `kill -9 $(pgrep -f "hermes.*<profile>.*gateway")` then `systemctl --user reset-failed hermes-gateway-<profile>` then `systemctl --user start hermes-gateway-<profile>`

### `.env` file is fragile
One bad `write_file` can nuke a bot token. **Always read the existing `.env` before modifying it**, or keep tokens backed up. Restoring from session search works but is slow.

### Discord UI shows bots offline
Even when the gateway logs confirm `✓ discord connected` and messages flow fine, Discord's sidebar may show the bot as offline/grey. This is a Discord UI quirk, not a real issue.

### Message Content Intent required
Without this intent enabled in the Discord Developer Portal, the bot can see messages in its DMs but NOT in server channels. Gateway will throw `PrivilegedIntentsRequired` and fail to connect.

## Quick Reference: Common Commands

```bash
# Check all gateway services
systemctl --user list-units 'hermes-gateway*' --no-pager

# Check a specific gateway
systemctl --user status hermes-gateway-apollo --no-pager

# View gateway logs
cat ~/.hermes/profiles/<profile>/logs/gateway.log | grep "discord" | tail -10

# Or via journalctl
journalctl --user -u hermes-gateway-<profile> --no-pager | tail -30

# Restart (may hang — see pitfall above)
systemctl --user restart hermes-gateway-<profile>

# Enable on boot
systemctl --user enable hermes-gateway-<profile>

# Force restart a stuck gateway
kill -9 $(pgrep -f "hermes.*<profile>.*gateway")
systemctl --user reset-failed hermes-gateway-<profile>
systemctl --user start hermes-gateway-<profile>
```
