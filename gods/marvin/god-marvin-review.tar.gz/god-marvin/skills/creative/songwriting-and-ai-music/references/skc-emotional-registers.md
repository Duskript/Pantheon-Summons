# SKC Emotional Register: Intimacy vs Power

## Two Modes

SKC material has so far explored two distinct emotional registers. Future songs should be aware of which lane they're in:

### Power/Surge Mode
- **Existing material**: "God Mode"
- **Theme**: Suppression → detonation → omniscient power → universal transmission
- **Energy**: Desperate → Detonated → Omniscient
- **Sonic**: Explosive, heavy, metal-gaze × rap, circuit-snap moments
- **Pop culture refs**: DBZ Super Saiyan calm ascension, Neo Matrix monologue

### Intimacy/Love Mode
- **Existing material**: "And the World Fell Away" (in progress)
- **Theme**: Scattered noise → distilled moment → gravitational pull toward one person
- **Energy**: Scattered → Focused → Warm → Expansive
- **Sonic**: Still heavy (fuzz guitars, 808), but serving intimacy not power
- **Key insight**: The world falling away isn't loss or destruction — it's *perspective*. Everything else becomes irrelevant because what's in front of you is the only thing that's real.
- **Avoid**: Don't make intimacy sound like a power trip. "And I didn't miss it" works because it's about indifference to noise, not triumph over it.

## Cross-Pollination
Both modes can coexist in the same song. But the **emotional center** should be clear — a love song shouldn't accidentally read like a battle cry, and vice versa.

## Pitfall
The heavy SKC sound (fuzz guitars, 808 sub, wall of sound) can easily push intimate lyrics toward aggression. Solution: keep the instrumentation warm and slow-burn, not sharp and explosive. The contrast between heavy sound and tender lyrics is the tension, not a mistake to fix.
