---
name: hermes-agent
description: "Configure, extend, or contribute to Hermes Agent."
version: 2.1.0
author: Hermes Agent + Teknium
license: MIT
metadata:
  hermes:
    tags: [hermes, setup, configuration, multi-agent, spawning, cli, gateway, development]
    homepage: https://github.com/NousResearch/hermes-agent
    related_skills: [claude-code, codex, opencode]
---

# Hermes Agent

Hermes Agent is an open-source AI agent framework by Nous Research that runs in your terminal, messaging platforms, and IDEs. It belongs to the same category as Claude Code (Anthropic), Codex (OpenAI), and OpenClaw — autonomous coding and task-execution agents that use tool calling to interact with your system. Hermes works with any LLM provider (OpenRouter, Anthropic, OpenAI, DeepSeek, local models, and 15+ others) and runs on Linux, macOS, and WSL.

What makes Hermes different:

- **Self-improving through skills** — Hermes learns from experience by saving reusable procedures as skills. When it solves a complex problem, discovers a workflow, or gets corrected, it can persist that knowledge as a skill document that loads into future sessions. Skills accumulate over time, making the agent better at your specific tasks and environment.
- **Persistent memory across sessions** — remembers who you are, your preferences, environment details, and lessons learned. Pluggable memory backends (built-in, Honcho, Mem0, and more) let you choose how memory works.
- **Multi-platform gateway** — the same agent runs on Telegram, Discord, Slack, WhatsApp, Signal, Matrix, Email, and 10+ other platforms with full tool access, not just chat.
- **Provider-agnostic** — swap models and providers mid-workflow without changing anything else. Credential pools rotate across multiple API keys automatically.
- **Profiles** — run multiple independent Hermes instances with isolated configs, sessions, skills, and memory.
- **Extensible** — plugins, MCP servers, custom tools, webhook triggers, cron scheduling, and the full Python ecosystem.

People use Hermes for software development, research, system administration, data analysis, content creation, home automation, and anything else that benefits from an AI agent with persistent context and full system access.

**This skill helps you work with Hermes Agent effectively** — setting it up, configuring features, spawning additional agent instances, troubleshooting issues, finding the right commands and settings, and understanding how the system works when you need to extend or contribute to it.

**Docs:** https://hermes-agent.nousresearch.com/docs/

## Quick Start

```bash
# Install
curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash

# Interactive chat (default)
hermes

# Single query
hermes chat -q "What is the capital of France?"

# Setup wizard
hermes setup

# Change model/provider
hermes model

# Check health
hermes doctor
```

---

## CLI Reference

### Global Flags

```
hermes [flags] [command]

  --version, -V             Show version
  --resume, -r SESSION      Resume session by ID or title
  --continue, -c [NAME]     Resume by name, or most recent session
  --worktree, -w            Isolated git worktree mode (parallel agents)
  --skills, -s SKILL        Preload skills (comma-separate or repeat)
  --profile, -p NAME        Use a named profile
  --yolo                    Skip dangerous command approval
  --pass-session-id         Include session ID in system prompt
```

No subcommand defaults to `chat`.

### Chat

```
hermes chat [flags]
  -q, --query TEXT          Single query, non-interactive
  -m, --model MODEL         Model (e.g. anthropic/claude-sonnet-4)
  -t, --toolsets LIST       Comma-separated toolsets
  --provider PROVIDER       Force provider (openrouter, anthropic, nous, etc.)
  -v, --verbose             Verbose output
  -Q, --quiet               Suppress banner, spinner, tool previews
  --checkpoints             Enable filesystem checkpoints (/rollback)
  --source TAG              Session source tag (default: cli)
```

### Configuration

```
hermes setup [section]      Interactive wizard (model|terminal|gateway|tools|agent)
hermes model                Interactive model/provider picker
hermes config               View current config
hermes config edit          Open config.yaml in $EDITOR
hermes config set KEY VAL   Set a config value
hermes config path          Print config.yaml path
hermes config env-path      Print .env path
hermes config check         Check for missing/outdated config
hermes config migrate       Update config with new options
hermes login [--provider P] OAuth login (nous, openai-codex)
hermes logout               Clear stored auth
hermes doctor [--fix]       Check dependencies and config
hermes status [--all]       Show component status
```

### Tools & Skills

```
hermes tools                Interactive tool enable/disable (curses UI)
hermes tools list           Show all tools and status
hermes tools enable NAME    Enable a toolset
hermes tools disable NAME   Disable a toolset

hermes skills list          List installed skills
hermes skills search QUERY  Search the skills hub
hermes skills install ID    Install a skill (ID can be a hub identifier OR a direct https://…/SKILL.md URL; pass --name to override when frontmatter has no name)
hermes skills inspect ID    Preview without installing
hermes skills config        Enable/disable skills per platform
hermes skills check         Check for updates
hermes skills update        Update outdated skills
hermes skills uninstall N   Remove a hub skill
hermes skills publish PATH  Publish to registry
hermes skills browse        Browse all available skills
hermes skills tap add REPO  Add a GitHub repo as skill source
```

### MCP Servers

```
hermes mcp serve            Run Hermes as an MCP server
hermes mcp add NAME         Add an MCP server (--url or --command)
hermes mcp remove NAME      Remove an MCP server
hermes mcp list             List configured servers
hermes mcp test NAME        Test connection
hermes mcp configure NAME   Toggle tool selection
```

### Gateway (Messaging Platforms)

```
hermes gateway run          Start gateway foreground
hermes gateway install      Install as background service
hermes gateway start/stop   Control the service
hermes gateway restart      Restart the service
hermes gateway status       Check status
hermes gateway setup        Configure platforms
```

For a full walkthrough of creating a project-specific profile with git setup, see: `references/project-profiles.md`

For running multiple Telegram bots simultaneously via separate profiles (multi-bot gateway), see: `references/multiple-telegram-bots.md`

Supported platforms: Telegram, Discord, Slack, WhatsApp, Signal, Email, SMS, Matrix, Mattermost, Home Assistant, DingTalk, Feishu, WeCom, BlueBubbles (iMessage), Weixin (WeChat), API Server, Webhooks. Open WebUI connects via the API Server adapter.

Platform docs: https://hermes-agent.nousresearch.com/docs/user-guide/messaging/

### Sessions

```
hermes sessions list        List recent sessions
hermes sessions browse      Interactive picker
hermes sessions export OUT  Export to JSONL
hermes sessions rename ID T Rename a session
hermes sessions delete ID   Delete a session
hermes sessions prune       Clean up old sessions (--older-than N days)
hermes sessions stats       Session store statistics
```

### Cron Jobs

```
hermes cron list            List jobs (--all for disabled)
hermes cron create SCHED    Create: '30m', 'every 2h', '0 9 * * *'
hermes cron edit ID         Edit schedule, prompt, delivery
hermes cron pause/resume ID Control job state
hermes cron run ID          Trigger on next tick
hermes cron remove ID       Delete a job
hermes cron status          Scheduler status
```

### Cron: Script-Injected Context (Multi-Source Briefings)

For jobs that need to collect data from multiple files or systems, use the `script` parameter. The script runs before the prompt is sent, and its stdout is **prepended to the prompt** — the agent receives both the script output AND the prompt as context.

#### Basic Pattern: Bash Script Collecting Local Files

```bash
# Create a data-collection script
cat > ~/.hermes/scripts/morning-briefing.sh << 'EOF'
#!/bin/bash
echo "=== HADES_REPORT ==="
cat /home/konan/athenaeum/reports/hades-$(date +%Y-%m-%d).md
echo ""
echo "=== PROJECT_IDEAS ==="
cat /home/konan/pantheon/project-ideas.md
EOF
chmod +x ~/.hermes/scripts/morning-briefing.sh

# Reference it in the cron creation (via cronjob tool, not CLI):
cronjob(action="create", name="Morning Briefing", schedule="5 7 * * *",
    script="morning-briefing.sh", deliver="origin",
    prompt="Compose a briefing from the data below...")
```

#### Advanced Pattern: Bash Wrapper → Python Sub-Scripts (API/File Sources)

When data comes from different sources (local files, REST APIs, RSS feeds, GitHub), write **one Python script per data source** that outputs a labeled section, then chain them in your bash wrapper:

```bash
#!/bin/bash
# ~/.hermes/scripts/morning-briefing.sh — Wrapper that chains multiple collectors

echo "=== HADES_REPORT ==="
cat /home/konan/athenaeum/Codex-Pantheon/reports/hades-$(date +%Y-%m-%d).md

echo ""
echo "=== OVERNIGHT_INBOX ==="
python3 /home/konan/.hermes/scripts/overnight-inbox.py

echo ""
echo "=== HERMES_NEWS ==="
python3 /home/konan/.hermes/scripts/hermes-news.py
```

Example Python sub-script patterns:

**File-based data collector** (`overnight-inbox.py`): Scans a directory of JSON message files (e.g. `~/pantheon/gods/messages/*/msg_*.json`), filters by timestamp, and outputs labeled entries. Use `=== SECTION_NAME ===` markers so the prompt can reference sections by name.

**API-based data collector** (`hermes-news.py`): Fetches from external APIs (Google News RSS, GitHub search) using `urllib.request` with a `User-Agent` header. Outputs structured labeled entries:
```
print("=== TOP_ARTICLES ===")
for a in articles:
    print(f"TITLE:{a['title']}")
    print(f"LINK:{a['link']}")
    ...
```

#### Section-Label Convention

Use `=== SECTION_NAME ===` as a consistent delimiter in script output. This lets the prompting cron prompt cleanly reference each section without parsing complexity:

```python
print("=== SECTION_A ===")
# ... data ...
print("=== SECTION_B ===")
# ... data ...
```

In the prompt: *"The data below is labeled with [=== SECTION_NAME ===] markers. Include Section A first, then Section B."*

#### Prompt Design for Multi-Source Data

The prompt should NOT repeat what the script already collects — the script output is already in the model's context window. The prompt should focus on **how to compose/present** that data (tone, format, sections, which sections to include/exclude).

Good prompt pattern:
```
Compose an energetic morning briefing. Include:

1. **Section A** — summarize key findings from the data
2. **Section B** — list items with [emoji] per status  
3. **Section C** — top 4 latest items with clickable links
4. **Section D** — what's hot, what's next

Only include sections that have actual content — if Section B says "SILENT", skip it.

The data is below as labeled sections.
```

#### Pitfalls
- The script output is prepended verbatim — don't put formatting noise in the script
- Scripts run in `~/.hermes/scripts/` dir — use absolute paths or paths relative to `~`
- Always `chmod +x` the shell wrapper script (Python scripts don't need it if run via `python3 …`)
- Python scripts calling external APIs need `User-Agent` headers or they get blocked
- Keep Python scripts self-contained (stdlib only) — no dependencies to install
- Use `deliver: "origin"` to send results back to the user's chat platform (Telegram, Discord, etc.)
- For scripts under `~/.hermes/scripts/`, the working directory is the Hermes home, not the script's dir — use absolute paths for file reads

For full worked examples and reusable code templates: `references/multi-source-cron-briefings.md`

### Webhooks

```
hermes webhook subscribe N  Create route at /webhooks/<name>
hermes webhook list         List subscriptions
hermes webhook remove NAME  Remove a subscription
hermes webhook test NAME    Send a test POST
```

### Profiles

```
hermes profile list         List all profiles
hermes profile create NAME  Create (--clone, --clone-all, --clone-from)
hermes profile use NAME     Set sticky default
hermes profile delete NAME  Delete a profile
hermes profile show NAME    Show details
hermes profile alias NAME   Manage wrapper scripts
hermes profile rename A B   Rename a profile
hermes profile export NAME  Export to tar.gz
hermes profile import FILE  Import from archive
```

### Credential Pools

```
hermes auth add             Interactive credential wizard
hermes auth list [PROVIDER] List pooled credentials
hermes auth remove P INDEX  Remove by provider + index
hermes auth reset PROVIDER  Clear exhaustion status
```

### Dashboard (Web UI)

The Hermes Agent web dashboard is a browser-based UI for managing config, API keys, and sessions. Runs as a local FastAPI server on port 9119.

```bash
# Launch the dashboard (opens port 9119 on 127.0.0.1)
hermes dashboard

# With in-browser chat tab (embedded --tui via PTY/WebSocket)
hermes dashboard --tui

# Custom port/host
hermes dashboard --port 9119 --host 127.0.0.1

# Stop all running dashboard processes
hermes dashboard --stop

# Check if dashboard is running
hermes dashboard --status
```

The dashboard serves the built web UI from `~/.hermes/hermes-agent/hermes_cli/web_dist/`.

> **Pitfall:** "Web UI" is ambiguous — there are FOUR different things the user could mean. Check before assuming:
> 1. **Hermes Dashboard** (port 9119) — config/keys/sessions management UI. Served by `hermes dashboard`. Source: `~/.hermes/hermes-agent/web/` (Vite + React SPA).
> 2. **Hermes Workspace** (outsourc-e/hermes-workspace) — standalone chat + terminal + multi-agent workspace. Vite + React + Electron. ~1.5GB, cloned at `~/hermes-workspace/`.
> 3. **hermes-webui** (nesquena/hermes-webui) — simpler Python-based chat frontend. Static JS + Python server. ~32MB, cloned at `~/hermes-webui/`.
> 4. **LiteLLM admin UI** (port 4000) — model routing/admin proxy UI.
>
> Konan is standardizing on a fork of Hermes Workspace as the only frontend path — Pantheon UI, AionUI, and Kitchen are retired. The fork lives on Google Drive, not GitHub. When he says "web UI," check session context before assuming which one.

#### Dashboard Pitfalls

- **`--host 0.0.0.0` is refused by default** — The dashboard will refuse to bind to anything other than 127.0.0.1 with the error: `Refusing to bind to 0.0.0.0 — the dashboard exposes API keys and config without robust authentication. Use --insecure to override`. This is a security gate, not a bug. If the user wants to access from another machine (e.g. via Tailscale), add `--insecure`: `hermes dashboard --host 0.0.0.0 --port 9119 --insecure`. Only do this on trusted networks.
- **`--tui` crashes in background mode** — The `--tui` flag spawns a PTY for an embedded chat tab, but running the dashboard in the background (e.g. via `&`, or as a background terminal call) causes `tcsetattr: Inappropriate ioctl for device` crashes. Drop `--tui` when running the dashboard as a background service. Without `--tui`, the web UI works fine — you just lose the in-browser chat.
- **`--status` shows PIDs, not HTTP health** — `hermes dashboard --status` lists running dashboard processes, but a listed PID may still have the HTTP server in a crash loop or not yet listening. Always verify with `curl -s http://127.0.0.1:PORT/` or `ss -tlnp | grep PORT` to confirm the server is actually serving before telling the user it's up.
- **Killing old processes before restart** — Use `hermes dashboard --stop` to kill all running dashboard processes cleanly before restarting with different flags. Background processes started outside of `hermes dashboard` (e.g. via terminal tool) need manual `kill` or `pkill -f dashboard`.
- **Dashboard doesn't hot-reload env vars** — Adding or updating env vars in `~/.hermes/.env` (e.g. uncommenting `OPENCODE_GO_API_KEY`) won't be picked up by a running dashboard. You must stop and restart: `hermes dashboard --stop && hermes dashboard --host ... --port ...`. A `/restart` from inside the session also works.
- **Dashboard provider list mirrors `~/.hermes/.env` (not auth.json/credential pools)** — If a provider isn't showing up in the dashboard UI, check the `.env` file first. Hermes discovers providers by scanning env vars like `OPENCODE_GO_API_KEY`, `OPENCODE_ZEN_API_KEY`, etc. If the key is commented out (`# VAR=`), the provider won't appear even if the key exists in a systemd service file or LiteLLM config. This is a common disconnect when LiteLLM and Hermes share the machine but have independent env setups.

#### Web UI Source & Development

The dashboard's web UI is a **Vite + React 19 + TypeScript** SPA — source at `~/.hermes/hermes-agent/web/`. Uses Tailwind CSS v4, react-router-dom v7, and the `@nous-research/ui` design system.

```
web/src/
├── App.tsx            # Main layout, sidebar, routing (built-in pages + plugin insertion)
├── pages/             # One component per route: Sessions, Config, Models, Chat, Cron, etc.
├── components/        # Shared UI components (ui/ subdirectory for primitives)
├── plugins/           # Plugin registry (manifests, page overrides, Slot system)
├── themes/            # Theme system (presets like "midnight", context provider)
├── i18n/              # Internationalization
├── lib/               # API client (gatewayClient.ts, api.ts), utilities
├── contexts/          # React contexts (PageHeaderProvider, useSystemActions)
└── hooks/             # React hooks

web/vite.config.ts     # Vite config — builds to ../hermes_cli/web_dist/
```

**Modifying the UI:**
1. Edit source files in `web/src/`
2. Build with `npm run build` (run from `web/` directory)
3. Restart the dashboard: `hermes dashboard --stop && hermes dashboard`
4. No server restart needed for frontend-only changes — rebuilt static files are served immediately

**Plugin system** loads manifests from `/api/dashboard/plugins`:
- Plugins can add new pages with `tab.path`, `tab.label`, and position hints (`after:`, `before:`)
- Plugins can override built-in pages via `tab.override`
- PluginSlot system allows injecting into header, banner, pre-main, post-main, overlay
- The chat page waits for plugin manifest load before mounting (prevents mid-session teardown)

**Personality management in the UI:** The web dashboard has **no personality editor**. To change the active personality:
```bash
hermes config set display.personality ''     # clear override (use system prompt's default persona)
hermes config set display.personality NAME   # set to a named personality
```
Or the `/personality [name]` slash command in-session. Named personalities are defined under `agent.personalities` in `config.yaml` (built-ins: helpful, concise, hype, kawaii, noir, philosopher, pirate, etc.).

**⚠️ Dependency note:** `@nous-research/ui` (v^0.10.0) is a private/internal npm package — already in `node_modules/` from existing install, but adding new components from it may need version alignment or additional imports. If you need fresh deps, check `web/package-lock.json` for what's already available.

#### Project Layout (Dashboard Source)

The `web/` directory is not listed in the main project layout below — add it mentally:
```
hermes-agent/
├── ...
├── web/                  # Dashboard SPA (Vite + React 19 + TypeScript)
├── hermes_cli/web_dist/  # Built dashboard output (committed to repo)
├── ...
```

### Other

```
hermes insights [--days N]  Usage analytics
hermes update               Update to latest version
hermes pairing list/approve/revoke  DM authorization
hermes plugins list/install/remove  Plugin management
hermes honcho setup/status  Honcho memory integration (requires honcho plugin)
hermes memory setup/status/off  Memory provider config
hermes completion bash|zsh  Shell completions
hermes acp                  ACP server (IDE integration)
hermes claw migrate         Migrate from OpenClaw
hermes uninstall            Uninstall Hermes
```

---

## Slash Commands (In-Session)

Type these during an interactive chat session.

### Session Control
```
/new (/reset)        Fresh session
/clear               Clear screen + new session (CLI)
/retry               Resend last message
/undo                Remove last exchange
/title [name]        Name the session
/compress            Manually compress context
/stop                Kill background processes
/rollback [N]        Restore filesystem checkpoint
/background <prompt> Run prompt in background
/queue <prompt>      Queue for next turn
/resume [name]       Resume a named session
```

### Configuration
```
/config              Show config (CLI)
/model [name]        Show or change model
/personality [name]  Set personality
/reasoning [level]   Set reasoning (none|minimal|low|medium|high|xhigh|show|hide)
/verbose             Cycle: off → new → all → verbose
/voice [on|off|tts]  Voice mode
/yolo                Toggle approval bypass
/skin [name]         Change theme (CLI)
/statusbar           Toggle status bar (CLI)
```

### Tools & Skills
```
/tools               Manage tools (CLI)
/toolsets            List toolsets (CLI)
/skills              Search/install skills (CLI)
/skill <name>        Load a skill into session
/cron                Manage cron jobs (CLI)
/reload-mcp          Reload MCP servers
/plugins             List plugins (CLI)
```

### Gateway
```
/approve             Approve a pending command (gateway)
/deny                Deny a pending command (gateway)
/restart             Restart gateway (gateway)
/sethome             Set current chat as home channel (gateway)
/update              Update Hermes to latest (gateway)
/platforms (/gateway) Show platform connection status (gateway)
```

### Utility
```
/branch (/fork)      Branch the current session
/fast                Toggle priority/fast processing
/browser             Open CDP browser connection
/history             Show conversation history (CLI)
/save                Save conversation to file (CLI)
/paste               Attach clipboard image (CLI)
/image               Attach local image file (CLI)
```

### Info
```
/help                Show commands
/commands [page]     Browse all commands (gateway)
/usage               Token usage
/insights [days]     Usage analytics
/status              Session info (gateway)
/profile             Active profile info
```

### Exit
```
/quit (/exit, /q)    Exit CLI
```

---

## Key Paths & Config

```
~/.hermes/config.yaml       Main configuration
~/.hermes/.env              API keys and secrets
$HERMES_HOME/skills/        Installed skills
~/.hermes/sessions/         Session transcripts
~/.hermes/logs/             Gateway and error logs
~/.hermes/auth.json         OAuth tokens and credential pools
~/.hermes/hermes-agent/     Source code (if git-installed)
```

Profiles use `~/.hermes/profiles/<name>/` with the same layout.

### Config Sections

Edit with `hermes config edit` or `hermes config set section.key value`.

| Section | Key options |
|---------|-------------|
| `model` | `default`, `provider`, `base_url`, `api_key`, `context_length` |
| `agent` | `max_turns` (90), `tool_use_enforcement` |
| `terminal` | `backend` (local/docker/ssh/modal), `cwd`, `timeout` (180) |
| `compression` | `enabled`, `threshold` (0.50), `target_ratio` (0.20) |
| `display` | `skin`, `personality`, `tool_progress`, `show_reasoning`, `show_cost` |
| `stt` | `enabled`, `provider` (local/groq/openai/mistral) |
| `tts` | `provider` (edge/elevenlabs/openai/minimax/mistral/neutts) |
| `memory` | `memory_enabled`, `user_profile_enabled`, `provider` |
| `security` | `tirith_enabled`, `website_blocklist` |
| `delegation` | `model`, `provider`, `base_url`, `api_key`, `max_iterations` (50), `reasoning_effort` |
| `checkpoints` | `enabled`, `max_snapshots` (50) |

Full config reference: https://hermes-agent.nousresearch.com/docs/user-guide/configuration

### Personality & Persona System

Hermes has a multi-layered personality system that controls tone, behavior, and identity:

1. **PERSONA.md** (`~/.hermes/PERSONA.md`) — The base system prompt. Defines the agent's core identity and capabilities. Does not exist by default; the built-in "Hermes Agent" persona serves as the default when no file is present.
2. **Active personality** (`display.personality` in config.yaml) — An overlay prompt injected on top of PERSONA.md. Swaps tone/behavior without changing the core identity. Set to `''` (empty string) to use only the base persona.
3. **Named personalities** (defined under `agent.personalities` in config.yaml) — Prompt templates referenced by `display.personality`. Built-in set: `catgirl`, `concise`, `creative`, `helpful`, `hype`, `kawaii`, `noir`, `philosopher`, `pirate`, `shakespeare`, `surfer`, `teacher`, `technical`, `uwu`.

```bash
# Set active personality
hermes config set display.personality kawaii     # Activate a named personality
hermes config set display.personality ''          # Clear — only PERSONA.md base applies

# Create a custom personality (any name works)
hermes config set agent.personalities.myhero 'You are a heroic assistant who speaks in epic metaphors.'
hermes config set display.personality myhero
```

#### In-Session Personality

The `/personality [name]` slash command changes personality for the current session only (not persistent across restarts). Use `config set` for permanent changes.

#### Web UI

The dashboard has **no personality editor**. There is no field for `display.personality` or a PERSONA.md editor in the web dashboard. Changes must be made via CLI commands above or by editing `config.yaml` directly.

#### Pitfalls
- **Dashboard has no personality/display-name editor** — always use the CLI or edit config.yaml directly.
- Setting `display.personality: ''` (empty string) restores the base persona with no overlay.
- Custom personality names are arbitrary strings — any name under `agent.personalities` can be referenced in `display.personality`.
- The `/personality` slash command only affects the current session; changes are NOT saved to config.
- The config key is `display.personality` (not `persona`, not `display.skin` — `skin` controls CLI theme colors only).
- There is no persisting in-memory personality after exit. If you want a specific persona every session, set it in `config.yaml`.

### Providers

20+ providers supported. Set via `hermes model` or `hermes setup`.

| Provider | Auth | Key env var |
|----------|------|-------------|
| OpenRouter | API key | `OPENROUTER_API_KEY` |
| Anthropic | API key | `ANTHROPIC_API_KEY` |
| Nous Portal | OAuth | `hermes auth` |
| OpenAI Codex | OAuth | `hermes auth` |
| GitHub Copilot | Token | `COPILOT_GITHUB_TOKEN` |
| Google Gemini | API key | `GOOGLE_API_KEY` or `GEMINI_API_KEY` |
| DeepSeek | API key | `DEEPSEEK_API_KEY` |
| xAI / Grok | API key | `XAI_API_KEY` |
| Hugging Face | Token | `HF_TOKEN` |
| Z.AI / GLM | API key | `GLM_API_KEY` |
| MiniMax | API key | `MINIMAX_API_KEY` |
| MiniMax CN | API key | `MINIMAX_CN_API_KEY` |
| Kimi / Moonshot | API key | `KIMI_API_KEY` |
| Alibaba / DashScope | API key | `DASHSCOPE_API_KEY` |
| Xiaomi MiMo | API key | `XIAOMI_API_KEY` |
| Kilo Code | API key | `KILOCODE_API_KEY` |
| AI Gateway (Vercel) | API key | `AI_GATEWAY_API_KEY` |
| OpenCode Zen | API key | `OPENCODE_ZEN_API_KEY` |
| OpenCode Go | API key | `OPENCODE_GO_API_KEY` |
| Qwen OAuth | OAuth | `hermes login --provider qwen-oauth` |
| Custom endpoint | Config | `model.base_url` + `model.api_key` in config.yaml |
| GitHub Copilot ACP | External | `COPILOT_CLI_PATH` or Copilot CLI |

Full provider docs: https://hermes-agent.nousresearch.com/docs/integrations/providers

### Toolsets

Enable/disable via `hermes tools` (interactive) or `hermes tools enable/disable NAME`.

| Toolset | What it provides |
|---------|-----------------|
| `web` | Web search and content extraction |
| `browser` | Browser automation (Browserbase, Camofox, or local Chromium) |
| `terminal` | Shell commands and process management |
| `file` | File read/write/search/patch |
| `code_execution` | Sandboxed Python execution |
| `vision` | Image analysis |
| `image_gen` | AI image generation |
| `tts` | Text-to-speech |
| `skills` | Skill browsing and management |
| `memory` | Persistent cross-session memory |
| `session_search` | Search past conversations |
| `delegation` | Subagent task delegation |
| `cronjob` | Scheduled task management |
| `clarify` | Ask user clarifying questions |
| `messaging` | Cross-platform message sending |
| `search` | Web search only (subset of `web`) |
| `todo` | In-session task planning and tracking |
| `rl` | Reinforcement learning tools (off by default) |
| `moa` | Mixture of Agents (off by default) |
| `homeassistant` | Smart home control (off by default) |

Tool changes take effect on `/reset` (new session). They do NOT apply mid-conversation to preserve prompt caching.

---

## Security & Privacy Toggles

Common "why is Hermes doing X to my output / tool calls / commands?" toggles — and the exact commands to change them. Most of these need a fresh session (`/reset` in chat, or start a new `hermes` invocation) because they're read once at startup.

### Secret redaction in tool output

Secret redaction is **off by default** — tool output (terminal stdout, `read_file`, web content, subagent summaries, etc.) passes through unmodified. If the user wants Hermes to auto-mask strings that look like API keys, tokens, and secrets before they enter the conversation context and logs:

```bash
hermes config set security.redact_secrets true       # enable globally
```

**Restart required.** `security.redact_secrets` is snapshotted at import time — toggling it mid-session (e.g. via `export HERMES_REDACT_SECRETS=true` from a tool call) will NOT take effect for the running process. Tell the user to run `hermes config set security.redact_secrets true` in a terminal, then start a new session. This is deliberate — it prevents an LLM from flipping the toggle on itself mid-task.

Disable again with:
```bash
hermes config set security.redact_secrets false
```

### PII redaction in gateway messages

Separate from secret redaction. When enabled, the gateway hashes user IDs and strips phone numbers from the session context before it reaches the model:

```bash
hermes config set privacy.redact_pii true    # enable
hermes config set privacy.redact_pii false   # disable (default)
```

### Command approval prompts

By default (`approvals.mode: manual`), Hermes prompts the user before running shell commands flagged as destructive (`rm -rf`, `git reset --hard`, etc.). The modes are:

- `manual` — always prompt (default)
- `smart` — use an auxiliary LLM to auto-approve low-risk commands, prompt on high-risk
- `off` — skip all approval prompts (equivalent to `--yolo`)

```bash
hermes config set approvals.mode smart       # recommended middle ground
hermes config set approvals.mode off         # bypass everything (not recommended)
```

Per-invocation bypass without changing config:
- `hermes --yolo …`
- `export HERMES_YOLO_MODE=1`

Note: YOLO / `approvals.mode: off` does NOT turn off secret redaction. They are independent.

### Shell hooks allowlist

Some shell-hook integrations require explicit allowlisting before they fire. Managed via `~/.hermes/shell-hooks-allowlist.json` — prompted interactively the first time a hook wants to run.

### Disabling the web/browser/image-gen tools

To keep the model away from network or media tools entirely, open `hermes tools` and toggle per-platform. Takes effect on next session (`/reset`). See the Tools & Skills section above.

---

## Voice & Transcription

### STT (Voice → Text)

Voice messages from messaging platforms are auto-transcribed.

Provider priority (auto-detected):
1. **Local faster-whisper** — free, no API key: `pip install faster-whisper`
2. **Groq Whisper** — free tier: set `GROQ_API_KEY`
3. **OpenAI Whisper** — paid: set `VOICE_TOOLS_OPENAI_KEY`
4. **Mistral Voxtral** — set `MISTRAL_API_KEY`

Config:
```yaml
stt:
  enabled: true
  provider: local        # local, groq, openai, mistral
  local:
    model: base          # tiny, base, small, medium, large-v3
```

### TTS (Text → Voice)

| Provider | Env var | Free? |
|----------|---------|-------|
| Edge TTS | None | Yes (default) |
| ElevenLabs | `ELEVENLABS_API_KEY` | Free tier |
| OpenAI | `VOICE_TOOLS_OPENAI_KEY` | Paid |
| MiniMax | `MINIMAX_API_KEY` | Paid |
| Mistral (Voxtral) | `MISTRAL_API_KEY` | Paid |
| NeuTTS (local) | None (`pip install neutts[all]` + `espeak-ng`) | Free |

Voice commands: `/voice on` (voice-to-voice), `/voice tts` (always voice), `/voice off`.

---

## Spawning Additional Hermes Instances

Run additional Hermes processes as fully independent subprocesses — separate sessions, tools, and environments.

### When to Use This vs delegate_task

| | `delegate_task` | Spawning `hermes` process |
|-|-----------------|--------------------------|
| Isolation | Separate conversation, shared process | Fully independent process |
| Duration | Minutes (bounded by parent loop) | Hours/days |
| Tool access | Subset of parent's tools | Full tool access |
| Interactive | No | Yes (PTY mode) |
| Use case | Quick parallel subtasks | Long autonomous missions |

### One-Shot Mode

```
terminal(command="hermes chat -q 'Research GRPO papers and write summary to ~/research/grpo.md'", timeout=300)

# Background for long tasks:
terminal(command="hermes chat -q 'Set up CI/CD for ~/myapp'", background=true)
```

### Interactive PTY Mode (via tmux)

Hermes uses prompt_toolkit, which requires a real terminal. Use tmux for interactive spawning:

```
# Start
terminal(command="tmux new-session -d -s agent1 -x 120 -y 40 'hermes'", timeout=10)

# Wait for startup, then send a message
terminal(command="sleep 8 && tmux send-keys -t agent1 'Build a FastAPI auth service' Enter", timeout=15)

# Read output
terminal(command="sleep 20 && tmux capture-pane -t agent1 -p", timeout=5)

# Send follow-up
terminal(command="tmux send-keys -t agent1 'Add rate limiting middleware' Enter", timeout=5)

# Exit
terminal(command="tmux send-keys -t agent1 '/exit' Enter && sleep 2 && tmux kill-session -t agent1", timeout=10)
```

### Multi-Agent Coordination

```
# Agent A: backend
terminal(command="tmux new-session -d -s backend -x 120 -y 40 'hermes -w'", timeout=10)
terminal(command="sleep 8 && tmux send-keys -t backend 'Build REST API for user management' Enter", timeout=15)

# Agent B: frontend
terminal(command="tmux new-session -d -s frontend -x 120 -y 40 'hermes -w'", timeout=10)
terminal(command="sleep 8 && tmux send-keys -t frontend 'Build React dashboard for user management' Enter", timeout=15)

# Check progress, relay context between them
terminal(command="tmux capture-pane -t backend -p | tail -30", timeout=5)
terminal(command="tmux send-keys -t frontend 'Here is the API schema from the backend agent: ...' Enter", timeout=5)
```

### Session Resume

```
# Resume most recent session
terminal(command="tmux new-session -d -s resumed 'hermes --continue'", timeout=10)

# Resume specific session
terminal(command="tmux new-session -d -s resumed 'hermes --resume 20260225_143052_a1b2c3'", timeout=10)
```

### Tips

- **Prefer `delegate_task` for quick subtasks** — less overhead than spawning a full process
- **Use `-w` (worktree mode)** when spawning agents that edit code — prevents git conflicts
- **Set timeouts** for one-shot mode — complex tasks can take 5-10 minutes
- **Use `hermes chat -q` for fire-and-forget** — no PTY needed
- **Use tmux for interactive sessions** — raw PTY mode has `\r` vs `\n` issues with prompt_toolkit
- **For scheduled tasks**, use the `cronjob` tool instead of spawning — handles delivery and retry

---

## Troubleshooting

### Voice not working
1. Check `stt.enabled: true` in config.yaml
2. Verify provider: `pip install faster-whisper` or set API key
3. In gateway: `/restart`. In CLI: exit and relaunch.

### Tool not available
1. `hermes tools` — check if toolset is enabled for your platform
2. Some tools need env vars (check `.env`)
3. `/reset` after enabling tools

### Model/provider issues
1. `hermes doctor` — check config and dependencies
2. `hermes login` — re-authenticate OAuth providers
3. Check `.env` has the right API key
4. **Copilot 403**: `gh auth login` tokens do NOT work for Copilot API. You must use the Copilot-specific OAuth device code flow via `hermes model` → GitHub Copilot.

### Changes not taking effect
- **Tools/skills:** `/reset` starts a new session with updated toolset
- **Config changes:** In gateway: `/restart`. In CLI: exit and relaunch.
- **Code changes:** Restart the CLI or gateway process

### Skills not showing
1. `hermes skills list` — verify installed
2. `hermes skills config` — check platform enablement
3. Load explicitly: `/skill name` or `hermes -s name`

### Gateway issues

For a full step-by-step Telegram setup guide (token verification, env file write workaround, WSL pitfalls, access control), see: `references/telegram-gateway-setup.md`

For running multiple Telegram bots simultaneously via separate profiles: `references/multiple-telegram-bots.md`

For adding a second/third platform (Discord, Slack, etc.) to an existing multi-platform profile: `references/multi-platform-profile.md`

For running multiple Hermes profiles (gods) on the **same Discord server** without cross-channel chatter — channel isolation, `require_mention` + `allowed_channels` interaction, force-killing stuck gateways, and per-god config comparison: `references/multiple-discord-bots-channel-isolation.md`

**⚠️ Common pitfall: Profile gateway starts but bot can't answer ("No inference provider configured")** — New Hermes profiles have NO model or provider configuration. The gateway service starts fine, but when a user sends a message, the agent errors out. Always configure `model:` and `providers:` in the profile's `config.yaml` (not just `.env` tokens). Use `<profile-name> doctor` to verify before opening the bot to users.

Check logs first:
```bash
grep -i "failed to send\|error" ~/.hermes/logs/gateway.log | tail -20
```

Common gateway problems:
- **Gateway dies on SSH logout**: Enable linger: `sudo loginctl enable-linger $USER`
- **Gateway dies on WSL2 close**: WSL2 requires `systemd=true` in `/etc/wsl.conf` for systemd services to work. Without it, gateway falls back to `nohup` (dies when session closes).
- **Gateway crash loop**: Reset the failed state: `systemctl --user reset-failed hermes-gateway`

### Platform-specific issues
- **Discord bot silent**: Must enable **Message Content Intent** in Bot → Privileged Gateway Intents.
- **Slack bot only works in DMs**: Must subscribe to `message.channels` event. Without it, the bot ignores public channels.
- **Windows HTTP 400 "No models provided"**: Config file encoding issue (BOM). Ensure `config.yaml` is saved as UTF-8 without BOM.

### Auxiliary models not working
If `auxiliary` tasks (vision, compression, session_search) fail silently, the `auto` provider can't find a backend. Either set `OPENROUTER_API_KEY` or `GOOGLE_API_KEY`, or explicitly configure each auxiliary task's provider:
```bash
hermes config set auxiliary.vision.provider <your_provider>
hermes config set auxiliary.vision.model <model_name>
```

---

For details on how Hermes discovers providers from `.env`, the gap between LiteLLM service env vars and Hermes env vars, and the full list of env vars Hermes scans: `references/hermes-provider-env-setup.md`

## Where to Find Things

| Looking for... | Location |
|----------------|----------|
| Config options | `hermes config edit` or [Configuration docs](https://hermes-agent.nousresearch.com/docs/user-guide/configuration) |
| Available tools | `hermes tools list` or [Tools reference](https://hermes-agent.nousresearch.com/docs/reference/tools-reference) |
| Slash commands | `/help` in session or [Slash commands reference](https://hermes-agent.nousresearch.com/docs/reference/slash-commands) |
| Skills catalog | `hermes skills browse` or [Skills catalog](https://hermes-agent.nousresearch.com/docs/reference/skills-catalog) |
| Provider setup | `hermes model` or [Providers guide](https://hermes-agent.nousresearch.com/docs/integrations/providers) |
| Platform setup | `hermes gateway setup` or [Messaging docs](https://hermes-agent.nousresearch.com/docs/user-guide/messaging/) |
| MCP servers | `hermes mcp list` or [MCP guide](https://hermes-agent.nousresearch.com/docs/user-guide/features/mcp) |
| Profiles | `hermes profile list` or [Profiles docs](https://hermes-agent.nousresearch.com/docs/user-guide/profiles) |
| Cron jobs | `hermes cron list` or [Cron docs](https://hermes-agent.nousresearch.com/docs/user-guide/features/cron) |
| Memory | `hermes memory status` or [Memory docs](https://hermes-agent.nousresearch.com/docs/user-guide/features/memory) |
| Env variables | `hermes config env-path` or [Env vars reference](https://hermes-agent.nousresearch.com/docs/reference/environment-variables) |
| CLI commands | `hermes --help` or [CLI reference](https://hermes-agent.nousresearch.com/docs/reference/cli-commands) |
| Gateway logs | `~/.hermes/logs/gateway.log` |
| Session files | `~/.hermes/sessions/` or `hermes sessions browse` |
| Source code | `~/.hermes/hermes-agent/` |

---

## Contributor Quick Reference

For occasional contributors and PR authors. Full developer docs: https://hermes-agent.nousresearch.com/docs/developer-guide/

### Project Layout

```
hermes-agent/
├── run_agent.py          # AIAgent — core conversation loop
├── model_tools.py        # Tool discovery and dispatch
├── toolsets.py           # Toolset definitions
├── cli.py                # Interactive CLI (HermesCLI)
├── hermes_state.py       # SQLite session store
├── agent/                # Prompt builder, context compression, memory, model routing, credential pooling, skill dispatch
├── hermes_cli/           # CLI subcommands, config, setup, commands
│   ├── commands.py       # Slash command registry (CommandDef)
│   ├── config.py         # DEFAULT_CONFIG, env var definitions
│   └── main.py           # CLI entry point and argparse
├── tools/                # One file per tool
│   └── registry.py       # Central tool registry
├── gateway/              # Messaging gateway
│   └── platforms/        # Platform adapters (telegram, discord, etc.)
├── cron/                 # Job scheduler
├── tests/                # ~3000 pytest tests
└── website/              # Docusaurus docs site
```

Config: `~/.hermes/config.yaml` (settings), `~/.hermes/.env` (API keys).

### Adding a Tool (3 files)

**1. Create `tools/your_tool.py`:**
```python
import json, os
from tools.registry import registry

def check_requirements() -> bool:
    return bool(os.getenv("EXAMPLE_API_KEY"))

def example_tool(param: str, task_id: str = None) -> str:
    return json.dumps({"success": True, "data": "..."})

registry.register(
    name="example_tool",
    toolset="example",
    schema={"name": "example_tool", "description": "...", "parameters": {...}},
    handler=lambda args, **kw: example_tool(
        param=args.get("param", ""), task_id=kw.get("task_id")),
    check_fn=check_requirements,
    requires_env=["EXAMPLE_API_KEY"],
)
```

**2. Add to `toolsets.py`** → `_HERMES_CORE_TOOLS` list.

Auto-discovery: any `tools/*.py` file with a top-level `registry.register()` call is imported automatically — no manual list needed.

All handlers must return JSON strings. Use `get_hermes_home()` for paths, never hardcode `~/.hermes`.

### Adding a Slash Command

1. Add `CommandDef` to `COMMAND_REGISTRY` in `hermes_cli/commands.py`
2. Add handler in `cli.py` → `process_command()`
3. (Optional) Add gateway handler in `gateway/run.py`

All consumers (help text, autocomplete, Telegram menu, Slack mapping) derive from the central registry automatically.

### Agent Loop (High Level)

```
run_conversation():
  1. Build system prompt
  2. Loop while iterations < max:
     a. Call LLM (OpenAI-format messages + tool schemas)
     b. If tool_calls → dispatch each via handle_function_call() → append results → continue
     c. If text response → return
  3. Context compression triggers automatically near token limit
```

### Testing

```bash
python -m pytest tests/ -o 'addopts=' -q   # Full suite
python -m pytest tests/tools/ -q            # Specific area
```

- Tests auto-redirect `HERMES_HOME` to temp dirs — never touch real `~/.hermes/`
- Run full suite before pushing any change
- Use `-o 'addopts='` to clear any baked-in pytest flags

### Commit Conventions

```
type: concise subject line

Optional body.
```

Types: `fix:`, `feat:`, `refactor:`, `docs:`, `chore:`

### Key Rules

- **Never break prompt caching** — don't change context, tools, or system prompt mid-conversation
- **Message role alternation** — never two assistant or two user messages in a row
- Use `get_hermes_home()` from `hermes_constants` for all paths (profile-safe)
- Config values go in `config.yaml`, secrets go in `.env`
- New tools need a `check_fn` so they only appear when requirements are met
