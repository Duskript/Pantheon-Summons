# Hermes Provider Env Setup

Hermes discovers providers by scanning env vars in `~/.hermes/.env` at startup. The dashboard's provider list and `hermes auth list` both derive from this.

## The Env File Gap (LiteLLM vs Hermes)

This machine (Pantheon/U55) runs **LiteLLM** as a separate service with its own env vars in `~/.config/systemd/user/litellm.service`. API keys set there (like `OPENCODE_GO_API_KEY`) are available to LiteLLM but **NOT to Hermes** unless also present in `~/.hermes/.env`.

### Symptoms
- LiteLLM routes `opencode/` models fine (port 4000)
- Hermes dashboard shows no OpenCode Go provider
- `hermes auth list` doesn't show the provider
- User asks "why isn't X in the list?" — check `.env` first

### Fix
Uncomment the relevant line in `~/.hermes/.env`:
```bash
sed -i 's|# OPENCODE_GO_API_KEY=$|OPENCODE_GO_API_KEY=sk-...|' ~/.hermes/.env
```

Then restart the dashboard:
```bash
hermes dashboard --stop
hermes dashboard --host 0.0.0.0 --port 9119 --insecure  # if remote access needed
```

## Env vars Hermes scans for providers

| Provider | Env var |
|----------|---------|
| OpenCode Go | `OPENCODE_GO_API_KEY` |
| OpenCode Zen | `OPENCODE_ZEN_API_KEY` |
| OpenAI (standard) | `OPENAI_API_KEY` |
| Anthropic | `ANTHROPIC_API_KEY` |
| OpenRouter | `OPENROUTER_API_KEY` |
| Google/Gemini | `GOOGLE_API_KEY` or `GEMINI_API_KEY` |
| DeepSeek | `DEEPSEEK_API_KEY` |
| xAI/Grok | `XAI_API_KEY` |
| Hugging Face | `HF_TOKEN` |
| Z.AI/GLM | `GLM_API_KEY` |
| MiniMax | `MINIMAX_API_KEY` |
| Kimi/Moonshot | `KIMI_API_KEY` |
| Kilo Code | `KILOCODE_API_KEY` |
| AI Gateway | `AI_GATEWAY_API_KEY` |

Full list: `~/.hermes/.env` has all of these, commented out. Just uncomment + fill the key.

## Pitfalls
- **Dashboard doesn't hot-reload env vars** — must stop/restart `hermes dashboard` for `.env` changes to take effect
- **OAuth providers (openai-codex)** are stored in `~/.hermes/auth.json`, NOT `.env` — these show up differently in the dashboard
- **Custom endpoints** (LM Studio, local Ollama) are configured in `config.yaml` under `model.base_url`, not via env vars — they won't appear as "providers" in the dashboard's provider list, they're the model's base_url
- **Dual-purpose keys** — OpenCode Go key was originally set only in LiteLLM's systemd service for proxy routing. When the user asked why it wasn't in the Hermes dashboard, the key existed but wasn't exposed to Hermes. Always check BOTH locations.
