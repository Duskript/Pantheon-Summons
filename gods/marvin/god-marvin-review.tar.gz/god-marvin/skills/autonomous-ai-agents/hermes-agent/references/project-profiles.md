# Project-Specific Hermes Profiles

Workflow for creating a named Hermes profile that is isolated, pinned to a project repo, and has git access.

## Use Case

You want a separate Hermes instance dedicated to a specific project — with its own config, sessions, skills, and working directory — so work on different projects doesn't bleed together.

## Step-by-Step

### 1. Create the Profile

```bash
hermes profile create <name>
```

This creates `~/.hermes/profiles/<name>/` with its own `sessions/`, `skills/`, `memories/`, `logs/`, `workspace/`, and a `SOUL.md` personality file. It also creates a CLI wrapper at `~/.local/bin/<name>` so you can launch it directly:

```bash
<name> chat
```

### 2. Pin the Working Directory

Set the profile's terminal working directory to the project root:

```bash
echo "terminal:\n    cwd: /home/user/projects/myapp" > ~/.hermes/profiles/<name>/config.yaml
```

The profile starts in that directory for all terminal commands.

### 3. Set Git Identity

Set a git identity so commits made by this profile are attributed to it:

**Globally** (all repos):

```bash
git config --global user.name "ProfileName"
git config --global user.email "profile@project.local"
```

**Per-repo** (recommended for project-specific profiles):

```bash
cd ~/projects/myapp
git config --local user.name "ProfileName (MyApp)"
git config --local user.email "profile@project.local"
```

### 4. Wire Up Git Credentials

If the repo uses a GitHub PAT (Personal Access Token), store it with git so the profile can push/pull without interactive auth:

```bash
printf "protocol=https\nhost=github.com\nusername=<user>\npassword=<ghp_xxxxxxxx>\n" | git credential-store store
```

This writes to `~/.git-credentials`. The profile inherits this automatically since it runs as the same OS user. The token is now stored in a file readable only by that user (~/.git-credentials, chmod 600).

### 5. Clean the Remote URL

If you cloned with the PAT embedded in the URL (e.g. `https://<token>@github.com/user/repo.git`), remove it so the token doesn't appear in `git remote -v` output:

```bash
cd ~/projects/myapp
git remote set-url origin https://github.com/user/repo.git
```

The credential store handles auth automatically from now on.

### 6. Configure the Model (⚠️ Critical)

New profiles have **zero model/provider config** — no default model, no provider, no API endpoint. If you launch the gateway before configuring this, it will fail with:

```
⚠️ Provider authentication failed: No inference provider configured.
```

Fix by copying the `model:` and `providers:` blocks from your working Hermes config:

```bash
# Read your main config's model+providers section:
grep -A8 '^model:' ~/.hermes/config.yaml
grep -A6 '^providers:' ~/.hermes/config.yaml
```

Then write them into the profile's `config.yaml`. At minimum you need:

```yaml
model:
  api_key: ...
  base_url: ...
  default: <model-name>
  provider: <provider-name>
providers:
  <provider-name>:
    api: ...
    default_model: <model-name>
```

The easiest way is to edit the file directly:

```bash
cat >> ~/.hermes/profiles/<name>/config.yaml << 'EOF'
model:
  default: <model>
  provider: <provider>
  # ... provider-specific keys
EOF
```

**Verify:**

```bash
<name> doctor
```

If it shows model issues, the config isn't complete. Profiles share NOTHING from the main profile's config.yaml — not the model, not providers, not tools.

## Profile Layout

```
~/.hermes/profiles/<name>/
├── SOUL.md            # Personality prompt
├── config.yaml        # Profile-specific settings
├── workspace/         # Default working directory
├── sessions/          # Session transcripts
├── skills/            # Loaded skills (isolated copy)
├── memories/          # Memory store
├── logs/              # Gateway and session logs
├── cron/              # Scheduled jobs
├── plans/             # Saved plans
├── skins/             # UI themes
└── home/              # Home channel state (gateway)
```

## CLI Wrapper

The `hermes profile create` command generates a shell script at `~/.local/bin/<name>` that runs:

```bash
hermes -p <name> "$@"
```

So `hephaestus chat` is equivalent to `hermes -p hephaestus chat`.

## Tips

- Profiles share **nothing** by default — no skills, no sessions, no memories. Use `hermes profile create --clone <existing>` to seed a new profile from an existing one.
- Use `hermes profile use <name>` to make a profile the default for bare `hermes` invocations.
- The `.env` file is shared at `~/.hermes/.env` (not per-profile), so secrets like `TELEGRAM_BOT_TOKEN` or `GATEWAY_ALLOW_ALL_USERS` are global. For truly isolated secrets, set them as env vars before launching the profile wrapper.
