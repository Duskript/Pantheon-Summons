# Running Multiple Telegram Bots (Multi-Profile Gateway)

How to run two or more Telegram bots simultaneously from a single Hermes installation, each with its own identity, config, and token.

## When to Use

- You want separate bots for different purposes (e.g. one for personal use, one for community, one for a specific project)
- Each bot needs a different personality, config, model, or working directory
- Each bot gets its own Telegram bot token from [@BotFather](https://t.me/BotFather)

## Architecture

Each bot lives in its own **Hermes profile**. The main profile runs the first bot, and additional profiles run additional bot gateways as separate systemd services.

```
~/.hermes/
├── config.yaml                          # Main profile (Zoai / bot 1)
├── .env                                 # Shared env (API keys, etc.)
└── profiles/
    └── <bot-name>/                      # Profile for bot 2, 3, ...
        ├── config.yaml                  # Isolated model/provider config (!)
        ├── .env                         # That bot's Telegram token
        ├── sessions/                    # Isolated conversation history
        └── ...                          # Skills, memories, logs, etc.
```

## Step-by-Step

### 1. Create the Profile

```bash
hermes profile create <bot-name>
```

This creates `~/.hermes/profiles/<bot-name>/` with a CLI wrapper at `~/.local/bin/<bot-name>`.

### 2. Write the Bot Token in the Profile's .env

The profile's `.env` file is **separate** from the global `~/.hermes/.env`:

```bash
echo 'TELEGRAM_BOT_TOKEN=123456789:AA...' >> ~/.hermes/profiles/<bot-name>/.env
echo 'GATEWAY_ALLOW_ALL_USERS=true' >> ~/.hermes/profiles/<bot-name>/.env
```

The global `.env` is NOT read by the profile's gateway, so this per-profile `.env` is required.

### 3. ⚠️ CRITICAL: Configure Model & Provider

**This is the most common pitfall.** New profiles have ZERO model config, so the gateway will start but fail to answer messages with:

```
⚠️ Provider authentication failed: No inference provider configured.
```

Copy the `model:` and `providers:` blocks from your main config (`~/.hermes/config.yaml`) into the profile's `config.yaml`. At minimum:

```yaml
terminal:
    cwd: /home/user/<project-or-working-dir>
model:
  default: <model-name>
  provider: <provider-name>
  base_url: http://127.0.0.1:11434/v1    # or whatever your provider uses
  api_key: <key-or-var>
providers:
  <provider-name>:
    api: <api-url>
    default_model: <model-name>
    models:
    - <model-name>
    name: <provider-display-name>
```

Verify with:

```bash
<bot-name> doctor
```

If it shows "No inference provider configured", the model config is missing or incomplete.

### 4. Install & Start the Gateway Service

```bash
hermes --profile <bot-name> gateway install
hermes --profile <bot-name> gateway start
```

This creates a **separate systemd service** named `hermes-gateway-<bot-name>` — it runs independently alongside the main gateway.

### 5. ⚠️ WSL Restart

On WSL, gateway services don't auto-start on full WSL restart. You'll need to start each one manually:

```bash
hermes --profile <bot-name> gateway start
```

## Management Commands

| Action | Command |
|--------|---------|
| Check status | `hermes --profile <bot-name> gateway status` |
| View logs | `journalctl --user -u hermes-gateway-<bot-name> -f` |
| Stop | `hermes --profile <bot-name> gateway stop` |
| Start | `hermes --profile <bot-name> gateway start` |
| Restart (use stop+start on WSL) | `hermes --profile <bot-name> gateway stop && sleep 1 && hermes --profile <bot-name> gateway start` |
| Run foreground (for testing) | `hermes --profile <bot-name> gateway run` |

> **Note:** Use `stop && start` instead of `restart` on WSL. The `restart` command frequently exits with TEMPFAIL (exit code 75) on WSL.

## How It Works

Each profile's gateway binds to a unique Telegram bot token. When Telegram sends an update, the correct gateway (the one whose token matches) picks it up. The bots don't conflict because Telegram routes each message to the correct bot by token.

The system has these components running:

```
hermes-gateway.service               → ~/.hermes/.env token (Zoai)
hermes-gateway-<bot-name>.service    → ~/.hermes/profiles/<bot-name>/.env token
hermes-gateway-another.service       → another profile's token
```

## Pitfalls

- **Profile has no model config** → messages get "No inference provider configured" error. Always configure `model:` and `providers:` in the profile's `config.yaml`.
- **Profile has no `.env`** → gateway starts but can't connect to Telegram. The global `.env` is NOT shared with profiles.
- **WSL restart kills everything** → gateways don't survive WSL reboots. Run `hermes --profile <name> gateway start` for each bot after reboot.
- **Token already in use by something** → each token can only have one polling connection. Make sure you're not running the same token in two places.
