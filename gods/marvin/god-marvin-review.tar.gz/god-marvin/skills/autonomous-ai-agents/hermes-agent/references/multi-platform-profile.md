# Adding Platforms to an Existing Multi-Platform Profile

How to add a **second (or third...) messaging platform** to a profile that's already running with one platform. Covers both the single-profile approach (Telegram + Discord in one profile) and the multi-profile approach (one profile per bot).

## When to Use

- You already have a profile running with one platform (e.g. Telegram)
- You want to add Discord, Slack, WhatsApp, or another platform to the **same profile** so the same agent instance handles both
- You already have a working reference profile (usually your main `~/.hermes/`) that has the platform working

## Architecture

Each platform needs two things in the target profile:

1. **Config block** in `config.yaml` — platform-specific settings (channels, reactions, etc.)
2. **Credential in `.env`** — the bot token/API key for that platform

Both are profile-scoped — the global `~/.hermes/.env` is NOT read by profile gateways.

## Workflow: Pattern-Match from a Reference Profile

The fastest approach: copy the platform config from a profile that already has it working (usually `~/.hermes/`), then customize for the target profile.

### 1. Grab the platform config block

From your reference profile's `config.yaml`, find the platform's section. For example, Discord:

```yaml
discord:
  require_mention: false
  free_response_channels: ''
  allowed_channels: '*'
  auto_thread: false
  reactions: true
  channel_prompts: {}
  server_actions: ''
```

Append this to the target profile's `config.yaml`.

### 2. Write the token

Add the bot token and any platform-specific vars to the profile's `.env`:

```bash
# Discord
echo 'DISCORD_BOT_TOKEN=MTQ5...token...' >> ~/.hermes/profiles/<name>/.env
echo 'DISCORD_HOME_CHANNEL=1499851385704022088' >> ~/.hermes/profiles/<name>/.env
```

### 3. Restart the gateway

```bash
systemctl --user restart hermes-gateway-<profile-name>
# Or the stop+start dance on WSL:
systemctl --user stop hermes-gateway-<profile-name>
sleep 1
systemctl --user start hermes-gateway-<profile-name>
```

### 4. Verify in logs

Both platforms should show connected:

```bash
grep -i "connected\|✓ " ~/.hermes/profiles/<name>/logs/gateway.log | tail -5
```

Expected output (example):
```
✓ discord connected
✓ telegram connected
Gateway running with 2 platform(s)
```

## Pitfalls

- **Profile has no model config** → the gateway starts, bots connect, but messages get "No inference provider configured". Always configure `model:` and `providers:` in the profile's `config.yaml` before adding platforms.
- **Token for wrong platform** → a Discord token in `TELEGRAM_BOT_TOKEN` won't work (and vice versa). The env var name must match: `DISCORD_BOT_TOKEN`, `TELEGRAM_BOT_TOKEN`, `SLACK_BOT_TOKEN`, etc.
- **Opus codec** → Discord voice channel playback requires libopus. The warning `Opus codec not found — voice channel playback disabled` is harmless for text bots.
- **Gateway restart** → on WSL, use `stop + start` not `restart` (TEMPFAIL exit code 75).
- **Platform requires intents** → Discord bots need **Message Content Intent** enabled in Bot → Privileged Gateway Intents. Slack bots need `message.channels` event subscribed.
