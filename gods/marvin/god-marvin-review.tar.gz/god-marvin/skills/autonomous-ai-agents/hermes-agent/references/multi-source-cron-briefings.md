# Multi-Source Cron Briefings

Pattern for building daily cron briefings that pull data from multiple sources (files, APIs, system reports) and compose it into a single dispatch.

## Architecture

```
Bash wrapper script
  ├── Echo section label → File(s) via cat
  ├── Echo section label → Python sub-script (file scanner)
  └── Echo section label → Python sub-script (API fetcher)
       ↓
Cron job captures all stdout → Prepends to prompt
       ↓
LLM receives raw data + formatting prompt
       ↓
Composed briefing delivered to user
```

## Script Template: Bash Wrapper

Saved at `~/.hermes/scripts/morning-briefing.sh`:

```bash
#!/bin/bash
echo "=== HADES_REPORT ==="
cat /home/konan/athenaeum/Codex-Pantheon/reports/hades-$(date +%Y-%m-%d).md

echo ""
echo "=== OVERNIGHT_INBOX ==="
python3 /home/konan/.hermes/scripts/overnight-inbox.py

echo ""
echo "=== HERMES_NEWS ==="
python3 /home/konan/.hermes/scripts/hermes-news.py
```

## Script Template: Python File Scanner

Saved at `~/.hermes/scripts/overnight-inbox.py`:

```python
#!/usr/bin/env python3
"""Scans JSON message directories for items from last N hours."""

import json, os, glob
from datetime import datetime, timezone, timedelta

MESSAGES_DIR = os.path.expanduser("~/pantheon/gods/messages")
CUTOFF_HOURS = 12
CUTOFF = datetime.now(timezone.utc) - timedelta(hours=CUTOFF_HOURS)

print("=== OVERNIGHT_INBOX ===")
total = 0
for inbox_dir in sorted(glob.glob(os.path.join(MESSAGES_DIR, "*"))):
    god_name = os.path.basename(inbox_dir)
    for msg_file in sorted(glob.glob(os.path.join(inbox_dir, "msg_*.json"))):
        try:
            with open(msg_file) as f:
                msg = json.load(f)
            ts = msg.get("timestamp", "")
            msg_time = datetime.fromisoformat(ts)
            if msg_time.tzinfo is None:
                msg_time = msg_time.replace(tzinfo=timezone.utc)
            if msg_time >= CUTOFF:
                total += 1
                print(f"MSG:{msg['id']}|to:{god_name}|from:{msg['from']}|subject:{msg.get('subject','')}")
                print(f"  → {msg.get('body','')[:200]}")
        except: continue

if total == 0:
    print("SILENT — no overnight messages")
else:
    print(f"\nTOTAL:{total} message(s)")
```

## Script Template: API Fetcher

Saved at `~/.hermes/scripts/hermes-news.py`:

```python
#!/usr/bin/env python3
"""Fetches top articles + community projects from external APIs."""

import json, xml.etree.ElementTree as ET
from urllib.request import Request, urlopen

print("=== TOP_ARTICLES ===")
# Google News RSS
rss_url = "https://news.google.com/rss/search?q=%22Hermes+Agent%22+AI&hl=en-US"
req = Request(rss_url, headers={"User-Agent": "Mozilla/5.0"})
resp = urlopen(req, timeout=10)
root = ET.fromstring(resp.read())
for item in root.findall(".//item")[:4]:
    print(f"TITLE:{item.findtext('title','')}")
    print(f"LINK:{item.findtext('link','')}")
    print(f"SOURCE:{item.findtext('source','')}")
    print("---")

print("=== COMMUNITY_PROJECTS ===")
# GitHub search
gh_url = "https://api.github.com/search/repositories?q=hermes-agent+tool+OR+plugin+OR+webui&sort=stars&per_page=10"
req = Request(gh_url, headers={"User-Agent": "Hermes-Briefing/1.0"})
resp = urlopen(req, timeout=10)
items = json.loads(resp.read()).get("items", [])
for r in items[:6]:
    print(f"NAME:{r['full_name']}")
    print(f"STARS:{r['stargazers_count']}")
    print(f"DESC:{(r.get('description') or '')[:120]}")
    print(f"URL:{r['html_url']}")
    print("---")
```

## Prompt Template

The prompt focuses on **tone + composition**, not data:

```
Compose an energetic, punchy morning briefing for [user].

Format it like a divine dispatch. Include these sections — only include sections with actual content:

1. **Report** — summarize key findings
2. **Messages** — any overnight messages. Skip if "SILENT".
3. **Projects** — status roll call with emojis (🟢 in-progress, 🟡 planning, 💡 idea)
4. **News** — top 4 latest articles with clickable links
5. **Community** — interesting projects, repos, skills with links
6. **Top of Mind** — what's hot, what's next

The data below has === SECTION_NAME === markers.
```

## Cron Registration

Use the `cronjob` tool with `script=` pointing to the bash wrapper:

```python
cronjob(action="create",
    name="Morning Briefing",
    schedule="5 7 * * *",        # 7:05 AM daily
    script="morning-briefing.sh",
    deliver="origin",             # delivers to user's chat platform
    prompt="...")
```

## Common Pitfalls

- **API blocking**: Always set `User-Agent` header on urllib requests
- **Stdlib dependency**: Keep Python scripts to stdlib only — cron may not have your pip packages
- **Working dir**: Bash scripts run from `~/.hermes/scripts/` — use absolute paths for file reads
- **Timeout**: API scripts need `timeout=10`+ in urlopen — RSS feeds can be slow
- **chmod**: Bash wrapper needs `chmod +x`; Python scripts don't if invoked via `python3 script.py`
