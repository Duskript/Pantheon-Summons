# Running Multiple Discord Bots with Channel Isolation

How to run multiple Hermes profiles (gods) on the **same Discord server** without them talking over each other, each restricted to its own channel.

## 🧠 The Core Problem

Unlike Telegram (which routes by bot token — one bot per gateway, never a collision), **Discord sends every message in a shared server to every bot that's connected**. Multiple Hermes profiles on the same server will ALL see the same messages unless you explicitly lock them down.

Without isolation, god A's gateway will respond to messages in god B's channel, and vice versa.

## How Isolation Works

Two configuration knobs that work together:

| Setting | What it does |
|---------|-------------|
| `discord.allowed_channels` | Whitelist of channel IDs this god responds in (without @mention) |
| `discord.require_mention: true` | God only responds when @mentioned (ignores all other messages) |

**For best results, use BOTH.** `allowed_channels` prevents cross-talk in channels where the god isn't supposed to be active. `require_mention` prevents the god from barging into general conversation even in its own channel.

## ⚠️ CRITICAL: `allowed_channels` is NOT a Hard Gate

`allowed_channels` does NOT stop the gateway from *receiving* messages in other channels — it only determines whether the agent *responds*. The gateway still sees everything. This means:

- **Memory / context** from other channels is still loaded into the agent's brain if session contexts merge
- **The gateway log** will show inbound messages from all channels, even if the agent doesn't reply
- For true isolation, combine with `require_mention: true`

## Step-by-Step Configuration

### 1. Get Your Channel IDs

Enable Discord Developer Mode (Settings → Advanced), then right-click any channel → Copy ID.

### 2. Configure Each Profile

In each profile's `config.yaml`, under the `discord:` section:

```yaml
discord:
  require_mention: true
  free_response_channels: ''
  allowed_channels: 'YOUR_CHANNEL_ID_HERE'
  auto_thread: false
  reactions: true
  channel_prompts: {}
  server_actions: ''
```

### 3. Set the Discord Token

In the profile's `.env`:

```
DISCORD_BOT_TOKEN=MTQ...your-token-here
DISCORD_HOME_CHANNEL=channel_id
```

Each god must have its **own Discord bot** (created at https://discord.com/developers/applications) with its own unique token.

### 4. Restart the Gateway

```bash
systemctl --user stop hermes-gateway-<profile>
sleep 2
systemctl --user reset-failed hermes-gateway-<profile>
systemctl --user start hermes-gateway-<profile>
```

## Gateway Stuck During Restart

**Common problem:** The gateway won't stop cleanly because child processes (e.g., MCP server scripts) hold it open. You'll see:

```
Active: deactivating (stop-sigterm) since ...
```

**Fix — force kill the process tree:**

```bash
# Find the PID
systemctl --user status hermes-gateway-<profile>

# Kill everything in the cgroup
kill -9 <main_pid> <child_pid_1> <child_pid_2>

# Clean up systemd state
systemctl --user reset-failed hermes-gateway-<profile>

# Start fresh
systemctl --user start hermes-gateway-<profile>
```

The `--replace` flag in the gateway command (`gateway run --replace`) helps, but when the old process's child processes don't die, `--replace` can't acquire the lock.

## Pitfalls

- **Same token in two profiles** → Discord rejects the second connection. Each bot needs a unique token.
- **Missing `allowed_channels`** → your god responds in EVERY channel. This is the #1 cause of bot cross-talk.
- **`require_mention: false` (default)** → the god responds to ANY message in `allowed_channels`, not just @mentions. Use `true` unless you want a channel-wide bot.
- **Token expired/revoked** → Discord tokens in the `.env` can expire or be reset from the dev portal. If a bot goes silent, check the token first.
- **Gateway crash-loop after config change** → always `reset-failed` before restarting after a config or token change.
- **Don't set `allowed_channels: ''` (empty string)** → this means "respond everywhere." The gateway treats empty as no restriction.
- **Auto-thread can confuse channel isolation** — set `auto_thread: false` unless you specifically want threads.

## Quick Reference: Profile Config Comparison

| Setting | Hermes (main, #the-herald) | Hephaestus (forge channel) | Apollo (Muse's Mount) |
|---------|---------------------------|---------------------------|----------------------|
| `require_mention` | `false` (open channel) | `true` | `true` |
| `allowed_channels` | herald channel ID | forge channel ID | Muse's Mount channel ID |
| `DISCORD_BOT_TOKEN` | Token A | Token B | Token C |

## Testing Isolation

After setup, test by:

1. Sending a message in god A's channel → **only god A should respond**
2. Sending a message in god B's channel → **only god B should respond**
3. Sending a message in any other channel → **neither responds**
4. @-mentioning god A in god B's channel → **god A responds** (because `require_mention` overrides channel lock — intentional)

If a god responds somewhere it shouldn't, check `allowed_channels` first, then `require_mention`, then verify the gateway actually restarted with the new config.
