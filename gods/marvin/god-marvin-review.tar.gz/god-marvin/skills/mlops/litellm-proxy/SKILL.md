---
name: litellm-proxy
title: LiteLLM Proxy Setup & Management
tags: [litellm, proxy, model-routing, ollama, python, systemd]
description: Install, configure, and manage LiteLLM as a model routing proxy on a remote/headless machine. Covers venv setup, dependency troubleshooting, config patterns, systemd service, and testing.
trigger: User asks to set up, install, configure, or troubleshoot LiteLLM proxy
---

# LiteLLM Proxy Setup & Management

## When to use this skill

You're deploying LiteLLM as a central model routing proxy so multiple Hermes Agent profiles (gods) can all point at one endpoint and have their `model` field determine the routing destination. LiteLLM runs headless with the web UI accessible for admin.

## Prerequisites

- SSH access to the target machine
- Python 3.x installed
- Target machine has network access to model providers (Ollama, Anthropic, OpenAI, etc.)
- If target machine has Ollama running, note the port (default 11434)

## Step 1: Create a virtual environment

Modern Ubuntu (25.04+) enforces PEP 668 — you cannot `pip install` system-wide. Always use a venv:

```bash
ssh <host> "python3 -m venv ~/litellm-env"
```

> **Pitfall:** Do NOT try `pip install --break-system-packages` or `--user`. These are fragile and pollute the system Python. A clean venv is always the right path.

## Step 2: Install LiteLLM

```bash
ssh <host> "~/litellm-env/bin/pip install litellm"
```

### Dependency cascade (Python 3.14+)

On newer Python versions (3.14+), the single `pip install 'litellm[proxy]'` command fails because the `'[proxy]'` extras spec pins old versions of `orjson` (3.10.15) and `uvloop` (0.21.0) which lack pre-built wheels for 3.14 and fail to compile from source (PyO3 bindings too old, libuv configure failures).

**The fix: install the core first, then the proxy extras separately.** Newer versions of orjson (3.11.8+) and uvloop (0.22.1+) DO have pre-built wheels for 3.14 — but you won't get them via the extras pinning.

```bash
# Step 1: core only (gets the main litellm package + base deps)
~/litellm-env/bin/pip install litellm

# Step 2: proxy server framework deps (these install clean)
~/litellm-env/bin/pip install uvicorn fastapi python-multipart gunicorn

# Step 3: all extra deps that proxy_server.py imports at runtime
# These include the newer wheel-compatible versions of orjson + uvloop
~/litellm-env/bin/pip install \
  websockets backoff orjson uvloop pyjwt pynacl \
  cryptography azure-identity azure-storage-blob \
  email-validator pydantic-settings sse-starlette httpx-sse \
  fastapi-sso mcp polars \
  litellm-proxy-extras litellm-enterprise pyroscope-io \
  soundfile apscheduler boto3 redis rq
```

> **Pitfall:** Never try `pip install 'litellm[proxy]'` all at once on Python 3.14+. The extras spec pins build-dependent packages to versions without 3.14 wheels. Install core first, then add the extras packages freely — pip resolves them individually and picks up newer wheel-compatible versions.
>
> **Pitfall:** The full proxy extras set is ~15+ additional packages beyond `litellm` itself. You'll know you're done when `~/litellm-env/bin/python3 -c "from litellm.proxy.proxy_server import app; print('OK')"` succeeds without import errors.
>
> **Reference:** See `references/python314-dependency-saga.md` in this skill for the full list of import errors encountered and the exact fix sequence, useful if you hit a gap on a future install.

## Step 3: Create the config

Write a `config.yaml` to the home directory on the target machine:

```yaml
general_settings:
  master_key: <your-admin-key>

litellm_settings:
  drop_params: true
  set_verbose: false

model_list:
  # Ollama models need the ollama/ prefix
  - model_name: <model-name-as-gods-will-request-it>
    litellm_params:
      model: ollama/<exact-ollama-model-name>
      api_base: http://localhost:11434

  # Non-Ollama (Anthropic, OpenAI, etc.)
  - model_name: <model-name>
    litellm_params:
      model: <provider>/<model>
      api_key: os.environ/ANTHROPIC_API_KEY
```

> **Pitfall:** The `model:` field in `litellm_params` MUST use a provider prefix:
> - `ollama/<name>` for Ollama models
> - `openai/<name>` for OpenAI-compatible
> - `anthropic/<name>` for Anthropic
> - `openai/<name>` with `api_base: <custom-url>` for any OpenAI-compatible provider
>
> Without the prefix, LiteLLM defaults to `openai/` and hits api.openai.com, returning 404.

> **Pitfall:** For Ollama cloud models, the `model_name` (what gods request) and the Ollama model name (what `ollama/list` shows) are the same string — just add the `ollama/` prefix in `litellm_params.model`.

## Step 4: Start the server (test)

```bash
ssh <host> "cd ~ && ~/litellm-env/bin/litellm --config ~/litellm-config.yaml --port 4000"
```

Keep this in a background terminal for testing. Verify:

```bash
# Health check
ssh <host> "curl -s http://localhost:4000/health/liveliness"

# List models (requires auth)
ssh <host> "curl -s http://localhost:4000/models -H 'Authorization: Bearer <master_key>'"

# Chat completion test
ssh <host> "curl -s http://localhost:4000/v1/chat/completions \
  -H 'Authorization: Bearer <master_key>' \
  -H 'Content-Type: application/json' \
  -d '{\"model\":\"<model-name>\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}],\"stream\":false}'"
```

## Step 5: Create systemd service

```ini
[Unit]
Description=LiteLLM Model Proxy
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=<username>
WorkingDirectory=/home/<username>
ExecStart=/home/<username>/litellm-env/bin/litellm --config /home/<username>/litellm-config.yaml --port 4000
Restart=always
RestartSec=5

[Install]
WantedBy=default.target
```

Deploy to `~/.config/systemd/user/litellm.service` or system-level.

```bash
ssh <host> "systemctl --user daemon-reload && systemctl --user enable --now litellm"
```

## Step 6: Wire Hermes profiles to use LiteLLM

Each Hermes god profile changes `base_url` to point at the LiteLLM proxy instead of the provider directly:

```yaml
provider: openai
base_url: http://<hostname>:4000
model: <model-name>
```

No other profile changes needed. The model name in the request tells LiteLLM where to route.

## Web UI / Key Management

### Swagger UI (always available)

The Swagger UI at `http://<host>:4000/` works on every Python version:
1. Open `http://<host>:4000/` in browser
2. Click **Authorize** → enter `master_key`
3. Find **POST `/key/generate`** → Try it out
4. Send:
```json
{
  "models": ["model1", "model2"],
  "metadata": {"user": "opencode"}
}
```
5. Copy the returned key

Alternatively, generate keys via curl:
```bash
curl http://<host>:4000/key/generate \
  -H "Authorization: Bearer <master_key>" \
  -H "Content-Type: application/json" \
  -d '{"models": ["model1"], "metadata": {"user": "opencode"}}'
```

### Admin Dashboard (`/ui`) — Python 3.14 BLOCKED

The Admin Dashboard at `http://<host>:4000/ui` requires Prisma ORM (SQLite), which does NOT support Python 3.14+ (`prisma generate` fails with PyO3 compatibility errors). This is a hard blocker — not just a missing pip package.

**DO NOT** add `database_url` to the config on Python 3.14 machines — it triggers Prisma initialization which crashes the entire server:
```yaml
general_settings:
  database_url: ~/.litellm/litellm.db  # ❌ CRASHES on Python 3.14
```

On Python 3.13 or earlier, the Dashboard works fine. On 3.14, use the Swagger UI + curl for all admin operations. The Swagger UI covers key generation, model listing, and spend logs — all the essentials.

The UI/API does NOT support adding/removing model backends — that's a config edit + restart.

## Adding new model providers at runtime

LiteLLM does NOT support adding/removing model backends via API or UI — it requires a config edit + restart. To add a new provider:

1. Edit `~/litellm-config.yaml` on the target machine
2. Add entries to `model_list` (see the general pattern below)
3. `ssh <host> "systemctl --user restart litellm"`
4. Verify with `curl http://<host>:4000/models`

### Quick pattern reference

```yaml
  - model_name: <client-facing-name>
    litellm_params:
      model: <provider>/<model-id>
      api_base: <endpoint>   # optional, only for non-default
      api_key: <value-or-env-ref>  # inline or os.environ/KEY_NAME
```

For full details on OpenCode Go, OpenAI, Anthropic, and custom endpoints, see `references/adding-providers.md` in this skill.

> **Common pitfall:** Users often look for a web UI button to add providers. No such button exists — LiteLLM's Admin Dashboard is read-only for model management. Config edits are the only path. **Explain this upfront before the user wastes time hunting for it.**
>
> **Related user-frustration signal:** When the user asks "how do I add a provider" or "spin up the dashboard," they likely mean one of two things: (a) edit the LiteLLM config to add a new model backend, or (b) open the Hermes Agent dashboard (`hermes dashboard` on port 9119). Ask for clarification BEFORE assuming which one. These are easily confused and the user gets frustrated when you guess wrong.

## Verification checklist

- [ ] `curl http://<host>:4000/health/liveliness` returns `"I'm alive!"`
- [ ] `curl http://<host>:4000/models -H 'Authorization: Bearer <key>'` shows all configured models
- [ ] Chat completion returns a valid response
- [ ] Systemd service auto-starts on boot
- [ ] God profiles updated to use LiteLLM endpoint
