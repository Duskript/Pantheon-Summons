# Python 3.14 LiteLLM Dependency Saga

## Root cause

LiteLLM 1.83.7's `[proxy]` extras pins `orjson==3.10.15` and `uvloop==0.21.0`. Neither has pre-built `.whl` files for Python 3.14. They attempt to compile from source via Rust/PyO3 and `libuv` respectively, both of which fail:

- **orjson** — PyO3 0.23.3 maxes out at Python 3.13; Python 3.14 is too new
- **uvloop** — `libuv` configure script fails (C compiler cannot create executables)

## Fix

Install `litellm` without extras, then add the missing packages individually. The individual packages resolve to newer versions (`orjson==3.11.8`, `uvloop==0.22.1`) that DO have pre-built 3.14 wheels.

## Import error catalog

Each of these errors appeared sequentially as `proxy_server.py` was imported. After fixing each, the NEXT import error would surface. Fix all at once by installing the full dependency set from the skill's Step 2/3.

| Missing Module | Package | Error context |
|---|---|---|
| `websockets` | `websockets` | First import in proxy_server.py |
| `backoff` | `backoff` | Exception handler import |
| `orjson` | `orjson` | JSON serialization — no fallback in code path |
| `jwt` | `pyjwt` | MCP experimental OAuth endpoints |
| `cryptography.x509` | `cryptography` | JWT auth handler |
| `email_validator` | `email-validator` | Pydantic EmailStr field in SCIM models |
| `fastapi_sso` | `fastapi-sso` | SSO management endpoints |
| Various (mcp, polars, etc.) | `mcp`, `polars` | Experimental MCP server integration |

## Verification command

```bash
~/litellm-env/bin/python3 -c "from litellm.proxy.proxy_server import app; print('OK')"
```

Succeeds when ALL deps are present. Fails with `ModuleNotFoundError` for the first missing one if any are absent.

## systemd user service note

On Ubuntu 26.04, user services go to `~/.config/systemd/user/`. Enable with `systemctl --user enable --now litellm`. The service runs as the user, not root — no sudo needed.
