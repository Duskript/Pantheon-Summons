# Adding new model providers to LiteLLM

## Concept

LiteLLM's `model_list` in `config.yaml` maps a `model_name` (what the client/god requests) to a backend provider via `litellm_params`. Adding a new provider means adding one or more entries to `model_list`.

## General pattern

```yaml
model_list:
  - model_name: <what-clients-request>   # e.g. "claude-sonnet-4"
    litellm_params:
      model: <provider-prefix>/<model-id>  # e.g. "anthropic/claude-sonnet-4-20250101"
      api_key: <key-or-env-var>            # inline or os.environ/ANTHROPIC_API_KEY
      api_base: <optional-custom-endpoint> # only for non-default providers
```

### Provider prefixes
| Provider | Prefix | Example |
|----------|--------|---------|
| Ollama | `ollama/` | `ollama/deepseek-v4-flash:cloud` |
| OpenAI-compatible (generic) | `openai/` | `openai/gpt-4o` |
| Anthropic | `anthropic/` | `anthropic/claude-sonnet-4` |
| Google | `gemini/` | `gemini/gemini-2.0-flash` |

For any custom OpenAI-compatible API, use the `openai/` prefix + custom `api_base`.

---

## OpenCode Go — specific guide

### Overview
OpenCode Go (https://opencode.ai/go) is a $5/month subscription giving access to 14 open coding models via an OpenAI-compatible API. Models are hosted in US, EU, and Singapore.

### API endpoint
```
https://opencode.ai/zen/go/v1/chat/completions
```

### Model IDs (no suffix — bare names)
```
minimax-m2.7       minimax-m2.5
kimi-k2.6          kimi-k2.5
glm-5.1            glm-5
deepseek-v4-pro    deepseek-v4-flash
qwen3.6-plus       qwen3.5-plus
mimo-v2-pro        mimo-v2-omni
mimo-v2.5-pro      mimo-v2.5
```

### Config entry (for LiteLLM)
```yaml
  - model_name: opencode/deepseek-v4-flash
    litellm_params:
      model: openai/deepseek-v4-flash
      api_base: https://opencode.ai/zen/go/v1
      api_key: os.environ/OPENCODE_GO_KEY

  - model_name: opencode/kimi-k2.6
    litellm_params:
      model: openai/kimi-k2.6
      api_base: https://opencode.ai/zen/go/v1
      api_key: os.environ/OPENCODE_GO_KEY
```

### Getting a key
1. Go to https://opencode.ai/auth
2. Sign up / login
3. Subscribe to Go ($5 first month, then $10/month)
4. Copy the API key from your account page
5. Set as env var: `export OPENCODE_GO_KEY=<key>` (or put in `~/.env`)

### Usage from a client
```yaml
# In a Hermes profile or any OpenAI-compatible client:
provider: openai
base_url: http://pantheon:4000
model: opencode/deepseek-v4-flash
api_key: sk-pantheon-proxy
```

### Verification
```bash
curl -s https://opencode.ai/zen/go/v1/models | python3 -c 'import json,sys; [print(m["id"]) for m in json.load(sys.stdin)["data"]]'

curl -s https://opencode.ai/zen/go/v1/chat/completions \
  -H "Authorization: Bearer $OPENCODE_GO_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"hi"}],"stream":false}'
```
