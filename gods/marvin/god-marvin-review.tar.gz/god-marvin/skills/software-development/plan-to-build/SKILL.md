---
name: plan-to-build
description: "Full lifecycle from agreed concept to verified implementation — scout, design, plan, build, close. Includes checkpoint system for interruption-safe progress tracking."
version: 1.0.0
author: Hermes
license: MIT
metadata:
  hermes:
    tags: [planning, implementation, workflow, checkpoint, pantheon]
    related_skills: [writing-plans, subagent-driven-development, test-driven-development, requesting-code-review]
---

# Plan → Build

## Overview

The reliable, repeatable workflow for turning a "yeah, let's build that" into running, verified infrastructure. Covers the full lifecycle from idea to done, with a **checkpoint system** so we never lose progress if interrupted mid-stream.

**Core principle:** Every phase has a hard gate. You don't start Phase N+1 until Phase N's exit criteria are met. No skipping.

---

## When to Load This Skill

**Trigger:** The moment Konan says "yeah, build it," "go ahead," "let's do it," or otherwise greenlights a concept after discussion.

This marks the transition from **talking about something** to **building something**. Load this skill immediately — it activates the full lifecycle:
1. Scout what exists (don't assume we know the landscape)
2. Design the architecture
3. Plan the work
4. Build task by task with checkpoints
5. Close with verification and knowledge saved

**Auto-load rule:** If we've been discussing a feature or project and Konan gives the go-ahead, load `plan-to-build` before proceeding. This is now the default path from "let's build" to "done."

**If you're reading this and we're mid-discussion about building something:** you're already past the trigger. Load this skill now and start Phase 0.

**Reference files:**
- `references/thoth-architecture-patterns.md` — condensed knowledge bank on entity-relation graph + Dream Cycle patterns from an open-source reference project. Load when adopting knowledge-graph, entity-extraction, or background-refinement patterns into Pantheon infrastructure.
- `references/knowledge-graph-layer-build.md` — reusable 7-task build sequence for adding a typed entity-relation graph layer to the Athenaeum (extend GraphClient vocab → extraction script → Hades phase → Dream Cycle → cron → MCP tool → docs). Includes SQLite schema quirks, env loading patterns, and pitfall list.

---

## The 5 Phases

```
[Scout] → [Design] → [Plan] → [Build] → [Close]
   ↑          ↑          ↑         ↑          ↑
   └── gate   └── gate   └── gate  └── gate   └── done
```

---

## The Checkpoint System

**Every build gets a checkpoint file** at:

```
.hermes/plans/YYYY-MM-DD-feature-name_CHECKPOINT.md
```

This is your interruption-proof recovery document. **After every completed task**, update it with:

```markdown
# Checkpoint: [Feature Name]
Last updated: 2026-05-07T14:30:00Z

## Status
Total tasks: 12
Completed: 4
In progress: 1 (Task 5)
Blocked: 0

## Task Log
| # | Task | Status | Completed At | Notes |
|---|------|--------|-------------|-------|
| 1 | Scout current state | ✅ Done | 14:00 | Found existing graph.py in scripts/ — will extend |
| 2 | Design graph schema | ✅ Done | 14:15 | Schema designed, Konan approved |
| 3 | Write extraction script | ✅ Done | 14:22 | Tests passing |
| 4 | Wire into cron | ✅ Done | 14:30 | Running at 07:15 daily |
| 5 | Add MCP search tool | 🔄 In progress | — | |
| 6 | Dreamweaver Phase 1 | ⏳ Pending | — | |
| 7 | Dreamweaver Phase 2 | ⏳ Pending | — | |
| ... | | | | |

## File State (track per-task modifications)
- `scripts/extract-entities.py` — created, dry-run verified (967 files)
- `pantheon-core/graph_client.py` — modified (added 18 entity types, 67 relations)
- `graph/graph.db` — fresh, schema recreated
- `.hermes/plans/2026-05-07-graph-layer.md` — plan document

## Next Action
Pick up Task 5: Write dreamweaver.py — script skeleton exists, needs Phase 1 implementation

## Notes
- Konan wanted 67 relations, not trimmed — full Thoth vocabulary
- Entity extraction uses `opencode/deepseek-v4-pro` via litellm
```

### Checkpoint Update Rules

1. **Update AFTER every completed task** — before starting the next one
2. **Update when interrupted** — write current state so resumption is instant
3. **Update when blocked** — note what's blocking and what unblocking looks like
4. **On resumption** — read the checkpoint first, not the plan. It tells you exactly where you are

### Resumption Protocol

If returning to a build after interruption (new session, context loss, etc.):

1. Read the checkpoint file
2. Read the plan file for full task details
3. Start from the **Next Action** listed in the checkpoint
4. If stuck, check **Blocked** notes

---

## Phase 0: Scout 🕵️

**Entry:** Konan says "let's build X" or we agree on a concept
**Gate to exit:** Clear picture of what exists, what's feasible, and the landscape

### Checklist

- [ ] Search filesystem for anything related (`search_files`, `read_file`)
- [ ] Check existing skills that might already cover parts of this
- [ ] Check session history for prior discussion (`session_search`)
- [ ] Read relevant codex files in Athenaeum
- [ ] Check running services, cron jobs, configs
- [ ] Identify potential conflicts with existing infrastructure
- [ ] Document findings: what exists, what doesn't, what patterns to follow

⚠️ **Pitfall: narrow search scope.** Don't assume existing infrastructure lives where you expect it. The Pantheon has code across `pantheon-core/`, `plugins/`, `scripts/`, `athenaeum/scripts/`, gods, and `~/.hermes/`. Search ALL of these before concluding something doesn't exist. In one session, a working `GraphClient` was hiding in `pantheon-core/gods/` while the scout was looking in `athenaeum/scripts/` — cost 5 extra tool calls to discover something that was already built.

⚠️ **Pitfall: assuming SQLite column names match Python code.** When building against an existing SQLite database, check `PRAGMA table_info(tablename)` or `SELECT * FROM tablename LIMIT 1` to discover actual column names before writing queries. The application code may use `type_` as a Python variable name while the SQL column is actually `type`. Similarly, the Python code might reference `entity.name` while the column is `label`. This is a **very** common mismatch in Pantheon infrastructure — the `graph_client.py` uses `type` (col) / `type_` (var) for edges and `label` (col) / `name` (conceptually) for nodes. Always verify with a live query, don't trust the source code's variable names.

### Exit Criteria

- I can describe the current state of the world
- I know what already exists and what needs to be built
- No surprises waiting to ambush us mid-build

### Checkpoint Update

```
- Phase 0 complete
- Existing infrastructure: [summary]
- Files examined: [list]
```

---

## Phase 1: Design 📐

**Entry:** Scout phase complete, landscape known
**Gate to exit:** Konan approves the architecture

### Checklist

- [ ] Sketch architecture: components, data flow, storage, interfaces
- [ ] Define schema / data model (if applicable)
- [ ] Decide: build vs. spike? (If >50% unknowns, spike first)
- [ ] Identify which Pantheon subsystems this touches (cron, MCP, gods, Athenaeum, UI)
- [ ] Write up architecture sketch (brief — a few paragraphs + bullet points)
- [ ] Present to Konan for approval

### Design Principles

- **Build into the Athenaeum, not alongside it** — native infrastructure, not plugins
- **Borrow patterns, don't import code** — Thoth patterns, not Thoth code
- **CRUD before fancy** — get the data model right, optimizations come later
- **One thing well** — each component does one job
- **Start with full fidelity** — when adopting patterns from a reference project, adopt the complete model (all entity types, all relations, all phases). The granularity IS the point — it's what makes the pattern valuable. Premature trimming loses precision and you end up building a worse version of what you already have. Trim only after you have usage data showing which parts aren't needed. (*Lesson: Thoth's 67 relations. Konan rejected trimming to 20.*)

### Exit Criteria

- Architecture is documented and Konan has seen it
- Konan says "yes, build that" (or provides adjustments)
- All major unknowns resolved (if not, spike first)

### Checkpoint Update

```
- Phase 1 complete
- Architecture approved by Konan
- Design document: [path or embedded]
```

---

## Phase 2: Plan 📝

**Entry:** Architecture approved
**Gate to exit:** Plan written to `.hermes/plans/` with checkpoint initialized

### Checklist

- [ ] Break architecture into bite-sized tasks (2-5 min each)
- [ ] Each task has: exact file paths, exact commands, expected outputs, verification steps
- [ ] Tasks ordered: foundation → core → edge cases → polish
- [ ] Write plan to `.hermes/plans/YYYY-MM-DD-feature-name.md`
- [ ] Initialize checkpoint file at `.hermes/plans/YYYY-MM-DD-feature-name_CHECKPOINT.md`
- [ ] Plan references existing skills where relevant (TDD, review, etc.)

### Plan Format

```markdown
# [Feature Name] — Implementation Plan

**Goal:** One sentence
**Architecture:** 2-3 sentences
**Phase 0-1 Reference:** Link or embed design doc

## Tasks

### Task 1: [Name]
**Files:** Create/Modify: [paths]
**Verify:** [command and expected output]
**Details:** [what to do, step by step]

### Task 2: [Name]
...
```

### Verification Rules

Every task must have a **verification step** that proves it works:
- Code task → test command with expected output
- Config task → status check command
- Infra task → health check or log inspection

If you can't write the verification step, you don't understand the task well enough.

### Exit Criteria

- Plan covers all phases of the architecture
- Every task has a verification step
- Checkpoint file exists with all tasks listed (status: pending)
- Tasks are ordered so nothing depends on work not yet done

### Checkpoint Update

```
- Phase 2 complete
- Plan: .hermes/plans/YYYY-MM-DD-feature-name.md
- Checkpoint initialized: .hermes/plans/YYYY-MM-DD-feature-name_CHECKPOINT.md
```

---

## Phase 3: Build 🔨

**Entry:** Plan written and checkpoint initialized
**Gate to exit:** All tasks complete and verified

### Checklist

- [ ] Execute tasks in order (no skipping)
- [ ] Verify each task before moving to the next
- [ ] Update checkpoint after EVERY completed task
- [ ] If interrupted: update checkpoint with current state and next action
- [ ] If blocked: note the blocker in checkpoint, resolve before continuing
- [ ] If a task reveals a design flaw: pause, update design, get Konan's input, update plan, resume

### Build Discipline

- **One task at a time** — no multitasking, no jumping ahead
- **Verify or it didn't happen** — every task needs proof it works
- **Update checkpoint immediately** — before starting the next task
- **If stuck >5 min** — stop, assess, ask Konan if needed
- **No "fix it later"** — later never comes
- **For cron/subprocess scripting:** tools running outside the Hermes session (cron jobs, standalone scripts called by cron, subprocess.run() invocations inside other scripts) don't inherit `~/.hermes/.env` environment variables. Explicitly load the env file with `os.environ.setdefault()` or pass `env=` to `subprocess.run()` with the parsed env dict. The pattern: read `~/.hermes/.env`, split on `=`, strip quotes, copy to a fresh `os.environ.copy()`, pass as `env=`.

### Three Verification Tiers

| Tier | What | When |
|------|------|------|
| Unit | Does the code do what it's supposed to? | Per-task |
| Integration | Do connected pieces work together? | Per-group of related tasks |
| Acceptance | Does it satisfy the Phase 1 goal? | End of Phase 3 |

### When Things Go Wrong

**Task fails verification:**
1. Diagnose (systematic-debugging skill if needed)
2. Fix
3. Re-verify
4. Update checkpoint
5. Continue

**Design flaw discovered:**
1. Stop building
2. Document the flaw
3. Propose fix to Konan
4. Get approval
5. Update plan
6. Resume

**Interrupted mid-task:**
1. Save all work in progress
2. Update checkpoint with exact state of current task
3. Note "Next Action" clearly
4. On return: start from checkpoint

### Exit Criteria

- All tasks: ✅ Done
- All verifications: passing
- Checkpoint shows 100% complete
- No "I'll fix it later" items

### Checkpoint Update

```
After each task:
- Mark task as ✅ Done
- Update "Next Action"
- Note any issues encountered
```

---

## Phase 4: Close 🏁

**Entry:** All tasks built and verified
**Gate to exit:** Konan briefed, knowledge saved

### Checklist

- [ ] Run full system verification (integration test or manual walkthrough)
- [ ] Save memory about what was built and where
- [ ] If the approach was novel or had nontrivial pitfalls → save/update a skill
- [ ] Update any relevant INDEX.md or documentation
- [ ] Brief Konan with summary: what was built, where it lives, how to use it, any caveats

### Close Brief Format

```
## ✅ Build Complete: [Feature Name]

**What was built:**
- [component 1] — what it does, where it lives
- [component 2] — what it does, where it lives

**How to verify it's working:**
[command or check]

**Where to look next time:**
[file paths, config locations]

**Caveats / known issues:**
[anything to watch out for]

**Skill saved:** [skill name if applicable]
```

### Memory to Save

Things worth persisting across sessions:
- File paths to critical components
- Config locations
- How to verify it's working
- Unusual patterns or conventions used
- Konan preferences discovered during the build

Do NOT save task progress, temporary state, or session logs — that's what the checkpoint is for.

### Exit Criteria

- Konan knows what was built and where
- Memory saved for future reference
- Skill saved if the approach was nontrivial
- Checkpoint archived (or stays as record)

---

## Interruption Protocol (Quick Reference)

If you must stop mid-build for any reason:

```markdown
1. Update checkpoint with current task status
2. Note: "Stopped at Task X because [reason]"
3. Set Next Action to the exact step to restart from
4. Save any open files
5. Tell Konan: "Checkpoint at [path], stopped at Task X"
```

On return:

```markdown
1. Read checkpoint
2. Read plan (for task details)
3. Check Next Action
4. Resume from there
```
