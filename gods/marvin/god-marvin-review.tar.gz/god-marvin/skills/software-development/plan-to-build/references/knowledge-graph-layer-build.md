# Knowledge Graph Layer — Build Sequence

A reusable template for adding a typed entity-relation graph layer to the Athenaeum. Used for the Thoth→Athenaeum knowledge graph (2026-05-07).

## Build Sequence (7 tasks, in order)

```
1. GraphClient Vocab → 2. Extraction Script → 3. Hades Integration →
4. Dreamweaver Script → 5. Cron Schedule → 6. MCP Tool → 7. Documentation
```

Each step depends on the previous — no parallel work.

---

## Task 1: Extend GraphClient Vocab

**Goal:** Add entity types, edge types, and banned relation lists to `graph_client.py`.

**Files:** `pantheon-core/gods/graph_client.py` + `plugins/pantheon/graph_client.py` (keep synced)

**Steps:**
1. Add `NODE_TYPE_*` constants for each entity type
2. Add to `VALID_NODE_TYPES` set
3. Add `EDGE_TYPE_*` constants for each relation type
4. Add to `VALID_EDGE_TYPES` set
5. Add `BANNED_EDGE_TYPES` set (vague relations to reject)
6. In `add_edge()`, add a check: `if type_ in BANNED_EDGE_TYPES: raise ValueError(...)`
7. Remove the SQL CHECK constraint on `nodes.type` (it's validated in Python — removing it avoids migration headaches when adding types)
8. Apply identical changes to `plugins/pantheon/graph_client.py`
9. Delete old `.hermes/pantheon/graph.db` if schema changed (SQLite doesn't alter CHECK constraints)

**Verify:** `python3 -c "from gods.graph_client import GraphClient, VALID_NODE_TYPES, VALID_EDGE_TYPES, BANNED_EDGE_TYPES; ..."` — add a few test entities + edges, query them back.

---

## Task 2: Write Extraction Script

**Goal:** LLM-based entity/relation extraction from Athenaeum files.

**Files:** `athenaeum/scripts/extract-entities.py`

**Pattern (replaces reembed-athenaeum.py pattern):**
1. Walk Athenaeum files (same file-walking logic as `reembed-athenaeum.py` — skip INDEX.md, archive/, distilled/, sessions/)
2. Track checkpoint at `~/.hermes/pantheon/extract-checkpoint.json` (file mtime-based)
3. For each modified file: read content, send to LLM with structured prompt requesting JSON
4. Parse JSON, filter by confidence floor (0.80), cap entities (12/doc)
5. Save to GraphClient with deterministic slugs (lowercase, hyphens, max 60 chars)
6. Link each extracted entity to its source file via `mentions` edges

**LLM prompt structure (system + user):**
- System: defines all valid entity types, valid relation types, banned relation types, rules (0.80 floor, 12 max, directional, explicit only)
- User: file content (truncated to 32K chars)
- Temperature: 0.1 (consistent extraction)

**Key patterns:**
- Load `~/.hermes/.env` at module level for cron compatibility
- Dry-run flag (`--dry-run`) that skips LLM calls and just lists files
- Force flag (`--force`) to reprocess all files regardless of checkpoint
- Progress logging every 25 files with periodic checkpoint saves

**Verify:** `python3 extract-entities.py --dry-run` — should list all files without making LLM calls

---

## Task 3: Wire into Hades

**Goal:** Extraction runs as part of Hades' nightly consolidation.

**Files:** `pantheon-core/gods/hades.py`

**Pattern:**
1. Add `extraction` field to `HadesReport.__init__` (files_processed, files_failed, entities_extracted, relations_extracted, error)
2. Add extraction data to `to_dict()` and `to_markdown()` methods
3. Add as a new Phase (e.g., Phase 4) in `run_hades()` — call `extract-entities.py` via `subprocess.run()` with a 20-minute timeout
4. Pass env vars from `~/.hermes/.env` to subprocess
5. Parse stdout for extraction summary lines (`Total entities extracted:`, `Total relations extracted:`, etc.)
6. Update mailbox delivery to include extraction stats in summary

**Cron env pattern:**
```python
_ENV_FILE = Path(f"{_REAL_HOME}/.hermes/.env")
env = os.environ.copy()
if _ENV_FILE.exists():
    for line in _ENV_FILE.read_text().split("\n"):
        line = line.strip()
        if line and "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip().strip("'\"")
result = subprocess.run([sys.executable, script], capture_output=True, text=True, timeout=1200, env=env)
```

---

## Task 4: Write Dreamweaver (5-Phase Dream Cycle)

**Goal:** Background refinement of the knowledge graph — runs daily after extraction.

**Files:** `athenaeum/scripts/dreamweaver.py`

**5 Phases:**

| Phase | Action | Details |
|-------|--------|---------|
| 1. Merge | Entity dedup | Group by normalized name, merge duplicates (keep richer one, redirect edges) |
| 2. Enrich | Reverse edges | Add reverse direction for non-symmetric edges using a mapping table (depends_on↔required_by, uses↔used_by, etc.) |
| 3. Decay | Confidence aging | Multiply all edge weights by 0.98. Purge < 0.20. Flag < 0.80. |
| 4. Infer | Transitive closure | 2-hop inference for transitive types (depends_on, part_of, contains, triggers). Inferred confidence = min(w1,w2) × 0.75. |
| 5. Insights | Graph summary | Count nodes/edges by type, find top-10 most connected entities. |

**Key SQLite schema facts:**
- Node column is `label` (not `name`)
- Edge column is `type` (not `type_`)
- Node types: `person`, `project`, `concept`, `tool`, `system`, `organization`, `place`, `event`, `decision`, `preference`, `media`, `skill`, `fact` + system types: `file`, `session`, `entity`, `codex`, `url`

**Verify:** `python3 dreamweaver.py --dry-run` — all 5 phases run without errors

---

## Task 5: Create Cron Schedule

**Pattern:** Use the `cronjob` tool, not system crontab.
- Set a descriptive name
- Set schedule in cron format
- Include enough context in the prompt for the script to run independently
- Reference relevant skills (e.g., `pantheon-operations`)
- Verify with `cronjob list`

---

## Task 6: Add MCP Search Tool

**Goal:** Expose graph search as an MCP tool accessible to all gods.

**Files:** `pantheon-core/mcp_server.py`

**Search modes (mutually exclusive — use ONE at a time):**
1. `query` — keyword search on node labels and metadata
2. `entity_type` — filter by type
3. `entity_name` — LIKE search on label
4. `neighbor_of` — BFS neighbors with direction (incoming/outgoing)
5. `path_between` — shortest BFS path between two node IDs

**Pattern:**
```python
@mcp.tool(
    description="...",
)
def athenaeum_graph_search(...) -> str:
    # Import GraphClient, connect, set row_factory = _dict_factory
    # Execute based on which mode arg is set
    # Return JSON results
```

**Needed helpers:** Add `_dict_factory(cursor, row)` if not already defined:
```python
def _dict_factory(cursor, row):
    return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}
```

---

## Task 7: Create Documentation

**Files:** `athenaeum/graph/INDEX.md`

**Content:** Entity types table, relation types table by category, pipeline diagram, schema reference, banned relations list.

---

## Common Pitfalls

1. **Column name mismatch:** Always check `PRAGMA table_info(tablename)` before writing SQL queries. The Python code variable names and SQL column names differ in `graph_client.py` (see Task 4 above).

2. **Plugin sync:** Changes to `pantheon-core/gods/graph_client.py` must be duplicated in `plugins/pantheon/graph_client.py`. They are separate files, not symlinks.

3. **Env for subprocess/cron:** Scripts that need `OPENROUTER_API_KEY` or other env vars must load `~/.hermes/.env` explicitly when called from cron or via `subprocess.run()`.

4. **DB schema migration:** SQLite `CREATE TABLE IF NOT EXISTS` won't update an existing table's CHECK constraint. Solution: validate in Python, and delete the old DB file if schema changed.

5. **Phase 5 (Insights) is read-only** — it queries the graph but must still handle an empty graph gracefully.
