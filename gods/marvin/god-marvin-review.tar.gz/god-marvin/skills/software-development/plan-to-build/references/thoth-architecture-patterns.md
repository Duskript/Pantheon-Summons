# Thoth Architecture Patterns — Reference

**Source:** [github.com/siddsachar/Thoth](https://github.com/siddsachar/Thoth) (Apache 2.0, ~1018 stars)
**Date researched:** 2026-05-07
**Context:** Adopting knowledge-graph + Dream Cycle patterns into Pantheon's Athenaeum

---

## Entity Model

**10 entity types:** `person`, `preference`, `fact`, `event`, `place`, `project`, `organisation`, `concept`, `skill`, `media`

Each entity has: id, type, subject, description, aliases, tags, source (origin tag), confidence, created_at, updated_at.

**67 typed directional relations** with 60+ alias mappings. Vague types are BANNED: `related_to`, `associated_with`, `connected_to`, `linked_to`, `has_relation`, `involves`, `correlates_with` — all rejected before save.

Document-specific relations: `extracted_from`, `uploaded`, `builds_on`, `cites`, `extends`, `contradicts`.

Storage: Local SQLite + NetworkX (for traversal) + FAISS (for semantic search).

---

## Dream Cycle (5-Phase Background Refinement)

Runs during quiet hours (default 1-5 AM), checks every 30 min, once per day.

| Phase | What | Thresholds |
|-------|------|-----------|
| 1. Duplicate Merge | Entities with same type + ≥0.93 embedding similarity get merged; LLM synthesizes best description, aliases unioned, relations re-pointed to survivor | 0.93 similarity; 0.98 if different normalized subjects |
| 2. Description Enrichment | Entities with <80 char descriptions get richer descriptions from conversation context and neighborhood | 80 char threshold |
| 3. Confidence Decay | `dream_infer` relations >90 days old lose 10% confidence per cycle; pruned at floor | 90 days, 10% decay |
| 4. Relation Inference | Co-occurring entity pairs with no edge evaluated for typed relation; hub caps, batch rotation, half-overlap reuse, multi-excerpt evidence, 7-day rejection cache | 7-day rejection cache |
| 5. Insights Generation | Captures snapshot of logs, config, state → runs through LLM → stores categorized insight objects | Categories: error_pattern, skill_proposal, tool_config, knowledge_quality, usage_pattern, system_health |

Anti-contamination: 3-layer — sentence-level excerpt filtering, deterministic post-enrichment validation, strengthened prompting.

Busy check: queries Ollama `/api/ps` before starting; defers if actively serving user.

Output: `~/.thoth/dream_journal.json` with cycle ID, summary, duration, merges, enrichments, inferences, insights, errors.

---

## Graph-Enhanced Auto-Recall

**Flow:** semantic query (FAISS) → resolve entities → 1-hop graph expansion → surface connected neighbors with relationship context

Entities recalled include their IDs so the agent can update/delete specific entries when user corrects previously saved information.

Memory tool has 7 sub-tools: save, search, list, update, delete, link (create relations), explore (traverse graph).

---

## Entity Extraction Pipeline

**Live extraction:** Background process scans past conversations every 6 hours. Active/workflow threads excluded. Assistant messages truncated to 200 chars to prevent extracting from AI-generated content. 0.80 confidence floor.

**Document extraction:** 3-phase map-reduce LLM pipeline:
1. Map: document split into ~6K-char windows, each summarized to 3-5 sentences
2. Reduce: window summaries combined into coherent 300-600 word article
3. Extract: core entities + relations pulled from final article; capped at 12 entities per document

Cross-window dedup, cross-source merge protection (stricter threshold when document content resembles personal entity), per-document cleanup.

---

## Key Design Choices

- **Source tracking:** Each entity tagged with origin (`live`, `extraction`, `dream_*`, document-derived) for diagnostics
- **Deterministic deduplication:** Check for existing entities by normalized subject before creating new entries; cross-category matching prevents fragmentation; richer content always kept
- **Alias resolution:** Related names merge correctly; alias resolution before ban/confidence/dedup checks
- **LLM for extraction, not rule-based:** Extraction quality depends on model quality — 14B+ local or provider models
- **Post-cycle rebuilds:** FAISS rebuilt after Dream Cycle; wiki vault regenerated when enabled
- **Feature parity:** All features work with local models first; providers are opt-in

---

## Relationship to Pantheon

Pantheon already has `GraphClient` at `pantheon-core/gods/graph_client.py` with SQLite backend + BFS/neighbor traversal + FTS5 search. What Thoth adds:
- Full typed hierarchy (10 specific entity types vs 6 generic)
- 67 relation vocabulary vs 8 generic edge types
- Dream Cycle for ongoing refinement
- Entity extraction pipeline
- Graph-enhanced MCP search recall
- Source/confidence tracking on every entity and relation
