---
name: spec-retrofit-planning
description: "Plan a retrofit of existing code to meet an external spec/PRD: audit the codebase, map concepts to reality, collapse already-done phases, and produce a gated phase plan."
version: 1.0.0
author: Hermes
license: MIT
metadata:
  hermes:
    tags: [planning, retrofit, spec, prd, codebase-audit, phased-implementation, gating]
    related_skills: [writing-plans, plan, spike, codebase-inspection]
---

# Spec Retrofit Planning

**When you have an existing application and an external spec/PRD — map one to the other, discover what's already done, and produce a gated phase plan for the rest.**

## Overview

This is the planning methodology for **retrofitting** an existing system to meet new specification requirements. It's NOT for greenfield features (use `writing-plans`) or throwaway experiments (use `spike`). It's for the situation where:

- You have a working application
- Someone hands you a PRD, spec, design doc, or requirements document
- You need to figure out: what's already done? what needs changing? what's the right order?

This methodology was developed while mapping the Pantheon Workspace PRD (written for a React/Electron app) onto the existing Hermes Web UI (vanilla JS, Python backend, already responsive). The PRD described 12 phases, but Phases 0-2 were already implemented by the existing architecture.

## When to Use This Skill

**Load this when:**
- User provides an external spec/PRD/requirements doc
- User asks to "map this spec to existing code"
- User says "we got a design doc, figure out what needs to change"
- User shares a ChatGPT/Claude-generated PRD and wants implementation plan
- User asks "how does this spec apply to what we already have?"

**Don't use this for:**
- Greenfield features with no existing codebase (use `writing-plans`)
- Measuring code metrics like LOC (use `codebase-inspection`)
- One-off throwaway validation (use `spike`)
- Pure plan-mode with no exploration (use `plan`)

## The Methodology (10 Steps)

### Step 1: Intake the Spec

Read the full spec/PRD. Extract the core concepts and their definitions. Create a **concept dictionary** — the nomenclature the spec uses:

```markdown
| Spec Term | Definition | Example |
|-----------|------------|---------|
| Communion | A renamed session/conversation | Session → Communion |
| Boon | A renamed artifact/output | Artifact → Boon |
| Invoke | Starting a specialist god | Profile switch became god activation |
```

Pay attention to **rename operations** vs **new functionality**. The spec may conflate both.

### Step 2: Audit the Existing Codebase

Systematically explore the codebase. Don't assume — verify. The goal is to understand what structures exist and what they currently do:

**For web UIs:**
```
# Read the index.html — DOM structure tells you everything
read_file("static/index.html")
# Read the CSS layout — grid, panels, responsive breakpoints
read_file("static/style.css")
# Read the JS files — panel switching, session management
read_file("static/panels.js")
grep for specific patterns
```

**For backend APIs:**
```
# List API routes
search_files("routes.py|urls.py|api/")
# Read key route files
read_file("api/routes.py")
```

**For system architecture:**
```
# Understand file structure
search_files("*", target="files", path="root/")
# Check dependencies / config
read_file("package.json", "config.yaml")
```

Consider these dimensions of "the current state":
- **Layout** — how is the page structured? panels? responsive breakpoints?
- **Data models** — what objects exist? what fields do they have?
- **API surface** — what endpoints exist? what data flows?
- **State management** — how does the UI track state?
- **I18n** — how are labels managed? is there a string file?
- **Build system** — is there a build step? bundler?
- **PWA behavior** — manifest, service worker, offline mode?

### Step 3: Create the Concept Mapping Table

For each term/concept from the spec, create a row in a mapping table:

| Spec Concept | Web UI Equivalent | Gap | Action |
|---|---|---|---|
| Spec term X | `existing_element` or API concept | Exists as-is / Exists but renamed / Missing entirely / Partially done | Rename / Build / Enhance / No action |
| ... | ... | ... | ... |

**Gap types:**
- ✅ **Exists as-is** — no changes needed
- 🏷️ **Exists, needs rename** — change labels only
- 🔧 **Partially exists** — existing foundation, needs expansion
- 🆕 **Missing** — needs to be built from scratch
- 🗑️ **Not applicable** — spec assumed different tech stack

### Step 4: Audit Each Phase Against Reality

Take each phase from the spec's original plan. Audit it:

```
| Original Phase | Audit Result | Reasoning |
|---|---|---|
| Phase 0 — Repo stripping | ✅ Already done | We're using existing Web UI, not forking |
| Phase 1 — Responsive shell | ✅ Already done | Three-panel PWA already exists |
| Phase 2 — Communion chat | 🔧 Needs rename only | Chat system exists, labels need changing |
| Phase 3 — God roster | 🆕 Needs building | No god concept exists in current UI |
```

### Step 5: Collapse the Phases

Remove phases that are already done. Reorder/regroup what remains. This is the critical insight: **many spec phases may already be fully or partially implemented by the existing codebase.**

Collapse like this:
- ✅ **Done** → remove from implementation plan, note as assumption
- 🔧 **Partial rename** → group into a single "naming layer" phase
- 🔧 **Partial enhance** → keep as scaled-down phase
- 🆕 **New** → keep as-is

The result is often dramatically fewer and simpler phases than the original spec described.

### Step 6: Set Phase Gates

Each phase must have **binary exit criteria** — pass/fail conditions that must be 100% met before the next phase starts.

**Good exit criteria:**
```
| Phase A | All labels use spec terminology | All visible UI surfaces checked | App runs with no errors |
```

**Bad exit criteria:**
```
| Phase A | Most of the renaming is done | | |
```

Gate rules:
1. No phase begins until previous phase's exit criteria are 100% met
2. Each phase has a task checklist — ALL must complete
3. Exit criteria are binary: pass or fail
4. Blockers are logged before they halt progress

### Step 7: Create Element-by-Element Layout Map (for UI retrofits)

For UI work, this is critical. Map every single element in the current layout to its new role:

```
#### Top Bar (.app-titlebar)
| Current | New | Notes |
|---|---|---|
| Title: "Hermes" | Title: "Pantheon" | App name changes |
| Sub: session info | Sub: active god + session | Shows "Hermes · Main Hall" |
| — | New: 💡 Ideas button | Left side |
```

Go section by section through the actual DOM:
1. Top bar / header
2. Navigation (rail, sidebar tabs, hamburger menu)
3. Sidebar panels (list each one)
4. Main workspace views (list each one)
5. Composer toolbar (if applicable)
6. Right panel / drawers
7. Modals, overlays, dialogs
8. Mobile behavior for each of the above

### Step 8: Document Architecture Invariants

Extract the rules from the spec AND from the codebase that must never be violated:

```
1. Do not collapse X, Y, and Z into one backend
2. Keep the PWA-first approach
3. Keep mobile first-class
4. X remains always-on (never sleepable)
5. Specialist Ys are lazy-loaded
6. Only one agent works on a file group at a time
7. Current tech stack stays (no framework migration)
```

These are your guardrails against scope creep and architectural drift.

### Step 9: Twin-Save the Reference Document

Save the comprehensive design reference in **two places**:

1. **Workspace** — `~/workspace/PROJECT-UI-DESIGN.md` (local reference, easy to edit)
2. **Athenaeum** — `Codex-{domain}/path/to/design-reference.md` (permanent archival)

The workspace copy is for active development. The Athenaeum copy is for recall across sessions and by other gods.

Also save a **phase tracking worklog**:
```
# Project Name — Phase Tracking Worklog

## Active Phase
**Phase A — Naming Layer** (🟡 Not started)

## Phase A Checklist
- [ ] Task 1
- [ ] Task 2

## Blockers
| # | Phase | Description | Status | Resolution |
|---|---|---|---|---|
```

### Step 10: Update Memory

Save a compact summary to memory covering:
- What base application is being retrofitted
- What the target spec is
- The collapsed phase list
- Where design reference and worklog live
- Key architecture invariants

This ensures next session starts with context even without the full document.

## Example Workflow

This skill was created after this exact workflow was applied to the Pantheon PRD on 2026-05-07. The session:

1. Received a 12-phase PRD generated by ChatGPT for "Pantheon Workspace" (React/Electron fork)
2. Audited the actual Hermes Web UI codebase (vanilla JS, Python)
3. Discovered Phases 0-2 (repo stripping, responsive shell, mobile PWA) were already done
4. Mapped 12 spec concepts (Communion, Boon, Invoke, Forge, Athenaeum, etc.) to existing implementation
5. Collapsed to 8 phases (A-H) with hard completion gates
6. Created element-by-element DOM mapping (27 elements across 8 sections)
7. Documented 10 architecture invariants
8. Saved to both workspace (`PANTHEON-UI-DESIGN.md`) and Athenaeum (`Codex-Pantheon/constitution/`)
9. Created phase tracking worklog (`PANTHEON-WORKLOG.md`)
10. Updated memory with compact summary

## Pitfalls

### Assuming the spec is accurate
Specs (especially PRDs from LLMs) often assume a particular tech stack or architecture. Always verify assumptions against actual code.

### Over-respecting the spec's phase structure
The spec's original phase ordering may assume greenfield development. Your existing codebase has different starting conditions — collapse aggressively.

### Forgetting the rename layer
Many spec concepts are just renames of existing functionality. Don't build new systems for renames. Group all renames into a single "naming layer" phase.

### Missing the mobile view
For UI retrofits, always document how each section behaves on mobile (< 640px). The desktop layout is only half the picture.

### Not checking for architecture assumptions
Specs often describe things like "keep X running as a service" or "use Y as the backend" — verify that the existing architecture actually supports these assumptions before planning.

## Output Checklist

- [ ] Concept dictionary extracted from spec
- [ ] Codebase audit complete (structure, DOM, API, data models, i18n, build, PWA)
- [ ] Concept mapping table created (every spec concept mapped)
- [ ] Phase audit done (each original phase checked against reality)
- [ ] Collapsed phases defined with binary exit criteria
- [ ] Element-by-element layout mapping (for UI retrofits)
- [ ] Architecture invariants documented
- [ ] Design reference saved to workspace AND Athenaeum
- [ ] Phase tracking worklog created
- [ ] Memory updated with session summary

## Related Skills

- **writing-plans** — For greenfield feature plans (use AFTER this skill if a phase needs detailed implementation tasks)
- **codebase-inspection** — For deeper metrics on codebase (LOC, language ratios)
- **plan** — For pure plan-mode with no execution
- **spike** — For throwaway experiments during planning

## Attribution

Developed during the Pantheon UI design session (2026-05-07) where a 12-phase ChatGPT-generated PRD was mapped onto the existing Hermes Web UI and collapsed to 8 gated phases.
