# Example: Pantheon UI Retrofit Planning (2026-05-07)

This reference documents the actual execution of the `spec-retrofit-planning` methodology. The full design document is at:
- `~/workspace/PANTHEON-UI-DESIGN.md`
- `Athenaeum → Codex-Pantheon/constitution/pantheon-ui-design.md`

## Source Spec

A 12-phase ChatGPT-generated PRD for "Pantheon Workspace" — a PWA fork of Hermes Workspace (React/Electron). The PRD described:
- Repo stripping & baseline (Phase 0)
- Responsive shell layout (Phase 1)
- Communion chat integration (Phase 2)
- God roster & switching (Phase 3)
- God invocation lifecycle (Phase 4)
- Boon drawer (Phase 5)
- File uploads & chat blocks (Phase 6)
- Athenaeum integration (Phase 7)
- Forge integration (Phase 8)
- Ideas, notifications & health (Phase 9)
- Marketplace / God import (Phase 10)
- Polish, testing & hardening (Phase 11)

## Actual Codebase

**Hermes Web UI** (`~/hermes-webui/`, nesquena build):
- Vanilla JS + Python + static HTML
- Already responsive PWA with three-panel layout
- 32MB, no build step
- Session management, workspace browser, cron, skills, memory, profiles, kanban
- Composer with attach, model switching, reasoning, ctx indicator
- Mobile: drawers/sheets at < 641px

## Key Discovery

The PRD assumed building from scratch. The existing Web UI already had:
- ✅ Responsive three-panel layout (desktop: rail + sidebar + main + rightpanel)
- ✅ PWA manifest + service worker
- ✅ Mobile responsive with overlay drawers
- ✅ Session management with projects, pins, archive
- ✅ File uploads and attachment chips
- ✅ Code block rendering with syntax highlighting

**Phases 0, 1, and 6 were already done.** The 12-phase PRD collapsed to 8.

## Concept Mapping (Condensed)

| Spec Term | Reality | Action |
|---|---|---|
| Communion (session) | Existing session management | Rename labels only |
| God (profile) | Existing profile system | Add avatars + states |
| Invoke/Sleep | No runtime lifecycle | Build API + UI |
| Boon (artifact) | Chat messages only | New drawer |
| Forge (workspace) | File browser exists | Rebrand + add task mgmt |
| Athenaeum (knowledge) | Memory panel (raw text) | Rebuild as codex browser |
| Ideas | Nothing | New feature |
| Notifications | Toast only | New persistent panel |
| Health | Gateway in settings | New popup |

## Element Mapping Count

8 layout sections mapped with 27 total element mappings:
1. Top bar (5 elements)
2. Left rail (12 elements → 10 keep + 2 remove + 1 new)
3. Sidebar panels (10 panels → 7 keep, 2 rebrand, 1 move)
4. Main views (10 views → 4 keep, 2 rebrand, 1 rebuild, 2 new)
5. Composer footer (9 elements → 1 rebrand)
6. Right panel (5 elements → 1 dual-mode)
7. Mobile nav (5 overlays)
8. Modals (3 keep)

## Architecture Invariants (10 Rules)

1. Don't collapse Hermes, Pantheon, Athenaeum into one backend
2. Don't aggressively rename internals until adapter boundaries stable
3. Keep PWA-first (no framework rebuilds)
4. Keep mobile first-class
5. Hermes always-on (never sleepable)
6. Specialist gods lazy-loaded (30min idle shutdown)
7. One agent per file group
8. Vanilla JS stays (no React/Vue/Svelte)
9. Six JS files stay as backbone
10. CSS variables for god theming

## Gated Phases (Final)

| Phase | Gone? | Exit Criteria |
|---|---|---|
| A — Naming Layer | ✅ | All labels use Pantheon terms, app runs |
| B — God Roster | Must build | Hermes/Hephaestus/Apollo visible with identities |
| C — God Lifecycle | Must build | Invoke/sleep works, states visible |
| D — Boon Drawer | Must build | Structured outputs with pin/export |
| E — Athenaeum | Must build | Codex tree + semantic search |
| F — Forge | Must build | Boons → tasks, project tracking |
| G — Ideas/Health | Must build | Ideas, notifs, health popup |
| H — Marketplace | Future | Not detailed |
