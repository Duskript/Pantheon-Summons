---
name: portfolio-audit
description: Survey everything the user has built, catalog their skills and projects, and produce a career-positioning profile. Triggered when user asks for a job search, skills inventory, or "what have I built" review.
---

# Portfolio Audit

When a user asks "what have I built," "help me look for a job," "catalog my skills," or any variant of taking stock — run this comprehensive audit process.

## Process

### Phase 0: Import Recent Conversations (if available)

Before auditing, check for unimported Claude/chat exports. Recent conversations contain the most current project work and skill context.

1. **Check for pending exports** — look in `~/.hermes/cache/documents/` for `.zip` files, or ask the user if they have recent exports
2. **Import through Athenaeum pipeline** — run `pantheon-import-claude` with `--skip-existing`
3. **Handle projects separately** — recent Claude exports may have projects as individual files in `projects/` dir rather than `projects.json`. Use the helper script: `python3 /home/konan/.hermes/skills/pantheon/pantheon-operations/scripts/extract-claude-projects.py <export.zip>` (classifies by name, routes to correct Codex reference dir).
4. **Re-embed** — run `reembed-athenaeum.py` to index new content (needs OPENROUTER_API_KEY passed explicitly)
5. **Verify** — check `mcp_pantheon_athenaeum_walk` for the new files

This step ensures the audit reflects the user's most current work, not stale data.

### Phase 1: System Health Baseline

Before cataloging content, verify the infrastructure is healthy:

```python
# Run these tools:
mcp_pantheon_system_health()  → checks ChromaDB, Athenaeum, embeddings, messaging
mcp_pantheon_athenaeum_walk("INDEX.md")  → root-level codex listing
```

If system health is red, fix before proceeding — a corrupted knowledge base means incomplete data.

### Phase 2: Knowledge Store Walk

Walk the full index tree, starting from root and diving into each codex:

1. **Root INDEX.md** — get the codex list and descriptions
2. **Key codices** — always walk these in depth:
   - `Codex-Forge` — project blueprints, planning sessions, specs
   - `Codex-Pantheon` — system docs, constitution, projects tracker
   - `Codex-Infrastructure` — homelab, networking, Proxmox
   - `Codex-User` — profile, work context, relationships
   - `Codex-Work` — job context, Jira workflows, professional history

3. **Supporting codices** — skim for relevant projects:
   - `Codex-Apollo` — creative/methodology work
   - `Codex-SKC` — music projects
   - `Codex-General` — uncategorized notes
   - `skills/` — any skill definitions in the Athenaeum

4. **Deep dive** — for each codex with substantial content:
   - Read INDEX.md
   - List subdirectories and files
   - Check `distilled/` directories (Hades-consolidated knowledge)
   - Check `blueprints/` for project specs
   - Check `reference/` for documented projects

### Phase 3: Vector Search

Use semantic search to surface content the walk might miss:

```python
mcp_pantheon_athenaeum_search(query="job work skills experience")
mcp_pantheon_athenaeum_search(query="projects built tools automation")
mcp_pantheon_athenaeum_search(query="<domain-specific terms>")
```

### Phase 4: Profile & Context

Read the user's profile to establish current job, skills, history:

- `Codex-User/profile/claude-profile.md` — contains work context, skills, personal background
- `Codex-Pantheon/projects.md` — living project tracker with active/planned/ideas
- `Codex-User/work/` — work-specific references
- Any `claude-user.json` for basic identity info

### Phase 5: Catalog Construction

Build a structured inventory organized by **domain**:

```
## Domain: {Infrastructure / Software / Creative / etc.}

**Current Role:** {one-line summary of current job}

**Projects Built:**
- {Project name} — {what it does, key metrics (LOC, files, services)}
- ...

**Technical Skills:**
- {Skill area}: {detail, years of experience, proficiency level}
- ...

**Market Differentiators:**
- {Skills that stand out beyond the current role}
- ...

**Potential Job Titles (ascending seniority):**
- {Title} — {why it fits}
- ...
```

### Phase 6: Market Positioning Brief

Present the findings as a structured report:

1. **System health verdict** — ✅/⚠️/❌ with details
2. **Domain-by-domain catalog** — what they've built per area
3. **The gap analysis** — where their skill level exceeds their current role (this is the key insight)
4. **Role mapping** — 3-5 job titles they could target, with rationale
5. **Next steps** — what they need (resume polish, portfolio piece, skills gap)

## Output Format

Present as a Telegram-friendly structured message:

- Bullet lists, not tables
- Clear ✅/⚠️/❌ status indicators
- Bold for key numbers and role titles
- Brief, punchy sections — no prose paragraphs
- End with an open question: "Want me to drill into X, Y, or Z next?"

## Edge Cases

- **Empty work codex** — the user may not have documented their job. Use their profile from other codices (Codex-User, Codex-Pantheon) and vector search to fill gaps.
- **Many small projects** — group into domains rather than listing individually. The catalog is a portfolio, not a file list.
- **User is self-employed/freelancer** — treat their client work as "projects" under a "Consulting" domain.
- **User wants a resume, not an audit** — transition from audit to resume writing by asking: "I have your skills cataloged. Want me to draft a resume targeting {role X}?"

## Pitfalls

- **Don't claim a skill exists just because a file references it.** Verify: the user wrote the code, discussed the concept, or shipped the project. Imported conversations about wanting to learn something ≠ skill.
- **Don't over-interpret "intermediate" coding.** If the user self-describes as "intermediate Python," don't list them as "Python Developer." Stay honest to their self-assessment.
- **Don't ignore the work codex even if it's thin.** The user's day job often has the most concrete deliverables. Everything else is side projects.

## References

| File | Contents |
|------|----------|
| `references/konan-2026-05-audit.md` | Full portfolio audit output for Konan (May 2026) — example of completed audit format |
