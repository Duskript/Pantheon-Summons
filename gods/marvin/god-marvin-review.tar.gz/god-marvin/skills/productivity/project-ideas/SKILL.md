---
name: project-ideas
description: "Manage a curated list of project ideas stored in ~/pantheon/project-ideas.md. Add, list, update, organize, and remove ideas."
version: 1.2.0
---

# Project Ideas Manager

Manages a living markdown document at `~/pantheon/project-ideas.md` containing Konan's project ideas for things to build or add to the Pantheon system.

Both Hermes (me) and Hephaestus maintain this file. Hephaestus' SOUL includes housekeeping duty — he is expected to proactively update statuses when things wrap up, without being told.

## File Section Structure

The file uses these top-level sections (exact entries vary):

```markdown
## 🏗️ Pantheon — Core Architecture
  ### Entry Name — Subtitle
  ### ...
## 🏛️ God Roster (Planned)
  ### God Name — Role
  ### ...
## 🏛️ Greek System Gods (Built into Pantheon Core)
  (Table of system-level architecture gods)
  ### Multi-User Pantheon Architecture
## 💼 Work Projects
  ### ...
```

Each entry uses `### Idea Name` with bullet metadata:

```markdown
### Pantheon Bridge — Inter-God Communication Layer
- **Status:** idea | planning | in-progress | shelved | done
- **Tags:** #pantheon-core #architecture
- **Added:** YYYY-MM-DD
- **Notes:** Design decisions, architecture notes, constraints.
```

## Commands for Konan

| You say | I do |
|---------|------|
| "Save this idea:..." | Append new under appropriate section |
| "What ideas do I have?" | Read + summarize by section × status |
| "Mark X as in-progress" | Update status field |
| "Mark X as done" | See status rules below |
| "Remove the Y idea" | Delete entry + scrub cross-references |
| "Show me my ideas by priority" | Order: in-progress > planning > idea > shelved |
| "Update the notes on X" | Edit Notes field with new design decisions |
| "Notify Hephaestus about X" | Send via Pantheon Bridge (MCP primary, filesystem fallback) |

## Status Rules (⚠️ Important!)

**Two modes for marking things done — and you must decide which:**

1. **Reference entries** (architecture layers, design decisions, infrastructure specs) → set status to `done` but **keep the entry**. These hold permanent design notes, architecture decisions, and cross-context context that shouldn't be lost. Look for: detailed Notes sections, cross-references to other entries, dependency mentions. Examples: Pantheon Bridge, God SDK, Rebrand.

2. **Task entries** (a specific project, a tool, a one-off build) → **remove entirely** when marked done. Scrub ALL cross-references (tables, other entries' Notes fields, god rosters, system gods tables, data flow diagrams).

When in doubt, leave the entry and just update status. Konan will tell you if he wants it removed.

**Heuristic:** entries under "Pantheon — Core Architecture" with detailed design notes are reference entries. Entries that read like "build X" or "create Y" are task entries.

## Workflow: Notify Hephaestus, Don't Just Edit

When you update the project-ideas file on Konan's behalf (status changes, removals, new info), **also send a message to Hephaestus** via the Pantheon Bridge summarizing what changed and why. Konan expects both: the file update for record, and the bridge message so Hephaestus learns the pattern.

Include enough detail in the bridge message that Hephaestus can replicate the same judgment next time (e.g., "Pantheon Bridge → done, kept as reference entry since it holds architecture decisions").

## Proactive Maintenance Directive (from Konan)

Do NOT wait for Konan to point out stale statuses. When you finish a project, update its entry immediately. When you learn something was completed, update it. Hephaestus has the same directive in his SOUL — both gods are expected to keep the list current without prompting.

The skill of noticing what's done and updating accordingly is more important than the mechanical steps of editing a markdown file.

## Workflow

1. New ideas default to **Status:** `idea`, appended at bottom of their section
2. Always tag ideas (#pantheon-core, #god, #tool, #workflow, #architecture, etc.)
3. When Konan elaborates with design decisions, update Notes to capture them
4. When cleaning up removed task entries: do a full-file scan for dangling references
5. Correct old placeholder names (e.g. "Cyber") when encountered — user's name is Konan
6. If status changes on an architecture entry also impact other entries' dependency notes (e.g. God SDK → done means Rebrand's notes about "depends on God SDK" should be updated), update those too

## Integration with Cron / Morning Briefing

The Morning Briefing cron job (fires daily at 07:05) reads `~/pantheon/project-ideas.md` and includes a status rollup in the dispatch. The script at `~/.hermes/scripts/morning-briefing.sh` collects the file content and passes it to the agent's prompt:

```bash
echo "=== PROJECT_IDEAS ==="
cat /home/konan/pantheon/project-ideas.md
```

When you update the project ideas file, the change is automatically reflected in the next morning's briefing — no other step needed.
