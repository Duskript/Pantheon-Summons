#!/usr/bin/env python3
"""
Extract individual project files from a Claude.ai export zip
and route them to the correct Codex reference/ directory.

Usage:
    python3 scripts/extract-claude-projects.py <export.zip>

The main import pipeline (pantheon-import-claude) only handles
projects.json. Newer exports store projects as individual files
in projects/UID.json — this script picks up the slack.
"""
import json
import os
import sys
import zipfile
from pathlib import Path

ATHENAEUM = os.path.expanduser("~/athenaeum")
PROJECT_ROUTES = {
    # Keyword → Codex
    "lyric smith": "Codex-Apollo",
    "lyricist": "Codex-Apollo",
    "lyric craft": "Codex-Apollo",
    "suno": "Codex-Apollo",
    "style": "Codex-Apollo",
    "jira": "Codex-Work",
    "agent zero": "Codex-Infrastructure",
    "synthetic": "Codex-Infrastructure",
    "album art": "Codex-Infrastructure",
    "qr code": "Codex-SKC",
}


def classify_project(name: str) -> str:
    name_lower = name.lower()
    for keyword, codex in PROJECT_ROUTES.items():
        if keyword in name_lower:
            return codex
    return "Codex-Claude"  # fallback


def sanitize(name: str) -> str:
    slug = name.lower().replace(" ", "-")
    return "".join(c for c in slug if c.isalnum() or c in "-_")[:50]


def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <export.zip>")
        sys.exit(1)

    zip_path = os.path.abspath(sys.argv[1])
    if not os.path.isfile(zip_path):
        print(f"Error: file not found: {zip_path}")
        sys.exit(1)

    count = 0
    with zipfile.ZipFile(zip_path) as z:
        proj_files = [n for n in z.namelist() if n.startswith("projects/")]
        if not proj_files:
            print("No project files found in zip.")
            return

        for pf in proj_files:
            p = json.loads(z.read(pf))
            name = p.get("name", "Unknown")
            prompt = p.get("prompt_template", "") or ""
            desc = p.get("description", "") or ""
            codex = classify_project(name)
            slug = sanitize(name)

            out_path = Path(ATHENAEUM) / codex / "reference" / f"project--{slug}.md"
            out_path.parent.mkdir(parents=True, exist_ok=True)

            content = f"# {name}\n\n**Source:** claude.ai export\n**Type:** Project\n\n---\n\n"
            if desc:
                content += f"{desc}\n\n---\n\n"
            content += f"## System Prompt\n\n```\n{prompt}\n```\n"
            out_path.write_text(content)
            print(f"  ✅ {name} → {codex}/reference/")
            count += 1

    print(f"\nDone — {count} project(s) extracted.")
    print(f"Run 'athenaeum-ingest --bulk ~/athenaeum/' or 'reembed-athenaeum.py' to index.")


if __name__ == "__main__":
    main()
