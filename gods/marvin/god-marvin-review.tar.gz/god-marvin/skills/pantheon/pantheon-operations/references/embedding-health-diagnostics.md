# Session Notes: Embedding Health & ChromaDB State (2026-05-06)

## Context

Konan asked "has everything been embedded" — investigation revealed the ChromaDB was extremely sparse. The earlier embedding state (1068 vectors across 13 collections) was from **before a system rollback** on 2026-05-05. The pre-session state was only 95 vectors. Most content was not semantically searchable.

**Provider switch happened this session:** Switched from Ollama `nomic-embed-text` (768-dim) to OpenRouter `nvidia/llama-nemotron-embed-vl-1b-v2:free` (2048-dim). This required wiping all 13 collections and re-embedding from scratch (dimension mismatch).

## ChromaDB State During This Session

**Pre-session (found at start):** 95 vectors — only Codex-SKC (93) and Codex-God-Hephaestus (2) had data.

**Mid-session (post-wipe):** All 13 collections deleted and recreated fresh. An orphaned reembed process from an `execute_code` call embedded 20 vectors to Codex-SKC before being killed.

**Current state:** A full re-embed is running in the background (if the last `terminal(background)` was allowed to continue). The script is processing all 1204 embeddable files through OpenRouter with 2048-dim vectors. Monitor via `tail -f /tmp/reembed.log`.

## What Was Missing (pre-wipe)

- **Codex-Claude** — 0 vectors. All 214 imported Claude.ai conversations were unsearchable.
- **Codex-Work** — 0 vectors. Full-time position request, IT documents, professional content not in ChromaDB.
- **Codex-User** — 0 vectors. User profile, work context, personal history invisible to semantic search.
- **Codex-Apollo** — 0 vectors. Creative methodology, music prompts not embedded.
- **Codex-Pantheon** — 0 vectors. System documentation, architecture specs unsearchable.
- **Codex-General** — 0 vectors. General knowledge from across the web.
- **Codex-Infrastructure** — 0 vectors. Homelab configs, networking notes.
- **Codex-Forge** — 0 vectors.
- **Codex-Asclepius** — 0 vectors.
- **Codex-Fiction** — 0 vectors.

Note: Codex-SKC's 93 vectors came from a partial re-embed that ran before the rollback. The 2 vectors in Codex-God-Hephaestus were from the shared brain setup files.

## Dual ChromaDB Paths: A Trap

Found during this session — `~/athenaeum/chromadb/` has an empty ChromaDB:
- Has a valid `chroma.sqlite3` with all tables (migrations, collections, segments, embeddings table structure)
- But `collections` table is empty
- `segments`: 0 rows
- `embedding_metadata`: 0 rows

The real ChromaDB is at `~/.hermes/pantheon/chroma/`. The athenaeum path was probably created as an alternative location during the migration to headless Beelink, but never populated.

**Diagnosis commands:**

```bash
# Correct path — shows real collections and vectors
python3 -c "
import chromadb, os
client = chromadb.PersistentClient(path=os.path.expanduser('~konan') + '/.hermes/pantheon/chroma')
for col in sorted(client.list_collections(), key=lambda c: c.count(), reverse=True):
    print(f'{col.name}: {col.count()} vectors')
"

# Empty trap — shows 0 collections
python3 -c "
import chromadb
client = chromadb.PersistentClient(path=os.path.expanduser('~konan') + '/athenaeum/chromadb')
print(f'Collections: {len(client.list_collections())}')
"
```

## Cross-session history of this issue

- **2026-04-30**: Original session. First investigation of the 51-file phantom gap. Full inventory found **1068 vectors** across 13 collections.
- **2026-05-05**: System rollback occurred. ChromaDB was reset or rolled back.
- **2026-05-06 (pre-session)**: Only 95 vectors remained. 11 of 13 collections had 0 vectors.
- **2026-05-06 (this session)**: Wiped all collections and switched embedding providers (Ollama 768-dim → OpenRouter 2048-dim). Full re-embed running.

## Background Process Output Issue

Running the reembed script via `terminal(background=true)` may not show output in the process monitoring tool even when the script is running. This is due to Python output buffering and shell capture. **Workaround:** redirect to a file:

```bash
cd ~/pantheon && OPENROUTER_API_KEY="sk-or-..." nohup python3 -u scripts/reembed-athenaeum.py > /tmp/reembed.log 2>&1 &

# Monitor:
tail -f /tmp/reembed.log
```

## Recommended Actions

1. **Verify the re-embed completed** — check `tail -20 /tmp/reembed.log` for "Done!" message
2. **Verify final vector counts** — run the correct-path diagnosis command above
3. **Run Hades** after re-embed to verify coverage matches (all 13 codexes should have content)
4. **Delete the trap path** `~/athenaeum/chromadb/` to prevent future confusion
5. **Check KNOWN_CODEXES** in `hades.py` to ensure all 13 codexes are tracked by Hades
