# Pantheon Frontend Architecture

## Core Discovery (May 2026)

The Pantheon frontend is being built on **nesquena/hermes-webui** (https://github.com/nesquena/hermes-webui), NOT on Hermes Workspace (React/TypeScript/Electron fork).

The original Pantheon Agent Pack PRD was written assuming Hermes Workspace as the base. The tech stack is fundamentally different, requiring adaptation of all phases.

## Tech Stack (hermes-webui)

| Layer | Tech | Details |
|-------|------|---------|
| Server | Python stdlib | `server.py` + `api/*` modules (~20K lines). No framework — uses `http.server.ThreadingHTTPServer`. Thin routing shell + auth middleware. |
| HTML | Static | `static/index.html` (~600 lines), served from disk. |
| CSS | Vanilla CSS | `static/style.css` (~3K lines). 8 themes including dark, light, system, OLED, Sienna. KaTeX/Mermaid styles. Mobile responsive. |
| JavaScript | Vanilla JS | 13 modules in `static/*.js` (~26K lines total). No framework, no bundler, no transpilation. |
| PWA | Service worker | `static/sw.js` — offline shell cache, version-pinned assets. `static/manifest.json`. |
| Docker | Multi-arch Dockerfile | `python:3.12-slim` base. GHCR images for amd64 + arm64. HEALTHCHECK. |
| State | JSON files | Sessions as individual JSON files in `~/.hermes/webui/sessions/`. Projects in `projects.json`. No database. |
| Resource profile | ~100MB RSS, 0% CPU idle | Extremely lightweight. No database, no framework, no build step. |

### JS Module Inventory

| Module | Size | Purpose |
|--------|------|---------|
| `boot.js` | 64K | Bootstrap / initialization |
| `commands.js` | 48K | Slash commands |
| `i18n.js` | 508K | Internationalization (bulky but static) |
| `icons.js` | 12K | Icon SVG definitions |
| `login.js` | 4K | Login flow |
| `messages.js` | 92K | Message rendering, streaming, tool cards |
| `onboarding.js` | 44K | First-run onboarding |
| `panels.js` | 252K | Panel/layout management |
| `sessions.js` | 128K | Session CRUD, search, tags |
| `terminal.js` | 24K | Terminal emulation |
| `ui.js` | 288K | Main UI orchestration |
| `workspace.js` | 16K | Workspace file browser |
| `sw.js` | 8K | Service worker |

No build pipeline — these are served as-is by `server.py`. Any new Pantheon surface (Forge, Athenaeum) would be a new `.js` file in `static/` plus a new HTML element.

## DESIGN.md ("Hermes Calm Console")

The design spec at `~/hermes-webui/DESIGN.md` defines the visual language:

- **Philosophy**: Conversation-first, tool traces as quiet metadata. Linear/Vercel precision + Claude-style conversational warmth.
- **Palette**: Neutral parchment tones (#EAE0D5 primary, #0A0908 neutral, #22333B surface). Restrained accent. No rainbow colors in transcript.
- **Typography**: Split — editorial serif (Georgia) for assistant prose, clean sans for UI/controls. Tight scale: 11px metadata, 12px labels, 14px body.
- **Layout**: 3-panel. Left sidebar = sessions/nav, center = chat, right = workspace.
- **Components**: Tool cards as debug rows (not chat messages), collapsed by default. Disclosures for metadata. Cozy composer bar.

## Pantheon Concept Mapping

| Hermes WebUI concept | Pantheon name | Implementation notes |
|----------------------|---------------|---------------------|
| Session | **Communion** | Rename in `sessions.js`, `panels.js`, `ui.js` (~5 files) |
| Profile | **God** | Already maps 1:1 — profiles in Hermes = gods in Pantheon |
| Artifact/Workspace output | **Boon** | Replace workspace tab with curated Boon drawer |
| Start profile gateway | **Invoke god** | New UI action in header/god roster |
| Stop profile gateway | **Let god sleep** | New UI action + idle timer |
| Workspace file browser | **Forge** | Replace with execution/project space |
| (new surface) | **Athenaeum** | Knowledge space — new JS module + server endpoint |
| Session tags (projects) | God/domain tagging | Reuse existing `projects.json` infrastructure |
| Profile switch dropdown | God roster | Already works — just restyle as god-centric |

## Adapted Phase Plan (hermes-webui vs Original PRD)

The original PRD had 12 phases for Hermes Workspace (React). Adapted for hermes-webui:

### Phase 0 — Baseline & Naming Layer
- Map hermes-webui codebase (13 JS modules, CSS, HTML, API)
- Identify rename targets (session → communion, profile → god, etc.)
- Establish Pantheon adapter in JS — a thin namespace layer before deep renaming
- `~/hermes-webui/pantheon-overrides.js` — JS that re-exports/redefines key symbols
- Verify app still works after adding the layer

### Phase 1 — Responsive Shell Layout
- hermes-webui already has 3-panel layout and mobile hamburger
- Adjust: resize behavior, god-panel left rail, right Boon drawer placeholder
- CSS changes only — no JS framework changes needed
- Test on tablet/phone viewports

### Phase 2 — Communion Chat Integration
- Rename visible session language in `sessions.js`, `panels.js`, `ui.js`
- Add Communion selector pill (pills already exist in the codebase)
- Preserve Hermes session behavior — renaming is cosmetic at first
- Update i18n strings in `i18n.js` (the 508K file — careful with bulk edits)

### Phase 3 — God Roster & Switching
- Restyle the existing profile switcher as a god roster in the left rail
- Add active god pill in chat header
- God avatar/icon support (extend existing profile image handling)
- God-specific accent theme (per-god CSS variables)
- Profile switch = god switch — already works at API level

### Phase 4 — God Invocation Lifecycle
- New UI in `ui.js`/`panels.js`: god states (awake, starting, idle, sleeping, unavailable)
- "Invoke" and "Sleep" buttons on god roster items
- Hermes always-on, others lazy-loaded
- Needs new API endpoints or reuse of existing gateway control endpoints
- Idle timer display — polling or SSE push

### Phase 5 — Boon Drawer
- Replace/modify the workspace panel to become a Boon drawer
- States: closed, preview, expanded, pinned
- Render markdown/code/document previews
- Mobile bottom-sheet behavior
- Actions: open, copy, export, pin, send to Forge

### Phase 6 — Rich Chat Blocks
- Attachment chips (existing: enhance)
- Structured selection menus (existing: enhance)
- Code block action bar (existing: enhance)
- File reference cards (existing: enhance)
- God handoff/invocation cards (new visual component)

### Phase 7 — Athenaeum
- New JS module: `static/athenaeum.js`
- New server endpoints in `api/`
- Codex browser, semantic search panel, note viewer/editor
- Existing workspace panel provides UI pattern reference

### Phase 8 — Forge
- Replace workspace file browser with project/task space
- Task status tracking, "Send Boon to Forge" flow
- Can co-exist or replace the existing workspace panel

### Phase 9 — Ideas, Notifications, Health
- Ideas button in top bar (split: user ideas vs god suggestions)
- Notifications panel with persistent items
- Health popup (Hermes, Pantheon MCP, LiteLLM, god runtime)
- Reuse existing panel/modal infrastructure

### Phases 10-11 — Marketplace & Polish
- God import/export after core is stable
- Responsive QA, accessibility, error/loading states, PWA testing
- Offline behavior hardening

## Implementation Strategy Differences

| Aspect | Hermes Workspace (React) | hermes-webui (Vanilla JS) |
|--------|-------------------------|---------------------------|
| Rename approach | Rename React components + routes | Rename in `static/*.js` + CSS |
| New surfaces | New React routes + components | New `.js` files + HTML divs |
| State | React state/context | Vanilla JS global state / DOM |
| Build | Vite/webpack | None — edit files directly |
| Styling | CSS-in-JS or Tailwind | Single `style.css` |
| Testing | Jest/Vitest | pytest (Python) + manual/browser |
| API changes | Separate BFF | Same Python `api/` modules |
| Profile/god binding | Custom auth flow | Cookie-based (`hermes_profile`) |

## Key Design Files

| File | Path | Status |
|------|------|--------|
| DESIGN.md | `~/hermes-webui/DESIGN.md` | Has full "Hermes Calm Console" design spec ✓ |
| ARCHITECTURE.md | `~/hermes-webui/ARCHITECTURE.md` | 81K — comprehensive |
| Pantheon Agent Pack | `~/pantheon/agent-pack/` | PRD with phases, tasks, handoffs |
| Pantheon phase plan | Adapted above ^ | Vanilla JS version |
