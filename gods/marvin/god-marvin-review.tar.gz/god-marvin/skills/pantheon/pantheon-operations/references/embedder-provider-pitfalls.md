# Embedder Provider Pitfalls

> Reference for issues encountered with Pantheon's embedding providers.
> Last updated: 2026-05-06 (major rewrite: switched from Ollama to OpenRouter as primary)

## Embedding Provider Architecture

Pantheon now uses **OpenRouter** as the primary embedding provider with `nvidia/llama-nemotron-embed-vl-1b-v2:free` (2048-dim). This replaced Ollama's `nomic-embed-text` (768-dim) on 2026-05-06.

### Files That Changed (both must be updated together)

| File | What changed |
|------|-------------|
| `scripts/reembed-athenaeum.py` | Bulk re-embed script — `openrouter_embed()` replaces `ollama_embed()` |
| `pantheon-core/mnemosyne/client.py` | Per-file embedding — `_get_embedding()` now calls OpenRouter API |

These two files are **independently configurable** via env vars:

| Variable | Default | Notes |
|----------|---------|-------|
| `ATHENAEUM_EMBED_MODEL` | `nvidia/llama-nemotron-embed-vl-1b-v2:free` | Any OpenRouter model slug |
| `ATHENAEUM_EMBED_URL` | `https://openrouter.ai/api/v1/embeddings` | Any OpenAI-compatible endpoint |
| `OPENROUTER_API_KEY` | *(from env)* | Must be valid — 401 = silent failure |

## OpenRouter Key Validation Issue

**Location:** `~/pantheon/pantheon-core/mcp_server.py` — `_Embedder.is_available()`

```python
def is_available(self) -> bool:
    if self.use_openrouter:
        return True  # <-- BUG: doesn't validate the key works
    try:
        resp = httpx.get("http://localhost:11434/api/tags", timeout=5.0)
        return resp.status_code == 200
    except Exception:
        return False
```

The `is_available()` method returns `True` whenever `OPENROUTER_API_KEY` is set to ANY non-empty string, even if the key is expired, revoked, or malformed. This means the system health check reports the embedder as "ok" when it's actually broken.

**Impact:** The Pantheon system health endpoint (`mcp_pantheon_system_health`) reads this and shows `embedding.status: "ok"` even though all embedding calls will 401. This misleads diagnostics.

**Workaround (if OpenRouter key is expired):** The key in `~/.hermes/profiles/apollo/.env` was expired (401) as of mid-May 2026. Either update that key, or switch back to Ollama (see below).

**Fix needed:** Replace `return True` with a real test call — same format as the test in `reembed-athenaeum.py`.

## Re-Embed Script: Provider Switch (2026-05-06)

**Location:** `~/pantheon/scripts/reembed-athenaeum.py`

### Changes Made This Session

1. **Provider switch:** Replaced `ollama_embed()` with `openrouter_embed()` — calls `https://openrouter.ai/api/v1/embeddings` with configurable model via `EMBED_MODEL`
2. **API format:** OpenAI-compatible: `{"model": "...", "input": "text"}` → response `data[0].embedding`
3. **Chunking preserved:** Content still split into 2000-char chunks, each embedded separately, then averaged
4. **Size limits:** Max 64K chars per file (truncated), max 20 chunks
5. **Auth header:** `Authorization: Bearer $OPENROUTER_API_KEY` passed with every request
6. **Connection test:** Validates key on startup with a real embedding call — if it fails, the script exits immediately

### Dimension: 2048

| Provider | Model | Dim | Status |
|----------|-------|-----|--------|
| OpenRouter | `nvidia/llama-nemotron-embed-vl-1b-v2:free` | **2048** | ✅ Current default |
| Ollama | `nomic-embed-text` | 768 | ⬅️ If reverting, must wipe & re-embed |

**If you switch back to Ollama,** you MUST wipe ChromaDB and re-embed because vector dimensions differ. The reembed script handles this automatically (deletes all collections before recreating).

### Background Output Capture Issue

Running the script via `terminal(background=true)` may show empty output in the process tool even when the script is running. This is due to Python's output buffering combined with how the shell captures background process output. **Workaround:**

```bash
# Write to a file instead of relying on process tool output capture
cd ~/pantheon && OPENROUTER_API_KEY="..." nohup python3 -u scripts/reembed-athenaeum.py > /tmp/reembed.log 2>&1 &

# Monitor progress
tail -f /tmp/reembed.log
```

The `-u` flag (unbuffered) helps but doesn't fully resolve capture in all shell environments. Always prefer a log file redirect for long-running embed jobs.

## Ollama Fallback Path (if reverting)

To switch back to Ollama `nomic-embed-text`:

1. In `scripts/reembed-athenaeum.py`: Restore the `ollama_embed()` function that calls `http://localhost:11434/api/embeddings` with `model=nomic-embed-text`
2. In `pantheon-core/mnemosyne/client.py`: Restore the Ollama-based `_get_embedding()` — uses `httpx.post` to `http://localhost:11434/api/embeddings`
3. Ensure Ollama has the model: `ollama pull nomic-embed-text` (274MB)
4. Run reembed — the dimension change (2048→768) requires a full wipe and restart

### Ollama chunking bug (only relevant if reverting)

Ollama's `nomic-embed-text` model 500s on files over ~8K chars. The fix is chunking into 256-char segments, averaging the embeddings, capped at 20 chunks. This was the original fix that resolved the "52-file phantom gap" in Hades reports. Files that consistently fail without chunking:

- `Codex-SKC/claude/*.md` — song lyrics
- `Codex-SKC/audio/*.md` — composition briefs
- Any long markdown content

## Checking Current Embedder Status

```bash
# Test OpenRouter (current primary)
curl -s -X POST https://openrouter.ai/api/v1/embeddings \
  -H "Authorization: Bearer $OPENROUTER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"nvidia/llama-nemotron-embed-vl-1b-v2:free","input":"test"}'

# Test Ollama (fallback)
curl -s -X POST http://localhost:11434/api/embeddings \
  -d '{"model":"nomic-embed-text","prompt":"test"}'

# List ChromaDB collections with vector counts
python3 -c "
import chromadb, os
client = chromadb.PersistentClient(path=os.path.expanduser('~konan')+'/.hermes/pantheon/chroma')
for col in sorted(client.list_collections(), key=lambda c: c.name):
    print(f'{col.name}: {col.count()} vectors')
"
```
