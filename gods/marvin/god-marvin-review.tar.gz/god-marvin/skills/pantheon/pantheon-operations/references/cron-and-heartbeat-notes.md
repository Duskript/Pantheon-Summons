# Session Notes: Re-establishing Heartbeat Cron (2026-05-06)

## Context

Hestia was running hourly (60 min expected interval). The Fates watchdog had no cron trigger. All Pantheon cron entries were wiped during an earlier migration/transition.

**User requirement:** "get those heartbeats running but they should at most only report every other hour"

## Changes Made

### 1. Updated heartbeat defaults in source

File: `~/pantheon/scripts/heartbeat.py`

```python
# Before
"hestia": {
    "label": "Hestia — Hourly Health Checks",
    "expected_interval_min": 60,
},
"demeter_watcher": {
    "expected_interval_min": 60,
},

# After  
"hestia": {
    "label": "Hestia — Every-Other-Hour Health Checks",
    "expected_interval_min": 120,
},
"demeter_watcher": {
    "expected_interval_min": 120,
},
```

### 2. Updated runtime heartbeat file

The `the-fates.py --init` command uses **merge semantics** — it only adds entries that don't exist, it doesn't update existing ones. So after changing source defaults, the heartbeat file still had `hestia.expected_interval_min: 60`.

**Fix:** Directly edited `~/.hermes/pantheon/heartbeat.json` via Python script:

```python
import json
with open('heartbeat.json') as f:
    data = json.load(f)
data['hestia']['expected_interval_min'] = 120
data['hestia']['label'] = 'Hestia — Every-Other-Hour Health Checks'
data['demeter_watcher']['expected_interval_min'] = 120
with open('heartbeat.json', 'w') as f:
    json.dump(data, f, indent=2, sort_keys=True)
    f.write('\n')
```

### 3. Fixed import path bug in Hestia

**Bug:** `pantheon-core/gods/hestia.py` had:

```python
_SCRIPTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts")
```

This resolved to `~/pantheon/pantheon-core/scripts/` instead of `~/pantheon/scripts/`.

**Fix:** Changed to `"..", "..", "scripts"`:

```python
_SCRIPTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "scripts")
```

### 4. Set up system crontab

```bash
(crontab -l 2>/dev/null; echo "# Pantheon Heartbeat System"; \
echo "# Hestia — health check every 2 hours"; \
echo "0 */2 * * * cd /home/konan/pantheon && python3 pantheon-core/gods/hestia.py >> /home/konan/pantheon/logs/hestia.log 2>&1"; \
echo "# The Fates — heartbeat watchdog every 5 minutes"; \
echo "*/5 * * * * cd /home/konan/pantheon && python3 scripts/the-fates.py >> /home/konan/pantheon/logs/the-fates.log 2>&1") | crontab -
```

### 5. Created log directory

```bash
mkdir -p ~/pantheon/logs
```

### 6. Verified heartbeat file after setup

```
apollo_gateway       interval=   5min  last_ok=never
demeter_watcher      interval= 120min  last_ok=never
hades                interval=1440min  last_ok=2026-05-06T07:00:41
hermes_gateway       interval=   5min  last_ok=2026-05-06T17:15:27
hestia               interval= 120min  last_ok=2026-05-06T17:16:34
mcp_server           interval=   5min  last_ok=2026-05-06T17:15:28
the_fates            interval=   5min  last_ok=2026-05-06T17:16:08
```

## Key Lessons

1. **`the-fates.py --init` does NOT update existing entries** — it uses merge semantics (preserves existing timestamps and values). Always directly edit the JSON when changing intervals on existing subsystems.

2. **Import paths from `pantheon-core/gods/` need depth awareness** — `..` from `gods/` goes to `pantheon-core/`, not to `pantheon/`. Need `../..` to reach the repo root, then `scripts/`.

3. **System cron for scripts, Hermes cron for agents** — Python scripts that just collect data, write heartbeats, and exit should use system crontab. Hermes cron tool should only be used when agent context is required (reasoning, decision-making, output generation).

4. **Always redirect cron output** — without `>> log 2>&1`, cron mails output or it's silently lost. Create a `logs/` directory for each subsystem.

5. **Memory of cron being wiped** — crontab entries don't survive system migrations or Hermes agent transitions. Always check `crontab -l` when diagnosing "things that used to run but don't anymore."
