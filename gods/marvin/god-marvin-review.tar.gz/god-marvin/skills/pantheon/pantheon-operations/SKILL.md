---
name: pantheon-operations
description: Manage Pantheon subsystem runtime operations — cron scheduling, heartbeat system, import path conventions, log management, and diagnostic data flows.
---

# Pantheon Operations

Managing the runtime infrastructure that keeps Pantheon subsystems alive and monitored: cron jobs, the shared heartbeat system, import path architecture across the repo, and log management.

## Cron Management

Pantheon uses **two cron systems**. The wrong choice creates unnecessary overhead:

### 1. System Crontab (for headless Python scripts)

Use `crontab -e` or pipe entries for scripts that run headlessly with no need for Hermes agent context:

- **Hestia** — health checks (every 2h)
- **The Fates** — heartbeat watchdog (every 5min)
- **Hades** — nightly consolidation (daily at 02:00)
- **Dreamweaver** — graph Dream Cycle (daily at 02:15, after Hades)

**Pattern:**

```bash
# Add entry preserving existing crontab
(crontab -l 2>/dev/null; echo "# Comment describing job"; echo "schedule cd /home/konan/pantheon && python3 path/to/script.py >> /home/konan/pantheon/logs/name.log 2>&1") | crontab -
```

Always use absolute paths in the `cd` and redirect both stdout and stderr to a log file.

### 2. Hermes Cronjob Tool (for agent sessions)

Use the `/hermes cron add` command (or the underlying `cronjob` tool) when a full Hermes session is needed:

- **Morning Briefing** — needs agent context, knowledge, tools to synthesize reports
- **Decision-making tasks** — needs to evaluate and decide, not just execute
- **Complex output generation** — needs to write files, send messages, etc.

### Pitfall: Cron jobs were wiped

During a Pantheon migration/transition, cron jobs can get wiped. Always check with `crontab -l` before assuming a cron-triggered subsystem is running. Don't trust that previous cron setup survived — it's a common casualty.

### Pitfall: Cron timing must respect user's active hours

Heavy Pantheon maintenance jobs (Hades, Dreamweaver) MUST run **overnight at 02:00–02:30**, not during the morning. The user is active during the day and expects these jobs to run when the machine is idle.

**Wrong (wastes resources during user's active time):**
```
# Hades at morning — NO
0 7 * * * hades.py
```

**Correct (runs when user is asleep):**
```
# Hades at 02:00 — YES
0 2 * * * hades.py
```

The Morning Briefing at 07:05 reads the **already-completed** Hades report from disk — it does NOT run Hades itself. If you're scheduling a new subsystem and it's a heavy operation (10+ min, API calls, file processing), default to 02:00–04:00 time slot unless the user explicitly says otherwise.

## Heartbeat System

The shared heartbeat system is the canonical runtime health tracker. Everything writes to it; The Fates watches it.

### Architecture

```
                   ┌─────────────────────────────┐
                   │  heartbeats() writes here    │
                   │  get_all() reads from here   │
                   │  beat(sid) stamps timestamp  │
                   └──────────┬──────────────────┘
                              │
                    ┌─────────▼─────────┐
                    │ heartbeat.json     │
                    │ ~/.hermes/pantheon/│
                    └─────────▲─────────┘
                              │
           ┌──────────────────┼──────────────────┐
           │                  │                  │
   ┌───────▼───────┐ ┌───────▼───────┐ ┌───────▼───────┐
   │  Hestia       │ │  The Fates    │ │  Gateways     │
   │  writes every │ │  reads &      │ │  write on     │
   │  2h           │ │  alerts       │ │  each request │
   └───────────────┘ └───────────────┘ └───────────────┘
```

### Key Functions (from `scripts/heartbeat.py`)

| Function | Purpose |
|----------|---------|
| `beat(sid)` | Stamp `last_ok` for a subsystem |
| `get_all()` | Return all heartbeat entries |
| `initialise()` | Create/reset heartbeat file with defaults |
| `stale_list()` | Return entries past their expected interval |

### Updating a Subsystem's Expected Interval

**Must update two places:**

1. **Source of truth** — `~/pantheon/scripts/heartbeat.py` → `DEFAULT_HEARTBEATS` dict
2. **Runtime file** — `~/.hermes/pantheon/heartbeat.json`

**CRITICAL:** Running `the-fates.py --init` (which calls `initialise()`) uses a **merge** strategy — it preserves existing entries' values and only adds missing ones. It will NOT update an existing entry's `expected_interval_min` from the source code change. To force-update, edit the JSON file directly.

### Subsystem Intervals Reference

| Subsystem | Interval | Notes |
|-----------|----------|-------|
| The Fates | 5 min | Silent watchdog, only alerts on stale or dead subsystems |
| Gateways (MCP, Hermes, Apollo) | 5 min | Written by service code automatically |
| Hestia | 120 min | Full health check + heartbeat |
| Demeter | 120 min | File watcher checks |
| Hades | 1440 min | Daily night consolidation at 02:00 |
| Dreamweaver | 1440 min | Daily graph Dream Cycle at 02:15 (after Hades) |

## Import Path Architecture

Pantheon has a non-standard layout where scripts in different directories import from `~/pantheon/scripts/heartbeat.py`. The path calculation is fragile — it depends on `__file__` being at the right depth.

### Layout and Paths

```
~/pantheon/
├── scripts/             ← heartbeat.py, the-fates.py (import directly)
│   ├── heartbeat.py
│   └── the-fates.py
├── pantheon-core/
│   └── gods/            ← hestia.py, hades.py (need ../../scripts/)
│       ├── hestia.py
│       └── hades.py
└── logs/                ← cron output lands here
```

### The Import Pattern

Each file uses a guards to add `scripts/` to sys.path:

```python
_SCRIPTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts")
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)
```

### The Bug: Wrong Depth From `pantheon-core/gods/`

from `pantheon-core/gods/`:
- `__file__` = `/home/konan/pantheon/pantheon-core/gods/hestia.py`
- `os.path.dirname(...)` = `/home/konan/pantheon/pantheon-core/gods/`
- `..` + `scripts` = `/home/konan/pantheon/pantheon-core/scripts/` ← WRONG! Doesn't exist.

**Fix:** Use `"..", "..", "scripts"` which resolves to `/home/konan/pantheon/scripts/` ✓

### Cross-Repository Script Resolution

When one Pantheon subsystem calls a script **outside** the `~/pantheon/` repo (e.g., Hades calling `athenaeum/scripts/extract-entities.py`), relative path math from `__file__` breaks because the target isn't in the same directory tree. **Always use `~konan` absolute paths for cross-repo dependencies:**

```python
# WRONG — assumes extract-entities is inside the pantheon repo
script = os.path.join(os.path.dirname(os.path.dirname(__file__)), "..", "athenaeum", "scripts", "extract-entities.py")

# RIGHT — uses absolute home path
_REAL_HOME = os.path.expanduser("~konan")
script = os.path.join(_REAL_HOME, "athenaeum", "scripts", "extract-entities.py")
```

When running via `subprocess`, also pass the full environment loaded from `~/.hermes/.env` so API keys are available:

**Diagnosis:** If a subsystem script runs but reports "heartbeat library not available" or ImportError, check the path calculation depth. The directory `gods/` is at depth 2 from the repo root, while `scripts/` is at depth 1 from the repo root.

## Logging

Cron jobs redirect output to `~/pantheon/logs/`. Create the directory when setting up new cron:

```bash
mkdir -p ~/pantheon/logs
```

Standard log files:
| Subsystem | Log path |
|-----------|----------|
| Hestia | `~/pantheon/logs/hestia.log` |
| The Fates | `~/pantheon/logs/the-fates.log` |

## Embedding Health & Coverage

Before re-embedding, diagnose WHY files aren't embedded. The most common cause isn't a script failure — it's the codex not being on Hades' radar at all.

### Step 1: Compare ChromaDB Collections vs Hades' KNOWN_CODEXES

Hades only tracks codices in its `KNOWN_CODEXES` list at `~/pantheon/pantheon-core/gods/hades.py`. If a codex isn't there, Hades won't check its embedding status, run distillation, or report gaps.

**Check what Hades tracks:**

```bash
grep "KNOWN_CODEXES" ~/pantheon/pantheon-core/gods/hades.py -A 10
```

**List all ChromaDB collections and vector counts:**

```bash
cd ~/pantheon && python3 -c "
import chromadb
client = chromadb.PersistentClient(path='$HOME/.hermes/pantheon/chroma')
for col in client.list_collections():
    print(f'{col.name}: {col.count()} vectors')
"
```

**Cross-reference:** Any ChromaDB collection that doesn't correspond to a codex in `KNOWN_CODEXES` is being silently ignored by Hades. That codex's files may exist on disk but will never show up in the nightly embedding health report.

This also works in reverse — codices in `KNOWN_CODEXES` with zero ChromaDB vectors indicate the embedder failed for that entire codex.

### Step 2: Filesystem vs ChromaDB Count Per Codex

For a tracked codex, the raw file count vs ChromaDB vector count should be close (some discrepancy is expected since INDEX.md and non-embeddable files are excluded). Large gaps mean the embedder is silently failing on files in that codex.

### Step 3: Verify a Specific Codex is Embedded

If a codex exists on disk but you can't find it in ChromaDB:

1. Check if it's in `KNOWN_CODEXES` at `hades.py` line ~47
2. If not, add it: `"Codex-Claude", "Codex-User", "Codex-Work", "Codex-Apollo"` etc.
3. Run re-embedding to bring the missing files in
4. Verify next Hades run picks it up

**Pitfall: Codex not in KNOWN_CODEXES = invisible to Hades.** This is the #1 cause of "files exist but embedding status unknown." Codex-Claude, Codex-User, Codex-Work, and Codex-Apollo are all missing from the list by default. Files in these codices accumulate silently with no Hades oversight.

### Step 4: Protect a Codex from Archival via SYSTEM_CODEXES

Some codices should be watched by Hades (health checks, embedding, distillation) but **never archived or deleted**. Add them to `SYSTEM_CODEXES` in `hades.py`:

```python
SYSTEM_CODEXES = {"Codex-Pantheon", "Codex-Apollo"}
```

The `run_archive()` function skips any codex in this set. Currently applies to:
- `Codex-Pantheon` — system documentation, must never be archived
- `Codex-Apollo` — creative reference and methodology, content is deliberately curated

### Pitfall: The 52-file phantom gap

Hades has been reporting 51–52 unembedded files for days across multiple sessions. The count barely changes, suggesting the same files fail embedding each run rather than new drift. The root cause is usually the embedder (OpenRouter or Ollama) returning 500 errors on **long-form content** — song lyrics, multi-page conversations, large markdown files. Ollama's `nomic-embed-text` model has limited context and will crash on files over 8K+ chars.

**Fix:** The `reembed-athenaeum.py` script must chunk content before embedding. The `_Embedder` in `mcp_server.py` already does this (512-char chunks, averaged). The standalone reembed script was patched to match: 256-char chunks, capped at 20 chunks (64K chars total), averaged to a single vector. Without chunking, long song lyric files in Codex-SKC/claude/ and Codex-SKC/audio/ will always fail.

### Pitfall: Dual ChromaDB paths — only one is real

There are **two** ChromaDB databases on the system:

| Path | Status | Vectors |
|------|--------|---------|
| `~/.hermes/pantheon/chroma/` | ✅ **THE REAL ONE** | Active (used by all Pantheon tools) |
| `~/athenaeum/chromadb/` | ❌ **TRAP — EMPTY** | 0 collections, 0 embeddings |

The `~/athenaeum/chromadb/` path has a valid `chroma.sqlite3` file with all the right SQLite tables — but the `collections` table is empty. It was created as an alternative location but never populated. Meanwhile the real ChromaDB at `~/.hermes/pantheon/chroma/` is what `mcp_pantheon_system_health` and Mnemosyne actually use.

**Why this matters:** If you happen to check collections at the wrong path:
```python
# WRONG — returns 0 collections
client = chromadb.PersistentClient(path="~/athenaeum/chromadb/")

# RIGHT — returns real collections
client = chromadb.PersistentClient(path="~/.hermes/pantheon/chroma/")
```

- `~/athenaeum/chromadb/` exists as a silent trap for anyone probing ChromaDB directly.

**Current state (as of 2026-05-06, post-reembed):** All 13 collections were wiped and recreated as part of the provider switch (Ollama → OpenRouter, 768-dim → 2048-dim). A full re-embed is running in the background. Previous state was 95 vectors across 13 collections (~7% of 1367 files) — most content (Claude imports, user profile, work content, infrastructure) was not semantically searchable.

## Re-embedding the Athenaeum

After importing new content (Claude exports, manual additions, adding a codex to KNOWN_CODEXES), the ChromaDB vector store needs to be re-embedded for semantic search to find the new material.

**Command:**

```bash
cd ~/pantheon && OPENROUTER_API_KEY="sk-or-v1-..." python3 -u scripts/reembed-athenaeum.py
```

**Embedding provider:** OpenRouter with `nvidia/llama-nemotron-embed-vl-1b-v2:free` (2048-dim). This is the **current default** in both the reembed script and the Mnemosyne client.

**Two configurable env vars:**

| Variable | Default | Override |
|----------|---------|----------|
| `ATHENAEUM_EMBED_MODEL` | `nvidia/llama-nemotron-embed-vl-1b-v2:free` | Any OpenRouter model slug |
| `ATHENAEUM_EMBED_URL` | `https://openrouter.ai/api/v1/embeddings` | Any OpenAI-compatible embeddings endpoint |
| `OPENROUTER_API_KEY` | *(required)* | Set inline or in `.env` |

**If you want to switch back to Ollama** (nomic-embed-text, 768-dim):
1. Edit `scripts/reembed-athenaeum.py` — replace `openrouter_embed()` with `ollama_embed()` version
2. Edit `pantheon-core/mnemosyne/client.py` — replace `_get_embedding()` OpenRouter call with Ollama equivalent
3. Must wipe and re-embed (different dimensions — 2048 vs 768 — ChromaDB will error on mismatch)

**Key pitfalls:**

- **Timeouts** — 1,200 files through OpenRouter takes 10–20 minutes depending on rate limits. Always run in background:
  ```bash
  cd ~/pantheon && nohup python3 -u scripts/reembed-athenaeum.py > reembed.log 2>&1 &
  ```
- **Background output capture** — Python buffering means process tool output (via `terminal(background=true)`) may show as empty even when the script is running. Use a log file redirect to `/tmp/reembed.log` and `tail -f` to monitor.
- **Partial progress on kill** — if the script is killed mid-run, some collections will have partial vectors. Rerunning wipes and restarts. The script always deletes all existing collections first, then recreates them — it's fully destructive.
- **Adding a codex to KNOWN_CODEXES alone doesn't embed it** — you must then run the re-embed script to backfill ChromaDB before the next Hades run.
- **OpenRouter key expired?** The key stored in `~/.hermes/profiles/apollo/.env` may be expired (401). The MCP server's `_Embedder.is_available()` returns `True` for any non-empty key string regardless of validity — always verify with a real test call first.
- **The reembed script AND Mnemosyne client must be updated together.** If you change the embedding model/endpoint in one but not the other, Demeter-ingested files will use a different model from bulk re-embeds, producing dimension mismatches.

## Importing New Claude Exports

Claude.ai exports use a standard zip format. The import pipeline is at `~/pantheon/scripts/pantheon-import-claude`.

**Usage:**
```bash
cd ~/pantheon && python3 scripts/pantheon-import-claude <export.zip> [--skip-existing]
```

**Format change (May 2026):** Recent Claude exports may store projects as individual files in a `projects/` directory rather than a single `projects.json`. The import script only handles `projects.json` — projects in the new format will be skipped with a warning. Use the dedicated helper script:

```bash
python3 /home/konan/.hermes/skills/pantheon/pantheon-operations/scripts/extract-claude-projects.py <export.zip>
```

This automatically classifies projects by name and writes them to the correct Codex `reference/` directory.

**After import:**
Run `reembed-athenaeum.py` (see above) to index the new content into ChromaDB.

## Diagnostic Flow

When a subsystem seems dead or not reporting:

1. **Check heartbeat file** — `cat ~/.hermes/pantheon/heartbeat.json` — fastest triage
2. **Check crontab** — `crontab -l` — confirm cron entries exist
3. **Check log files** — `tail -20 ~/pantheon/logs/{subsystem}.log`
4. **Run manually** — `cd ~/pantheon && python3 {path}` — replicates cron execution context
5. **Check systemd services** — `systemctl --user list-units --type=service | grep pantheon` — for service-based subsystems

The heartbeat file's `last_ok` timestamp is the first read. If it's null or old, the subsystem hasn't run. Then check if it has a cron trigger or is systemd-managed.

### Entity Extraction Pipeline

The knowledge graph at `~/.hermes/pantheon/graph.db` is fed by a two-stage pipeline: extraction (embedding entities into the graph) + dream cycle (ongoing refinement). Both stages are cron-triggered subsystems.

### Architecture

```
[Hades nightly]                [Dreamweaver daily at 02:15]
      │                                │
      ▼                                ▼
extract-entities.py ───► graph.db ◄─── dreamweaver.py
      │                      │
      ▼                      ▼
  LLM (OpenRouter)     GraphClient (SQLite + FTS5)
  per-file extraction  BFS/neighbor traversal
```


### GraphClient Schema Migration

**5 Phases:**

| Phase | Operation | Thresholds |
|-------|-----------|------------|
| 1. Merge | Deduplicate entities by normalized name; redirect edges to survivor | Case/whitespace/punct normalization |
| 2. Enrich | Add missing reverse/implicit edges from mapping table | 54 reverse pairs |
| 3. Decay | Reduce edge weights by 0.98× each cycle; purge < 0.20; flag < 0.80 | 0.98 decay, 0.20 purge |
| 4. Infer | Transitive inference (A→B→C → A→C with 0.75× confidence) for `depends_on`, `part_of`, `contains`, etc. | 0.75 confidence multiplier |
| 5. Insights | Generate graph state summary: node counts by type, edge type breakdown, most-connected entities | — |

**Usage:**
```bash
# Full Dream Cycle
python3 ~/athenaeum/scripts/dreamweaver.py

# Single phase (e.g., just decay)
python3 ~/athenaeum/scripts/dreamweaver.py --phase 3

# Preview
python3 ~/athenaeum/scripts/dreamweaver.py --dry-run

# JSON output
python3 ~/athenaeum/scripts/dreamweaver.py --json
```

**Checkpoint:** `~/.hermes/pantheon/dreamweaver-checkpoint.json` tracks run count and timestamp.

### Cron Scheduling

Nightly maintenance jobs should run at **02:00** (when user is asleep, not during active morning hours):

```
# Dreamweaver — graph Dream Cycle (15 min after Hades starts at 02:00)
15 2 * * * cd /home/konan/athenaeum && /usr/bin/python3 scripts/dreamweaver.py >> /home/konan/pantheon/logs/dreamweaver.log 2>&1
```

### GraphClient Schema Migration

When extending GraphClient with new node/edge types, handle the SQLite CHECK constraint conflict:

**Problem:** `CREATE TABLE IF NOT EXISTS` doesn't modify existing tables. If the schema has a `CHECK(type IN ('file','session','entity'))` constraint and you add new types, the old constraint still blocks new values.

**Solutions:**
1. **Drop the CHECK constraint** from the table schema entirely (validate in Python instead — GraphClient already does this via `VALID_NODE_TYPES` / `VALID_EDGE_TYPES`)
2. **Drop and recreate the DB** if data isn't critical: `rm -f ~/.hermes/pantheon/graph.db`
3. **SQLite migration** — can't ALTER CHECK constraints; requires table recreation

**Best practice:** Don't use SQL CHECK constraints on node/edge type columns. Let Python validation handle it. The CHECK constraint in the original schema was the root cause of the "disk I/O error" when new types were introduced.

### Report Integration

Entity extraction results appear in the Hades nightly report under a `## 🔗 Entity Extraction` section:
- Files processed / failed
- Total entities extracted
- Total relations extracted

The Hermes mailbox delivery payload also includes `entities_extracted` and `relations_extracted` fields.

## Subsystem Lifecycle

### Adding a new cron-triggered subsystem

1. Determine the schedule (system cron vs Hermes cron)
2. Create the script with proper import path handling
3. Register it in `scripts/heartbeat.py` DEFAULT_HEARTBEATS
4. Update `~/.hermes/pantheon/heartbeat.json` directly (not through `--init`)
5. Add crontab entry with log redirect
6. Run it once manually to verify
7. Verify cron: `crontab -l`

### Removing a cron-triggered subsystem

1. Remove from crontab: `crontab -e` or scripted removal
2. Optionally remove from heartbeat file if fully decommissioned
3. Archive the script if permanently removed

## Web UI (nesquena/hermes-webui)

The Pantheon frontend is now the community-maintained **Hermes WebUI** by nesquena (https://github.com/nesquena/hermes-webui). This replaces all prior frontend experiments: Hermes Workspace, Pantheon UI, AionUI, Kitchen — all retired.

**Why this direction:**
- 752 forks, 3,300+ tests, active daily development (v0.51.14 as of May 2026)
- MIT license, no build step (Python stdlib HTTP server + vanilla JS)
- **Full profile system** that maps directly to Pantheon gods
- **Session tags** (projects.json with name/color) for god/domain tagging
- Extremely lightweight (~100MB RSS, negligible CPU idle)
- Thread-local profile isolation — could run multiple god tabs simultaneously

### The Gateway Relationship

**Architecture decision (May 2026):** The Gateway now serves ONLY the default profile (Konan/Hermes). All other god interactions happen through the Web UI's profile system.

This eliminates the need for multi-profile routing in the Gateway entirely:

| Purpose | Gateway (default profile only) | Web UI (all profiles) |
|---------|---------|--------|
| Telegram/Discord/Signal/SMS | ✅ Default profile only | ❌ Can't do platform bridges |
| Browser chat with any god | ❌ Not needed | ✅ Profile isolation per request |
| API access (external tools) | ✅ Default profile only | ❌ Different port/system |
| Multi-god routing | ❌ NOT needed | ✅ Profile system IS the god system |

**Why this works:** The Web UI's thread-local profile isolation (`api/profiles.py` sets `HERMES_HOME` per HTTP request via `hermes_profile` cookie) means each god gets a fully isolated environment — own SOUL.md, config, skills, memory — without needing the Gateway involved at all. Switching profiles in the Web UI is byte-for-byte identical to `hermes --profile {god}` in the terminal.

**Corollary:** This keeps the Gateway simple — it's a thin pipe for Telegram/Discord access to you, no multi-profile complexity needed.

### Profile → God Mapping

Each Pantheon god = a Hermes profile with its own isolated `HERMES_HOME`:

```
~/.hermes/
├── profiles/
│   ├── default/          ← Hermes (operational)
│   ├── hephaestus/       ← Hephaestus (coding)
│   └── apollo/           ← Apollo (creative)
└── (shared system files)
```

The web UI's profile system:
- Each profile has its own config.yaml, skills, memory, cron, SOUL.md, auth.json
- Thread-local profile isolation per HTTP request (via `hermes_profile` cookie)
- Session tagging via `projects.json` (name + color per project) could map to:
  - Which god the conversation is with
  - Which domain/project the conversation belongs to
- The `profile` field on sessions enables filtering by god

### Deployment (Current)

**Location:** `~/hermes-webui/`

**Start:**
```bash
cd ~/hermes-webui && HERMES_WEBUI_HOST=0.0.0.0 ~/.hermes/hermes-agent/venv/bin/python server.py
```

**Config:** Via environment variables (NOT `.env` file — `server.py` reads `os.getenv()` directly, `.env` is only sourced by `start.sh`/`bootstrap.py`)

| Env var | Default | Description |
|---------|---------|-------------|
| `HERMES_WEBUI_HOST` | `127.0.0.1` | Bind address |
| `HERMES_WEBUI_PORT` | `8787` | Port |
| `HERMES_WEBUI_AGENT_DIR` | Auto-discovered | Path to hermes-agent checkout |
| `HERMES_WEBUI_PYTHON` | Auto-discovered | Python executable (use agent venv) |
| `HERMES_HOME` | `~/.hermes` | Base Hermes directory |
| `HERMES_WEBUI_PASSWORD` | *(none)* | Enable password auth for 0.0.0.0 binding |
| `HERMES_WEBUI_STATE_DIR` | `~/.hermes/webui` | Session storage directory |

**Current state (May 2026):** Running at `0.0.0.0:8787` with no password set. Anyone on the local network can access it. Recommend setting `HERMES_WEBUI_PASSWORD` when locking down.

**Hardware:** ~100MB RSS resident, 0% CPU at idle. No database, no framework, no build step.

**Process management:** Started via background terminal (PID visible via health check at `/health`). Not yet under systemd supervision.

**State directory:** `~/.hermes/webui/` — sessions live as individual JSON files in `sessions/`, projects in `projects.json`, settings in `settings.json`. No database dependency.

**Version:** v0.51.14 (check by inspecting `server_version` in server.py or the HTML meta).

### Pitfall: Configuration from .env vs env vars

`server.py` reads `os.getenv("HERMES_WEBUI_HOST", "127.0.0.1")` — it does NOT source the `.env` file. The `.env` file is only used by `start.sh` and `bootstrap.py`. To pass config when running `server.py` directly, set the env var inline:

```bash
# This works:
HERMES_WEBUI_HOST=0.0.0.0 python server.py

# This does NOT work (.env is ignored by server.py):
# .env contains HERMES_WEBUI_HOST=0.0.0.0
python server.py
```

If adding to `.env` for documentation purposes, the `start.sh` wrapper picks it up.

## Gateway Idle Session Timeout (Planned)

Since the Gateway only serves the default profile (you), there's no multi-god complexity. But a **30-minute session idle timeout** is planned to maintain low memory footprint for the default profile.

**What it does:**
- Each Gateway session tracks a `last_active_at` timestamp
- A background cleanup thread runs every minute
- Sessions idle >30min get garbage-collected (conversation history, agent context freed)
- Your active Telegram/Discord threads stay live because they're constantly being used

**Where it lives:** `gateway/session.py` — the Session dataclass needs a `last_active_at` field and the Gateway needs a daemon thread that sweeps stale sessions.

**Status:** Feature identified, not yet implemented.

## References

| Reference file | Contents |
|----------------|----------|
| `references/cron-and-heartbeat-notes.md` | Session-specific setup commands, path bug reproduction, and commands used in this session |
| `references/embedding-health-diagnostics.md` | ChromaDB vs KNOWN_CODEXES inventory, cross-session embedding gap persistence, diagnostic commands |
| `references/embedder-provider-pitfalls.md` | OpenRouter key validation bug in MCP server, Ollama chunking fix for reembed script, dimension change, files that failed without chunking |
| `references/pantheon-frontend-architecture.md` | Pantheon frontend build on hermes-webui — tech stack, JS module inventory, DESIGN.md spec, Pantheon concept mapping, adapted phase plan (vanilla JS, not React). Load when planning any frontend work. |
|