#!/usr/bin/env python3
"""Overnight inbox summary for Pantheon Bridge.
Scans all god inboxes and reports messages from the last N hours.

Standard usage for morning briefing: runs before the agent prompt,
its stdout is prepended as context. Output format:

    === OVERNIGHT_INBOX ===
    MSG:<id>|to:<god>|from:<god>|subject:<subject>
      → <body preview (first 200 chars)>
    ...
    TOTAL:<count> message(s) in the last <N>h

If no messages found: prints "SILENT — no overnight messages"

Adapt: change CUTOFF_HOURS for different windows (e.g. CUTOFF_HOURS=24 for daily)."""

import json
import os
import glob
from datetime import datetime, timezone, timedelta

MESSAGES_DIR = os.path.expanduser("~/pantheon/gods/messages")
CUTOFF_HOURS = 12
CUTOFF = datetime.now(timezone.utc) - timedelta(hours=CUTOFF_HOURS)

inbox_dirs = sorted(glob.glob(os.path.join(MESSAGES_DIR, "*")))

print("=== OVERNIGHT_INBOX ===")

total_new = 0
for inbox_dir in inbox_dirs:
    god_name = os.path.basename(inbox_dir)
    new_msgs = []

    for msg_file in sorted(glob.glob(os.path.join(inbox_dir, "msg_*.json"))):
        try:
            with open(msg_file) as f:
                msg = json.load(f)
            ts = msg.get("timestamp", "")
            if not ts:
                continue
            try:
                msg_time = datetime.fromisoformat(ts)
                if msg_time.tzinfo is None:
                    msg_time = msg_time.replace(tzinfo=timezone.utc)
            except (ValueError, TypeError):
                continue

            if msg_time >= CUTOFF:
                new_msgs.append(msg)
        except (json.JSONDecodeError, IOError):
            continue

    if new_msgs:
        total_new += len(new_msgs)
        for msg in new_msgs:
            from_g = msg.get("from", "?")
            subject = msg.get("subject", "No subject")
            body = msg.get("body", "")
            preview = body[:200].replace("\n", " | ") if body else ""
            print(f"MSG:{msg.get('id','?')}|to:{god_name}|from:{from_g}|subject:{subject}")
            if preview:
                print(f"  → {preview}")

if total_new == 0:
    print("SILENT — no overnight messages")
else:
    print(f"\nTOTAL:{total_new} message(s) in the last {CUTOFF_HOURS}h")
