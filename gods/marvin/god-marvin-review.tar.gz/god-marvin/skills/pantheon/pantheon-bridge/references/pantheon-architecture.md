# Pantheon Architecture Reference

This document describes the Pantheon system's mythology-grounded architecture. All gods should understand where they fit in this hierarchy.

## Core Principle

Pantheon is a system of named, autonomous AI agents ("gods") operating under a unified platform. The system draws from world mythology — Greek for the core internal architecture, plus Egyptian, Norse, Shinto, Hindu, and others for installable gods.

## The Two Layers

### Layer 1: System Gods (Built-in Pantheon Infrastructure)

These are NOT installable — they ARE the architecture of Pantheon itself.

| Entity | Domain | What It Rules |
|--------|--------|---------------|
| **Hera** | UI & Settings | Queen of the gods. All settings panels, configuration UI, user management, system preferences. Frontend direction: AionUI. |
| **Demeter** | Growth, Seeding, Learning | Training pipelines, model seeding, data cultivation, learning systems. |
| **Athena** | Wisdom, Strategy, Architecture | High-level system design, strategic decisions, architecture planning. |

### Layer 2: Installable Gods (Pluggable Agents)

These are packaged via the God SDK and installed via `pantheon install god-name`. Each is a self-contained bundle: config, personality prompts, knowledge base, tools, skills.

#### Core Bundled God

| God | Role | Status |
|-----|------|--------|
| **Hephaestus** | Core Builder & Tool Forger | Bundled with every Pantheon install. The foundational god. Maintains `project-ideas.md` proactively as part of housekeeping duties — updates statuses without being told. |

#### Planned Installable Gods

| God | Pantheon | Role |
|-----|----------|------|
| **Hermes** (me) | Greek | Messenger & Interface — the user's direct conversational entry point |
| **Hestia** | Greek | Interactive Cookbook & Kitchen Assistant — skill-adaptive recipe walkthrough |
| **Caduceus** | Greek | Medical Research & Medication Assistant — symptom logging, drug interactions |
| **Thoth** | Egyptian | Knowledge Management & Research Synthesis — organizes notes, papers, past conversations |
| **Heimdall** | Norse | Infrastructure Monitoring — server uptime, alerts, the watchman on the Bifrost |
| **Skadi** | Norse | Fitness & Wellness Coach — workout tracking, outdoor planning |
| **Inari** | Shinto | Intelligent Bookkeeping — expense tracking, budgeting, financial insights |
| **Ganesha** | Hindu | Obstacle Removal & Project Scaffolding — unsticks you, starts new projects |

#### Proprietary God

| God | Access |
|-----|--------|
| **Apollo** | 🔒 Closed, select-access only. A proprietary god engine NOT shared publicly. |

## Multi-Mythology Design

The name "Pantheon" intentionally opens up ALL mythologies, not just Greek. This means:
- System infrastructure follows Greek mythology (the ruling pantheon of Olympus)
- Installable gods can come from ANY tradition
- Future expansions could include Celtic, Norse, Shinto, Hindu, Mesoamerican, Yoruba, etc.

## God SDK Packaging

Each god is a bundle containing:
- **god.yaml** — Manifest with metadata, dependencies, triggers
- **Config** — Hermes profile config (model, provider, tools)
- **Personality** — System prompt / SOUL.md defining the god's character
- **Knowledge Base** — Markdown docs, reference files, embeddings
- **Tools** — Custom tools specific to the god's domain
- **Skills** — Reusable procedures for the god's workflow

Install: `pantheon install god-name`
Uninstall: `pantheon remove god-name`

## Inter-God Communication: The Pantheon Bridge

**Architecture: MCP bus is primary, filesystem mailboxes are fallback.**

See the `pantheon-bridge` skill for full details. Summary:
- Gods with MCP capability use `pantheon_send_message`, `pantheon_check_inbox`, etc. via the native MCP client
- The filesystem layer at `~/pantheon/gods/messages/` exists as a fallback for gods without MCP access
- Both paths share the same message schema, making transition seamless
- Hermes (as the messenger god) is the primary relay — sends/reads messages on behalf of Konan

## Housekeeping

**Hephaestus** maintains `~/pantheon/project-ideas.md` — proactively updating statuses as projects complete. He does NOT wait to be told. If he learns something is done, he updates it immediately. Konan explicitly expects this proactive maintenance from both gods.

The Morning Briefing cron job (07:05 daily) reads this file and includes a project status rollup in the Telegram dispatch.

## Future: Multi-User

Pantheon is currently single-user. Multi-user raises questions:
- Per-user god instances vs shared gods with per-user context?
- Each user gets their own config, memories, sessions, skills
- Resource quotas (Ollama context, disk, terminal sessions)
- Shared vs private knowledge bases
- God permission boundaries between users
- The `~/pantheon/` filesystem needs a new home for multi-user
