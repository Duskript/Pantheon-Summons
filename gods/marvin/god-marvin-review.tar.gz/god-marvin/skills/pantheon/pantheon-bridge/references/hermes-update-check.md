# Hermes Agent Update Check

A bash script at `~/.hermes/scripts/check-hermes-update.sh` that checks for new Hermes Agent releases and prints categorized patch notes. Integrated into the Morning Briefing pipeline.

## How It Works

1. Reads current version from `~/.hermes/hermes-agent/VERSION` or git describe
2. Fetches the latest release tag via `git tag -l 'v*' --sort=-v:refname`
3. Compares — if current ≠ latest, prints categorized commit log between tags:
   - **Features** (commits matching `^feat`)
   - **Fixes** (commits matching `^fix`)
   - **Other** (everything else, limited to 20 lines to avoid bloat)

## Output Format

```
[HERMES-UPDATE] Current: v2026.4.23
[HERMES-UPDATE] Latest:  v2026.4.30
[HERMES-UPDATE] Status: ⬆️  Update available
[HERMES-UPDATE] == Patch Notes (v2026.4.23 → v2026.4.30) ==
[HERMES-UPDATE] Features:
[HERMES-UPDATE]   • feat(gateway): native send_multiple_images for Telegram...
[HERMES-UPDATE]   • ...
[HERMES-UPDATE] Fixes:
[HERMES-UPDATE]   • fix(deepseek): preserve v4 reasoning_content on replay...
```

If up to date, output is minimal: `[HERMES-UPDATE] Status: ✅ Up to date`

## Integration

Called from `~/.hermes/scripts/morning-briefing.sh` between the overnight inbox scan and the hermes-news section:

```python
print("\n=== HERMES_UPDATE_CHECK ===")
subprocess.run(["bash", "/home/konan/.hermes/scripts/check-hermes-update.sh"], check=False)
```

The `[HERMES-UPDATE]` prefix ensures output is parseable in the briefing prompt context — the agent can grep for `Status:` to detect whether a new version exists, then summarize the patch notes in a human-readable form.
