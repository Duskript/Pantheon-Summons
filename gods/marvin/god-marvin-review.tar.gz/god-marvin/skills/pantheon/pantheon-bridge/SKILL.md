---
name: pantheon-bridge
description: "Inter-god communication for Pantheon. MCP tools are the primary path; filesystem inboxes serve as a fallback when MCP is unavailable."
version: 1.1.0
---

# Pantheon Bridge — Inter-God Communication

The Pantheon Bridge is the messaging layer that lets gods talk to each other. **MCP (Model Context Protocol) tools are the primary communication path.** The filesystem mailbox system (`~/pantheon/gods/messages/`) exists as a fallback when MCP is unavailable or for god-to-god relay scenarios.

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                   MCP BUS (Primary)                  │
│  pantheon_send_message()   pantheon_check_inbox()   │
│  pantheon_mark_read()      pantheon_list_gods()     │
├─────────────────────────────────────────────────────┤
│                                                     │
│              ⬇ Falls back to ⬇                      │
│                                                     │
│         Filesystem Mailboxes (Fallback)             │
│  ~/pantheon/gods/messages/{god}/msg_*.json          │
│                                                     │
└─────────────────────────────────────────────────────┘
```

**Rule:** If MCP tools are available, use them. The filesystem is a fallback — it's there for edge cases and for gods that don't have MCP access yet. When a god has native MCP capability, that's the primary channel.

## Directory Structure (Fallback Layer)

```
~/pantheon/gods/
├── messages/
│   ├── hermes/          ← Inbox for Hermes
│   │   ├── hermes-inbox.json    ← Index of all messages for Hermes
│   │   └── msg_*.json           ← Individual messages
│   ├── hephaestus/     ← Inbox for Hephaestus
│   ├── hades/          ← Inbox for Hades
│   └── ...             ← One inbox per god
├── gods.yaml           ← Registry of all known gods and their capabilities
└── README.md           ← Documentation
```

## Primary: MCP Bus

Gods with MCP capability (like Hermes) use MCP tools directly. The Hermes Agent's native MCP client connects to the Pantheon Bridge MCP server (configured in `config.yaml`) and the tools auto-register.

MCP tools provided by the Pantheon Bridge server:

| MCP Tool | Purpose |
|----------|---------|
| `pantheon_send_message` | Send a message from one god to another |
| `pantheon_check_inbox` | Check a god's inbox for unread messages |
| `pantheon_mark_read` | Mark a message as read |
| `pantheon_list_gods` | List all registered gods and their statuses |

## Fallback: File-based Messaging

When MCP is not available (e.g. a god doesn't have MCP client support yet, or the MCP server is down), fall back to the filesystem.

Message format (same schema used by both paths):

```json
{
  "id": "msg_20260429_0001",
  "from": "hephaestus",
  "to": "hermes",
  "type": "report",
  "subject": "God SDK scaffold complete",
  "body": "The initial manifest format is ready for review.",
  "priority": "normal",
  "timestamp": "2026-04-29T12:00:00Z",
  "read": false,
  "payload": {},
  "thread_id": null
}
```

Message types:
- `report` — A deliverable or result (e.g. "Hades Report ready")
- `request` — Asking another god for something
- `notification` — Status update, no action needed
- `data` — Raw data payload for another god to process
- `alert` — Something needs attention NOW
- `handoff` — Passing a task to another god

## Commands

### For Konan (you ask me, I handle it):
- "Any messages for me?" → Check your inbox (MCP if available, otherwise filesystem)
- "Send a message to Hephaestus saying X" → Send via MCP bus; fall back to filesystem if MCP is down
- "Forward [subject] to [god]" — Relay between gods
- "Show me recent messages between gods" — Conversation history

### Priority: MCP First

When I (Hermes) send a message:
1. **Try MCP first** — use `pantheon_send_message` via the native MCP client
2. **Fall back to filesystem** — if MCP unavailable, write JSON to recipient's inbox folder + update their inbox index

When I read messages:
1. **Try MCP first** — use `pantheon_check_inbox`
2. **Fall back to filesystem** — check inbox index, read msg files

## Nightly / Morning Workflow

The Pantheon Bridge feeds into the **Morning Briefing** (07:05 daily, delivered to Konan on Telegram). The pipeline:

1. **07:00** — Hades runs Athenaeum consolidation pipeline → saves report to `~/athenaeum/Codex-Pantheon/reports/hades-YYYY-MM-DD.md`
2. **07:05** — Morning Briefing cron fires, runs `~/.hermes/scripts/morning-briefing.sh` which collects:
   - The latest Hades report from the Athenaeum
   - `~/pantheon/project-ideas.md` (the full project list)
   - Overnight inbox scan (all god messages from the last 12 hours)
   - **Hermes Agent update check** — runs `check-hermes-update.sh` to detect new releases with patch notes (see `references/hermes-update-check.md`)
3. The agent composes a dispatch with Hades results × inbox summary × project status rollup × **release update**

The overnight inbox scanner lives at `scripts/overnight-inbox-scan.py` under this skill. It scans all `~/pantheon/gods/messages/*/msg_*.json` files from the last 12 hours. See the script for the exact output format — it's designed to be stdout-piped into cron prompts.

## Monitoring & Inbox Scanning

For morning briefings, overnight inbox summaries, or periodic bridge health checks, use a time-windowed scan across all god inboxes:

```python
#!/usr/bin/env python3
\"\"\"Scan all god inboxes for messages within the last N hours.\"\"\"
import json, glob, os
from datetime import datetime, timezone, timedelta

MESSAGES_DIR = os.path.expanduser("~/pantheon/gods/messages")
CUTOFF = datetime.now(timezone.utc) - timedelta(hours=12)

for inbox_dir in sorted(glob.glob(os.path.join(MESSAGES_DIR, "*"))):
    god_name = os.path.basename(inbox_dir)
    for msg_file in sorted(glob.glob(os.path.join(inbox_dir, "msg_*.json"))):
        with open(msg_file) as f:
            msg = json.load(f)
        ts = msg.get("timestamp", "")
        if ts:
            msg_time = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            if msg_time >= CUTOFF:
                print(f"{msg.get('to','?')} ← {msg.get('from','?')}: {msg.get('subject','')}")
```

This is used by the Morning Briefing cron (07:05 daily) via `~/.hermes/scripts/overnight-inbox.py`. The script is run *before* the prompt — its stdout is prepended as context for the agent to compose the briefing.

**Pitfalls:**
- Timezone-naive timestamps need `.replace(tzinfo=timezone.utc)` — always normalize to UTC
- Read-only scan — do NOT mark messages as read during scan (that's the inbox watcher's job)
- For cron jobs: put the scan in a separate script, reference it via `cronjob(script="...")` in Hermes' cron system

## God Registry (`gods.yaml`)

```yaml
gods:
  hermes:
    display_name: Hermes
    role: Messenger & Interface
    capabilities:
      - chat
      - message_relay
    status: active

  hephaestus:
    display_name: Hephaestus
    role: Core Builder & Tool Forger
    capabilities:
      - tool_building
      - code_generation
      - project_scaffolding
    status: active
```

## Setup

The directory structure is created once and shared across all god profiles via the shared `~/pantheon/` directory, which all profiles already have access to since they share the same filesystem.
