# User Inquiry Protocol — Konan

This doc captures how to handle **inquiry/feasibility questions** from Konan. These are questions like "Can U55 support X?" or "Would this work?".

## The Pattern

Konan asks about **whether something works** or **what the impact would be**. Answer directly with facts. Do NOT:

- Start checking installation status or dependencies
- Propose setup steps or configuration commands
- Offer to implement or wire things up
- Begin any action-oriented workflow

The single exception: if the question requires live data to answer (e.g. current RAM usage, disk space), collect that data then stop. Do not extend into installation.

## Why

Konan's process is:

1. **Feasibility & impact assessment** — can it work? what does it cost?
2. **Architecture fit** — how does it integrate with existing systems?
3. **Implementation** — only after steps 1-2 are resolved

Jumping ahead to step 3 is a distraction and a correction signal. He will explicitly say when he wants action taken ("set it up," "install it," "wire it up").

## Trigger Words

Phrases that mean "assessment only, no action":
- "would [X] be able to [Y]?"
- "what's the hardware impact?"
- "how does [X] work with [Y]?"
- "what does [X] look like?"
- "can [machine] support [X]?"

## Example Flow

**Konan:** "Can the U55 support Pantheon + LiteLLM?"
**✅ Correct:** Answer with facts. Specs, resource impact, feasibility verdict.
**❌ Wrong:** Start checking if LiteLLM is installed, propose installation, check pip status, offer to set up systemd service.

**Konan after assessment:** "Perfect. Now how does that work with profiles?"
**✅ Correct:** Answer the architectural/design question. Stay in assessment mode.
**❌ Wrong:** Offer to wire it up or start implementing.

**Konan says:** "Set it up" / "Install it" / "Wire it up" / "Let's do it"
**→ Action mode is now open.** Proceed with implementation.

## LiteLLM-specific Notes

LiteLLM is a light Python proxy (~100-500MB RAM, near-zero CPU). Acts as OpenAI-compatible endpoint routing by model name. Each Pantheon god points at the same LiteLLM endpoint but requests a different model name → LiteLLM routes to the correct backend (Ollama Cloud, Anthropic, OpenAI on-demand). Resource impact on a machine like U55 (7.2GB RAM, i3-5005U) is negligible.
