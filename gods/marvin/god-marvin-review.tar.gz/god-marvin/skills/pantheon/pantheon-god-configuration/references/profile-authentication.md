# Profile Authentication for Provider Migrations

When migrating a Pantheon god from one provider to another, do not assume the profile can reuse the main Hermes auth state automatically.

## Key Detail

Hermes profiles can have their own `auth.json`:
- Main auth: `~/.hermes/auth.json`
- Profile auth: `~/.hermes/profiles/{god}/auth.json`

A profile may show the new provider in `config.yaml` but still fail inference if the profile-local `auth.json` has no credentials for that provider.

## Observed Failure Mode

With `model.provider: openai-codex` and `model.default: gpt-5.4`, a direct test returned:

`No Codex credentials stored. Run \`hermes auth\` to authenticate. Run \`hermes model\` to re-authenticate.`

Doctor also reported:
- `OpenAI Codex auth (not logged in)`
- `No Codex credentials stored.`

## Fast Recovery

If the main Hermes profile already has working auth for the same provider, seed the god profile's auth file from the main one.

Example procedure:

1. Back up the profile auth file.
2. Copy only the provider entry needed (for example `openai-codex`) from `~/.hermes/auth.json` into `~/.hermes/profiles/{god}/auth.json`.
3. Preserve the profile file's other keys.
4. Restart the god gateway.
5. Verify with a one-shot inference test:
   - `hermes --profile {god} chat -q "Reply with exactly: ok" --quiet`

## Verification Checklist

- `hermes profile show {god}` reports the expected provider/model
- `hermes --profile {god} doctor` no longer blocks on missing provider auth
- A direct `hermes --profile {god} chat -q ...` call succeeds
- `systemctl --user restart hermes-gateway-{god}` comes back clean

## Notes

- Keep a timestamped backup of `auth.json` before editing.
- This is especially relevant for `openai-codex`, where working root auth does not guarantee the Pantheon god profile can use it.