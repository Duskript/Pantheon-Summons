# Ollama Cloud Models: Vision + Coding Capabilities

Research conducted 2026-05-02 for Hephaestus model selection. Ollama Pro provides cloud-hosted models via the `:cloud` tag.

## The Shortlist

Models on Ollama that support **vision** AND have **cloud** tags:

| Model | Vision | Coding | Context | Tags on Ollama |
|-------|--------|--------|---------|----------------|
| **kimi-k2.6:cloud** | ✅ Image | 🏆 Long-horizon coding, agent swarms | 256K | `cloud` only |
| gemma4:cloud | ✅ Image | General purpose | — | `31b-cloud` |
| deepseek-v4-flash:cloud | ✅ Image | Fast, general | — | `cloud` |
| ministral-3:cloud | ✅ Image | Small model | — | `cloud` |
| devstral-small-2:cloud | ✅ Image | Small/experimental | — | `cloud` |

## Models with NO vision (coding-focused)

| Model | Coding | Context | Notes |
|-------|--------|---------|-------|
| deepseek-v4-pro:cloud | 🏆 Best pure reasoning | 1M tokens | No vision |
| qwen3-coder-next:cloud | 🏆 80B/3B MoE, agentic | 256K | Text only |
| glm-5.1:cloud | 🏆 SOTA SWE-Bench | 198K | Text only |

## Key Finding

**Kimi K2.6:cloud** is the **only model on Ollama Pro** that combines:
- Vision (accepts images)
- State-of-the-art agentic coding (long-horizon, swarms of 300 sub-agents)
- Native tool use and function calling
- Cloud-hosted (no GPU required)

This made it the top pick for Hephaestus, replacing `deepseek-v4-flash:cloud`.

## The `:cloud` Tag Pattern

Models on Ollama with `:cloud` in their tag name are routed through Ollama's cloud infrastructure rather than running locally. With Ollama Pro, this is the primary way to access frontier models without a local GPU.

Not all models have a `:cloud` variant — some only offer local quantized versions. Check the model's tags page on ollama.com to confirm.
