# OpenCode Go Model Roster

> Live as of 2026-05-06. Verify current roster with:
> `curl -s https://opencode.ai/zen/go/v1/models -H "Authorization: Bearer $OPENCODE_GO_API_KEY"`

## Available Models

| Model | Tier | Best For |
|-------|------|----------|
| `deepseek-v4-pro` | Flagship | Heavy coding, reasoning, complex tool calling |
| `deepseek-v4-flash` | Budget | Fast/cheap, decent tool calling, lighter reasoning |
| `kimi-k2.6` | Mid-tier | Long-form creative, 1M+ context, solid tool calling |
| `kimi-k2.5` | Mid-tier (prev gen) | Same family, slightly weaker than 2.6 |
| `qwen3.6-plus` | Sweet spot | Creative + tool calling best-value. Strong instruction following, excellent function calling, competitive pricing |
| `qwen3.5-plus` | Mid-tier (prev gen) | Previous Qwen generation, still capable |
| `glm-5.1` | Mid-tier | GLM by Zhipu, bilingual, solid utility model |
| `glm-5` | Mid-tier (prev gen) | Same family, slightly weaker |
| `minimax-m2.7` | Niche | Long-form narrative generation, but tool calling historically weaker |
| `minimax-m2.5` | Niche (prev gen) | Same family |
| `mimo-v2-pro` | Unknown quality | Minimal ecosystem info |
| `mimo-v2-omni` | Multimodal | Image+text capable version of MIMO |
| `mimo-v2.5-pro` | Unknown quality | Newer MIMO variant |
| `mimo-v2.5` | Unknown quality | Standard MIMO |

## Recommendation Matrix

| Use Case | Best Pick | Runner-Up |
|----------|-----------|-----------|
| Creative writing + tool calling | `qwen3.6-plus` | `kimi-k2.6` |
| Heavy coding / engineering | `deepseek-v4-pro` | `qwen3.6-plus` |
| Budget conscious, any task | `deepseek-v4-flash` | `qwen3.5-plus` |
| Long-form narrative | `kimi-k2.6` | `minimax-m2.7` |
| Multimodal (image+text) | `mimo-v2-omni` | — |

## Pricing Notes

OpenCode Go is a flat subscription model — exact per-token pricing not exposed via API. These models tend to be cheaper than equivalent OpenAI/Antrophic API endpoints. The `-flash` and `-plus` variants are typically the most cost-effective.

## Access

All opencode/* models route through the Pantheon LiteLLM proxy:

```yaml
# In ~/litellm-config.yaml, each model maps to:
model_name: opencode/{model-name}
litellm_params:
  model: openai/{model-name}
  api_base: https://opencode.ai/zen/go/v1
  api_key: os.environ/OPENCODE_GO_API_KEY
```

Models NOT available on OpenCode Go (as of this writing): gemma4, claude, gpt-4o, llama-4. These route through Ollama cloud or other providers.
