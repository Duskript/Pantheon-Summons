# LiteLLM as Model Routing Proxy for Pantheon

LiteLLM is a lightweight HTTP proxy that exposes an OpenAI-compatible API endpoint and routes requests to multiple backends based on model name. This enables Pantheon gods to all point at one endpoint while LiteLLM handles provider routing.

## Resource Profile

| Resource | Impact |
|----------|--------|
| RAM | ~100-300MB idle, ~500MB under load |
| CPU | Near zero at rest, minimal per request (routing/formatting only) |
| Disk | ~150-200MB for `pip install litellm` + deps |
| GPU | Zero — LiteLLM does no inference |

## Architecture

```
                    ┌──────────────────┐
Hermes  ──model──►  │                  │
(deepseek-v4-flash) │    LiteLLM       │──► Ollama Cloud (deepseek-v4-flash)
                    │   on U55          │
Hephaestus ─model─► │   :4000           │──► Ollama Cloud (kimi-k2.6)
                    │                  │
Apollo ────model─►  │                  │──► Anthropic (claude-sonnet-4)
                    └──────────────────┘
```

## Routing Model

Each Hermes Agent god profile points at the same LiteLLM endpoint but specifies a different `model` name:

```yaml
# hermes profile
provider: openai          # LiteLLM speaks OpenAI-compatible API
base_url: http://pantheon:4000
model: deepseek-v4-flash:cloud

# hephaestus profile  
provider: openai
base_url: http://pantheon:4000  # same endpoint!
model: kimi-k2.6:cloud          # different model → different routing
```

LiteLLM's config.yaml maps model names to actual backends:

```yaml
model_list:
  - model_name: deepseek-v4-flash:cloud
    litellm_params:
      model: openai/deepseek-v4-flash
      api_base: https://ollama.cloud...
  - model_name: kimi-k2.6:cloud
    litellm_params:
      model: openai/kimi-k2.6
      api_base: https://ollama.cloud...
```

## Why It Fits the U55

U55 has 7.2GB RAM, dual-core i3-5005U, no GPU. LiteLLM's 200-500MB RAM and near-zero CPU impact is negligible on this hardware. The U55 becomes a routing gateway — all inference still happens on Ollama Cloud / Anthropic / OpenAI servers.

## Web UI

LiteLLM ships a web UI at `http://pantheon:4000/ui` for:
- Usage dashboard (token counts, spend, request logs)
- Key management
- Model listing
- Test playground

Model backend configuration remains YAML-based (config.yaml + restart). The admin API (`POST /model/new`, `DELETE /model/{id}`, `GET /models`) could enable UI-driven model management in the future.

## Key Insight for Unified Frontend

LiteLLM's admin API + Pantheon Bridge (MCP inter-god messaging) could enable a single control panel where one click both adds the model backend to LiteLLM AND updates the god profile — no manual config editing.
