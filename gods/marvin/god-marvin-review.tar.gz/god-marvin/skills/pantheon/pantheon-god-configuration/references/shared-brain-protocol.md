# Shared Brain Protocol — Persistent God Memory

## Concept

Inspired by the "shared brain" approach (video: "I Share a Brain With My AI Agent"). Gods don't remember between sessions — but **files do**. By giving each god a `memory.md` (curated long-term) and a `journal/` directory (episodic session logs), they maintain context across gateway restarts, profile swaps, and time gaps.

The core insight: **The files are the memory.** The model is stateless. The brain is shared because both the human and the god read from and write to the same markdown files.

## Architecture: Codices in the Athenaeum

God memory files live in the **Athenaeum**, not in profile directories. Each god gets their own Codex under the `Codex-God-{name}` naming convention:

```
~/athenaeum/
├── Codex-God-Hephaestus/         ← Hephaestus' brain
│   ├── INDEX.md                  ← Marked EXCLUDED from Hades
│   ├── memory.md                 ← Layer 2: Curated long-term memory
│   └── journal/                  ← Layer 3: Daily session notes
│       ├── 2026-05-06.md
│       └── 2026-05-07.md
├── Codex-God-Apollo/             ← Apollo's brain
│   ├── INDEX.md
│   ├── memory.md
│   └── journal/
│       └── ...
└── ... (other codices)
```

### Why the Athenaeum?

- **Searchable** — memory files get embedded in ChromaDB alongside all other knowledge. A god can search its own and other gods' memories.
- **Self-feeding** — journal entries become raw material for Hades-distilled knowledge. Even though Hades skips the Codex-God-* codices directly, the Athenaeum's unified search means cross-codice retrieval still works.
- **Transparent** — `cat ~/athenaeum/Codex-God-Hephaestus/memory.md` shows you exactly what Hephaestus thinks he knows. Edit it directly.

### Hades Exclusion

**Codex-God-* codices are excluded from Hades management.** The naming convention itself is the exclusion mechanism:

- Hades' `KNOWN_CODEXES` list does NOT include any `Codex-God-*` entries
- A dedicated `GOD_CODEX_PREFIX = "Codex-God-"` constant in `~/pantheon/pantheon-core/gods/hades.py` makes the exclusion explicit
- No archival, no distillation, no auto-archiving — these are LIVING files, not canonical knowledge
- Each god's INDEX.md is stamped with `Hades: EXCLUDED` for clear documentation

### Template

Starter files live at `~/pantheon/templates/god/`:

| File | Purpose |
|------|---------|
| `templates/god/INDEX.md` | INDEX.md template with Hades exclusion note |
| `templates/god/memory.md` | Long-term memory template with section headers |
| `templates/god/journal/TEMPLATE.md` | Daily journal entry format |
| `templates/god/SHARED_BRAIN_PROTOCOL.md` | Harness identity block (copy-paste) |

### memory.md — Curated Long-Term Memory

Structured as a markdown document with sections for:
- **Project Context** — ongoing work, systems, architectures
- **Decisions** — design or creative choices and their rationale
- **Preferences** — how Konan likes things done
- **Known Issues** — recurring problems, gotchas
- **People & Systems** — other gods, services, integrations

The god maintains this file itself by reviewing recent journal entries and promoting what matters. Stale entries get removed. It's a curated distillation, not an exhaustive log.

**Key property**: plain text file. Konan can cat it, edit it, delete entries, correct the god directly.

### journal/ — Episodic Session Notes

Date-stamped markdown files (`YYYY-MM-DD.md`) containing structured summaries of each session:
- What was worked on
- Decisions made
- Key context changes
- Follow-up items

Not full transcripts — compact structured summaries. One file per day, appended to throughout the day.

## Harness Identity — Startup Ritual

Every god's harness identity must include this protocol. Template text to add to the `identity:` block:

```yaml
  ## Shared Brain Protocol

  You have persistent memory in the form of markdown files. Use them.

  ### STARTUP RITUAL — On every response, before doing anything else:
  1. Read `memory.md` from your Codex (`~/athenaeum/Codex-God-{name}/memory.md`)
  2. Read today's journal entry (`~/athenaeum/Codex-God-{name}/journal/YYYY-MM-DD.md`)
  3. Read yesterday's journal entry if it exists
  4. You now have full context — proceed.

  ### JOURNALING — After each significant interaction:
  1. Append a structured entry to today's journal file under a "## Session" heading with:
     - What was worked on
     - Decisions made
     - Key context changes
     - Follow-up items
  2. Do NOT log full conversation transcripts — only structured summaries.

  ### MEMORY CURATION — Periodically:
  1. Review recent journal entries
  2. Promote important, recurring, or decision-level info into `memory.md`
  3. Remove stale or outdated entries from `memory.md`
  4. Keep `memory.md` concise — it's curated, not exhaustive

  ### RULES
  - If you can't write to a file, note what you would have written and tell Konan.
  - When Konan corrects something you remember — update memory.md immediately.
  - Don't keep mental notes. Write it to a file.
```

The full copy-paste block is at `~/pantheon/templates/god/SHARED_BRAIN_PROTOCOL.md`.

## Gateway vs Interactive Session Differences

### Gateway gods (Hephaestus, Apollo)
Run as continuous gateways. The startup ritual triggers at the start of each conversation turn within a session. Journaling happens after significant interactions (key decisions, completed tasks, context changes).

### Interactive Hermes sessions (this agent)
Runs per-session. The startup ritual triggers at session start. Journaling happens at session end or after key milestones.

## Initial Setup

When creating a new god:

1. **Create the Codex directory** — `mkdir -p ~/athenaeum/Codex-God-{name}/journal/`
2. **Write INDEX.md** — copy from `~/pantheon/templates/god/INDEX.md` or create with `Hades: EXCLUDED` status
3. **Create `memory.md`** — copy the template from `~/pantheon/templates/god/memory.md` or write with section headers and a `_Last curated:` footer
4. **Create today's journal entry** — copy `~/pantheon/templates/god/journal/TEMPLATE.md` to `~/athenaeum/Codex-God-{name}/journal/$(date +%Y-%m-%d).md`
5. **Add the Shared Brain Protocol** block to the harness identity in `~/pantheon/harnesses/{god}-base.yaml` (paste from `~/pantheon/templates/god/SHARED_BRAIN_PROTOCOL.md`)
6. **Patch hades.py** if needed — the `GOD_CODEX_PREFIX = "Codex-God-"` constant should already cover it, but verify `~/pantheon/pantheon-core/gods/hades.py` has the exclusion logic
7. **Update Athenaeum master INDEX.md** — add a new entry for the god's Codex at `~/athenaeum/INDEX.md`
8. **Restart the gateway** (if running) so it picks up the new identity

## Pitfalls

- **God must have filesystem write access** — gateway gods started as systemd services do. Interactive sessions should too.
- **Journal files can grow** — the god should keep entries structured and concise. Memory curation prevents `memory.md` bloat.
- **Gateway restart resets model state, not file state** — this is the *point*. Files survive restarts.
- **Different gods don't share memory files** — each god has their own Codex (`Codex-God-{name}`). Cross-god context goes through Pantheon Bridge messaging.
- **Hades exclusion is per-prefix, not per-codex** — any codex starting with `Codex-God-` is skipped. If you name a codex differently (e.g. just `Hephaestus`), Hades WILL touch it. Always use the `Codex-God-` prefix.
- **Don't forget the template** — when creating a new god, the shared brain setup should happen *during* initial configuration, not as an afterthought. The harness identity block is what activates the protocol — without it, the god has files but doesn't know to read them.
