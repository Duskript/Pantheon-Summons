---
name: pantheon-god-configuration
description: "Configure, update, and manage Pantheon gods — model selection, harness edits, profile config, platform deployment (Discord), gateway lifecycle, and verification."
version: 1.0.0
---

# Pantheon God Configuration

Configuring a Pantheon god's **model, harness, profile, and gateway lifecycle**. Covers swapping models (e.g. `deepseek-v4-flash:cloud` → `kimi-k2.6:cloud`), updating behavior via harness YAML, and restarting reliably.

## Associated References

Skill references (view via `skill_view(name='pantheon-god-configuration', file_path='references/<file>')`):
| File | Contents |
|------|----------|
| `references/ollama-cloud-models.md` | Ollama Pro cloud model capabilities matrix (vision, coding, context) |
| `references/profile-authentication.md` | Seeding profile auth.json when migrating god providers |
| `references/user-inquiry-protocol.md` | How to handle feasibility/inquiry questions from Konan — assessment mode vs action mode |
| `references/litellm-proxy.md` | LiteLLM as a model routing proxy for Pantheon — resource profile, architecture, routing model |
| `references/opencode-models.md` | OpenCode Go model roster, recommendation matrix, pricing notes |
| `references/shared-brain-protocol.md` | Persistent memory via `memory.md` + `journal/` — startup ritual, journaling format, memory curation. Required for all gods. |
| `references/discord-deployment-session.md` | Session log: multi-god Discord deployment — bot tokens, channel IDs, isolation fixes |

This skill operates across **two configuration layers** that must stay in sync:

```
Pantheon God Config
├── Hermes Profile      ~/.hermes/profiles/{god}/config.yaml
│   ├── model.default
│   ├── provider.default_model
│   └── provider.models[]
└── God SDK Harness     ~/pantheon/god-packages/god-{god}/harness.yaml
    └── model:
```

## Workflow: Changing a God's Model

This skill covers **two provider paths** — pick the one that matches the target model's backend.

### Path A: Ollama Model (local or cloud)

Use when the model runs through the local Ollama instance (`http://localhost:11434` or `https://ollama.com/v1` for cloud).

**1. Pull the model on Ollama**

```bash
ollama pull {model-name}:{tag}
```

For cloud models: `ollama list` to confirm it's pulled.

**2. Update the Hermes Profile Config**

File: `~/.hermes/profiles/{god}/config.yaml`

```yaml
model:
  api_key: ollama
  base_url: http://127.0.0.1:11434/v1          # local, or https://ollama.com/v1 for cloud
  default: {NEW_MODEL}                           # ← CHANGE THIS
  provider: ollama-launch
providers:
  ollama-launch:
    api: http://127.0.0.1:11434/v1
    default_model: {NEW_MODEL}                    # ← CHANGE THIS
    models:
    - {NEW_MODEL}                                 # ← ADD THIS
    - {OLD_MODEL}                                 #     ← KEEP AS FALLBACK
    name: Ollama
```

**Pattern:** add the new model to `providers.ollama-launch.models[]` before the old one.

---

### Path B: OpenCode Go Model (via LiteLLM Proxy)

Use when the model routes through the Pantheon LiteLLM proxy at `http://localhost:4000`. This covers all `opencode/*` models (deepseek-v4-pro, qwen3.6-plus, kimi-k2.6, etc.) and any other model defined in `~/litellm-config.yaml`.

**1. No pull needed** — OpenCode Go models are cloud-hosted. Just verify the model name exists in the LiteLLM roster.

Check available models:

```bash
curl -s http://localhost:4000/v1/models -H "Authorization: Bearer sk-pantheon-proxy" | python3 -m json.tool
```

Or check the config directly:

```bash
cat ~/litellm-config.yaml | grep -A1 "opencode/"
```

**2. Update the Hermes Profile Config**

File: `~/.hermes/profiles/{god}/config.yaml`

```yaml
model:
  base_url: http://localhost:4000
  default: opencode/{MODEL_NAME}               # ← e.g. opencode/deepseek-v4-pro
  provider: local-litellm
providers:
  local-litellm:
    api: http://localhost:4000
    api_key: sk-pantheon-proxy
    default_model: opencode/{MODEL_NAME}        # ← CHANGE THIS
    models:
    - opencode/{MODEL_NAME}                     # ← ADD THIS
    - opencode/deepseek-v4-flash                #     ← KEEP FALLBACKS
    - opencode/kimi-k2.6
    name: LiteLLM (Pantheon)
  # Optionally keep Ollama as a fallback for cloud/on-prem models
  ollama-launch:
    api: https://ollama.com/v1
    default_model: gemma4:31b-cloud
    models:
    - gemma4:31b-cloud
    - deepseek-v4-flash:cloud
    name: Ollama
```

**Key difference from Ollama path:** no `api_key` at the top-level `model:` block; the API key lives inside the provider block. No auth.json needed — `local-litellm` authenticates via inline `api_key`.

---

### Common Steps (Both Paths)

**3. Update the Harness Config**

File: `~/pantheon/harnesses/{god}-base.yaml`

```yaml
model: {NEW_MODEL}    # ← CHANGE THIS (matches profile config's model.default)
```

The harness `model:` must match the profile `model.default:` value exactly. If they disagree, the gateway may error on load.

**3.5 Set Up Shared Brain (if not already present)**

Every god needs persistent memory. Shared brain files live in the **Athenaeum** under `~/athenaeum/Codex-God-{name}/`. Create them:

```bash
# Create the Codex directory structure
mkdir -p ~/athenaeum/Codex-God-{name}/journal

# Copy template files
cp ~/pantheon/templates/god/memory.md ~/athenaeum/Codex-God-{name}/memory.md
cp ~/pantheon/templates/god/journal/TEMPLATE.md ~/athenaeum/Codex-God-{name}/journal/$(date +%Y-%m-%d).md

# Write INDEX.md marking it excluded from Hades
cat > ~/athenaeum/Codex-God-{name}/INDEX.md << 'INDEXEOF'
# Codex-God-{name}
**Domain:** {god name} — shared brain (memory + journal)
**Status:** LIVING — dynamically written by {god name}
**Hades:** EXCLUDED
INDEXEOF

# Update the Athenaeum master index
```

**IMPORTANT:** Old setup steps used `~/.hermes/profiles/{god}/memory.md` — this has been superseded. All god memory belongs in `~/athenaeum/Codex-God-{name}/`. If you find old profile-dir memory files, move them to the Athenaeum and delete the originals.

Then add a `## Shared Brain Protocol` section to the god's harness identity (see `references/shared-brain-protocol.md` for the exact template text and rules). This gives the god startup ritual, journaling behavior, and memory curation instructions.

**4. Verify Provider Authentication for the Profile**

Before restart, verify the god profile can actually authenticate to the new provider.

Checks:

```bash
hermes --profile {god} doctor
hermes --profile {god} chat -q "Reply with exactly: ok" --quiet
```

If the profile uses an OAuth provider like `openai-codex` and the chat test fails with `No Codex credentials stored`, inspect both auth stores:

- Main auth: `~/.hermes/auth.json`
- Profile auth: `~/.hermes/profiles/{god}/auth.json`

A Pantheon god profile may have an empty or stale profile-local `auth.json` even when the main Hermes profile is already authenticated. In that case, either authenticate inside the profile or seed the profile `auth.json` with the needed provider entry from the main auth file. See `references/profile-authentication.md`.

For `local-litellm` provider: no auth.json needed since the API key is inlined in the provider config block.

**5. Restart the Gateway**

```bash
# Systemd-managed (check with: systemctl --user list-units --type=service | grep {god})
systemctl --user restart hermes-gateway-{god}
```

If the service isn't registered, start as a raw process:

```bash
hermes --profile {god} gateway run
```

If a previous gateway is already running, use `--replace`:

```bash
hermes --profile {god} gateway run --replace
```

**6. Verify**

- **Process running:** `ps aux | grep "profile {god}" | grep python`
- **Model confirmed:** Check the gateway log for clean model load:
  ```bash
  tail -20 ~/.hermes/profiles/{god}/logs/gateway.log
  ```
- **API server check** (if god exposes one): `curl -s http://localhost:{PORT}/health`
- **Platform check:** Send a test message through the god's registered platform

## Where Gods Are Wired

A Pantheon god's configuration spans **three separate systems** that must be understood together:

### A. Running Instance (Hermes Profile)
The actual agent lives here — this is what runs on the gateway.

| Layer | Location | Purpose |
|-------|----------|---------|
| Profile config | `~/.hermes/profiles/{god}/config.yaml` | Model, provider, tools, API keys, platforms per god |
| Profile .env | `~/.hermes/profiles/{god}/.env` | Platform tokens (Telegram bot tokens, etc.) |
| **SOUL.md** | `~/.hermes/profiles/{god}/SOUL.md` | God's personality, scope, rules, working patterns — the canonical "soul" document |
| Shared brain | `~/athenaeum/Codex-God-{name}/memory.md`, `journal/` | Persistent long-term memory and daily session notes (Hades-excluded Codex) |
| Systemd service | `hermes-gateway-{god}.service` | Process lifecycle (optional — gods can run as raw processes) |

### B. God SDK Package (Template)
The reusable god definition lives here — used when packaging a god for distribution.

| Layer | Location | Purpose |
|-------|----------|---------|
| God metadata | `~/pantheon/god-packages/god-{god}/god.yaml` | Schema version, type, model, studios, tags |
| Harness identity | `~/pantheon/god-packages/god-{god}/harness.yaml` | Identity prompt, routing rules, guardrails, failure behavior |
| Skills | `~/pantheon/god-packages/god-{god}/skills/` | Skill SKILL.md files the god can load via `/skill` |

### C. Athenaeum Codex (Knowledge Base)
Each Codex has a designated primary god (see `KNOWLEDGE.md`). This is who reads from and writes to that corpus.

| Codex | Primary God | Domain |
|-------|-------------|--------|
| Codex-SKC | Apollo | Music, lyrics, style |
| Codex-Infrastructure | Hephaestus | Homelab, networking, Proxmox |
| Codex-Forge | Hephaestus | Blueprints, planning sessions |
| Codex-Fiction | Calliope | Long-form narrative, worldbuilding |
| Codex-Asclepius | Caduceus | Medical research, health references |
| Codex-Pantheon | Athena | System docs, constitution, workflows |
| Codex-General | Athena | Uncategorized notes |

### Current God Registry

The canonical registry of all active Pantheon gods is maintained as a **three-tier catalog** in `Codex-Pantheon/constitution/GODS.md`:
- **Agents** — Interactive AI gods with Hermes profiles (Hermes, Hephaestus, Apollo)
- **Hybrids** — Semi-autonomous cron/event-driven processes (Hades, The Fates)
- **Subsystems** — Pure scripts/services with no AI (Mnemosyne, Demeter, Charon, Iris, Hera, Kronos, Hestia)

The `god_list` MCP tool returns only **Agent**-type gods. For the full picture including hybrids and subsystems, reference the GODS.md constitution document or use the Athenaeum to search it.

### Subsystem Ownership Transfer (Scope Handoff)

When transferring ownership of Pantheon subsystems from one god to another (e.g. Hephaestus → Hermes):

1. **Write/update GODS.md** — set the new owner in the registry
2. **Update source god's SOUL.md**:
   - *Remove*: Current Scope (build list), Housekeeping, Current Phase
   - *Keep*: Git Discipline, How We Work Together, Skills rules, Filesystem Access, Fallback
   - *Update*: Identity line (generalize away from Pantheon-specific), What Pantheon Is (note the handoff)
3. **Create/update target god's SOUL.md** — define the new operations role with explicit subsystem inventory
4. **Save to memory** — update the ownership structure in persistent memory
5. **Verify all state** — check heartbeat.json, cron jobs, systemd services are accounted for in the handoff

### Subsystem State and Tracking Data

| Data | Path | What It Tells You |
|---|---|---|
| Heartbeat state | `~/.hermes/pantheon/heartbeat.json` | `last_ok` timestamps per subsystem — reveals what's actually running vs dead |
| Fates alerts | `~/.hermes/pantheon/fates-alerted.json` | Dedup tracking for heartbeat alerts |
| Hades reports | `~/athenaeum/Codex-Pantheon/reports/hades-*.md` | Daily consolidation reports — check existence to verify Hades ran |
| ChromaDB | `~/.hermes/pantheon/chroma/` | Vector store — missing or empty means Mnemosyne isn't deployed |
| Graph DB | `~/.hermes/pantheon/graph.db` | SQLite entity-relationship graph |
| Inter-god inbox | `~/pantheon/gods/messages/hermes/*.json` | Messages from subsystems — Hestia sends hourly heartbeats here |

Use the heartbeat file as your first diagnostic when a subsystem seems dead — it's faster than grepping logs.

## God Profiles Layout

Each profile is a directory under `~/.hermes/profiles/`:

```
~/.hermes/profiles/{god}/
├── config.yaml    ← Main config (model, provider, tools, platforms)
├── .env           ← Tokens and secrets
├── SOUL.md        ← God's soul document — personality, scope, rules, working patterns
├── auth.json      ← Provider authentication tokens
├── channel_directory.json  ← Platform channel bindings
├── gateway_state.json      ← Current gateway state
├── logs/          ← Gateway and execution logs
└── skills/        ← Skill definitions (SKILL.md files)
```

**Shared brain (memory.md + journal/) lives in the Athenaeum**, not in the profile directory. See `~/athenaeum/Codex-God-{name}/memory.md` and the Shared Brain setup section below.

**The SOUL.md file** is the god's identity anchor — it defines who they are, their current scope, working protocols, and rules. It is loaded as a system instruction on every gateway start. Unlike the harness identity block (which provides generic prompt structure), the SOUL.md is god-specific and maintained separately from the SDK package.

## Pitfalls

### Trust the user when they insist a file exists
If Konan says "look at his SOUL.md" or "it exists, keep looking" — **stop arguing and search harder**. The answer is almost always in `~/.hermes/profiles/{id}/` rather than in project directories. This is the #1 wasted-time pattern.

### SOUL.md is NOT in project directories
It's always under `~/.hermes/profiles/{id}/`. Do not search `~/pantheon/` or `~/athenaeum/` for it first — that wastes turns.

### Subsystems may be running without a dedicated cron entry
Hades generates reports even without its own cron cron — it may be triggered as part of the Morning Briefing pipeline (`~/.hermes/scripts/morning-briefing.sh`). Check the report file's modification date AND the morning briefing script, not just `cronjob list`, for a subsystem's true running status.

### Profile config vs harness config MUST agree
If the harness says `model: gemma4` but the profile config's provider only lists `deepseek-v4-flash:cloud`, the gateway will error on load. **Always update both.**

### Gateway restart with `--replace`
The `--replace` flag shuts down any existing gateway for that profile before starting the new one. Without it, you get port conflicts. Always use `--replace`.

### Systemd restart may hang
If the gateway has child processes (MCP server), `systemctl restart` can time out. Force-kill first:

```bash
kill -9 $(pgrep -f "hermes.*{god}.*gateway")
systemctl --user reset-failed hermes-gateway-{god}
systemctl --user start hermes-gateway-{god}
```

### Cloud models need API keys for some providers
Ollama cloud models (like Kimi K2.6) route through Ollama Pro — no extra key if you're on Ollama Pro. But models from Moonshot, Z.AI, etc. may need their own API key via `~/.ollama/config.json`.

### Provider auth can be profile-local
A successful auth flow in the main Hermes profile does **not** guarantee the god profile can use the same provider. Check `~/.hermes/profiles/{god}/auth.json` directly when moving to providers like `openai-codex`.

If direct inference fails with `No Codex credentials stored`, seed or re-auth the profile before blaming the model config. Keep a backup of the profile auth file first. See `references/profile-authentication.md`.

### Harness config model field
The harness `model:` field is checked at load time but the profile `model.default:` takes precedence at runtime. Always set both to be safe.

### Discord `home_channel` is required — not just `allowed_channels`
Setting `allowed_channels` restricts **which channels the god listens in**, but it does NOT control where the god sends responses. Without a `home_channel`, responses may route through the main gateway's default channel (e.g. your own chat channel) instead of the god's dedicated channel.

**Always set both:**
```yaml
discord:
  allowed_channels: '1499854046138204170'   # ← where the god listens
  home_channel: 1499854046138204170          # ← where the god responds
```

The `home_channel` ID is typically the same as `allowed_channels` — the god's dedicated Discord channel. Without it, the god will appear to "not respond" or will respond in the wrong place.

### After restart, test in the god's actual platform channel
A silent fail means the gateway runs but the Discord/Telegram connection didn't initialize or the routing is wrong. Test by sending a message in the god's dedicated Discord channel and verify the response appears there — not in a different channel. Check gateway logs for `✓ connected` messages.

### Be careful with broad `pkill -f` patterns during cleanup
When retiring old services or frontends, broad patterns like `pkill -f 'the-kitchen'` can match the parent shell command itself if the string appears in the running cleanup script. That can kill the command performing the cleanup and leave the system half-changed.

Safer pattern:

```bash
PIDS=$(ps -eo pid,args | grep '/exact/command/or/path' | grep -v grep | awk '{print $1}')
if [ -n "${PIDS:-}" ]; then
  kill $PIDS || true
  sleep 1
  kill -9 $PIDS 2>/dev/null || true
fi
```

Prefer exact command paths over generic names.

## Workflow: Setting Up Discord for a New God

Deploying a Pantheon god on Discord requires a Discord bot token, profile config with channel restrictions, and a per-profile `.env` file.

### Architecture

```
Pantheon Discord Server
├── #the-herald       ← Hermes (free response, home channel)
├── #forge-or-name    ← Hephaestus (free response, own channel)
├── #muses-mount      ← Apollo (free response, own channel)
└── #general          ← (unused by gods / or specific god)
```

Each god runs as a **separate Hermes profile** with its own:
- **Discord bot token** (from discord.com/developers/applications)
- **`config.yaml`** with channel restrictions
- **`.env`** with platform tokens
- **Systemd service** (`hermes-gateway-<profile>`)

### Per-God Config

Each profile's `config.yaml` needs a `discord:` section:

```yaml
discord:
  require_mention: false       # true = respond only when @mentioned; false = respond freely
  free_response_channels: ''   # override: channels where god responds without @mention
  allowed_channels: 'CHANNEL_ID_AS_STRING'  # ONLY channel(s) the god will respond in
  auto_thread: false
  reactions: true
  channel_prompts: {}
  server_actions: ''
```

#### Behavior Matrix

| require_mention | allowed_channels set | Behavior |
|:---------------:|:-------------------:|----------|
| `false` | `'CHANNEL_ID'` | Responds freely in that channel only |
| `true` | `'CHANNEL_ID'` | Responds only when @mentioned, only in that channel |
| `false` | `''` (empty) | Responds freely in ALL channels (messy on shared server) |
| `true` | `''` (empty) | Responds only when @mentioned, in any channel |

### Per-Profile `.env`

```env
# Discord
DISCORD_BOT_TOKEN=MTQ5OTg...yourTokenHere
DISCORD_HOME_CHANNEL=1499868497180889158

# Other platforms (optional)
TELEGRAM_BOT_TOKEN=...
GATEWAY_ALLOW_ALL_USERS=true
```

### Setup Steps

1. **Create a Discord bot** at https://discord.com/developers/applications
   - Enable **Message Content Intent** in Bot → Privileged Gateway Intents
   - Copy the bot token
   - Invite bot to server with `bot` + `applications.commands` scopes

2. **Create or reuse a Hermes profile**:
   ```bash
   hermes profile create my-god-name
   ```

3. **Add Discord config** to the profile's `config.yaml` — set `allowed_channels` and `require_mention` per your isolation needs.

4. **Add Discord token** to the profile's `.env` — both `DISCORD_BOT_TOKEN` and `DISCORD_HOME_CHANNEL`.

5. **Restart the gateway**:
   ```bash
   systemctl --user restart hermes-gateway-my-god-name
   ```

6. **Verify**:
   ```bash
   cat ~/.hermes/profiles/<profile>/logs/gateway.log | grep "discord"
   ```
   Look for: `✓ discord connected` and `Connected as BotName#1234`

### Platform-Specific Pitfalls

- **`allowed_channels` is NOT a hard block** — It filters **outbound** responses only. Gods still **receive** inbound messages from all channels. For full isolation, set `require_mention: true` or remove the bot from channels it doesn't need via Discord server settings.

- **`home_channel` is required** — `allowed_channels` restricts where the god listens, but without `home_channel`, responses may route through the wrong default channel (e.g. your own chat channel instead of the god's dedicated channel). **Always set both:**
  ```yaml
  discord:
    allowed_channels: 'CHANNEL_ID'   # where the god listens
    home_channel: CHANNEL_ID          # where the god responds
  ```

- **`.env` file is fragile** — One bad `write_file` (e.g. clipboard paste) can nuke a bot token. Always read the existing `.env` before modifying, or keep tokens backed up.

- **Discord UI shows bots offline** — Even when gateway logs confirm `✓ discord connected`, Discord's sidebar may show bots as grey. This is a Discord UI quirk, not a real issue.

- **Message Content Intent required** — Without this intent enabled in the Discord Developer Portal, the bot sees messages in its DMs but NOT in server channels. Gateway throws `PrivilegedIntentsRequired`.

- **Gateway restart can hang** — If the gateway has child processes (MCP server), `systemctl restart` may time out waiting for the process tree to stop. Force-kill: `kill -9 $(pgrep -f "hermes.*<profile>.*gateway")` then `systemctl --user reset-failed hermes-gateway-<profile>` then `systemctl --user start hermes-gateway-<profile>`.

- **After restart, test in the god's actual platform channel** — A silent fail means the gateway runs but the Discord connection didn't initialize or routing is wrong. Send a test message in the god's dedicated Discord channel and verify the response appears there. Check gateway logs for `✓ connected` messages.

## Workflow: Retiring Discord From the Active Deployment

When Discord was only an experiment and needs to be removed cleanly, do **all three layers**:

### 1. Remove active Discord secrets from env files

Check and clean:

- `~/.hermes/.env`
- `~/.hermes/profiles/{god}/.env`

Remove these if present:

```dotenv
DISCORD_BOT_TOKEN=...
DISCORD_HOME_CHANNEL=...
```

**Important:** the main `~/.hermes/.env` may be protected against direct file-patch tools because it is a credential file. In that case, use a terminal/script edit and create a timestamped backup first.

### 2. Clear Discord bindings from config.yaml

In each active profile and the main config, neutralize the `discord:` block instead of leaving channel IDs behind:

```yaml
discord:
  require_mention: false
  free_response_channels: ''
  allowed_channels: ''
  auto_thread: false
  reactions: false
  channel_prompts: {}
  server_actions: ''
```

If the profile had a home channel, clear that too:

```yaml
  home_channel: ''
```

### 3. Restart active gateways and verify platforms

Restart every running gateway that previously had Discord enabled:

```bash
systemctl --user restart hermes-gateway
systemctl --user restart hermes-gateway-{god}
```

Then verify the gateway no longer connects to Discord:

```bash
hermes gateway status
hermes --profile {god} gateway status

tail -n 20 ~/.hermes/logs/gateway.log
tail -n 20 ~/.hermes/profiles/{god}/logs/gateway.log
```

Expected result after restart:
- main gateway shows only the remaining platforms (for Pantheon: Telegram + API server)
- god gateway shows only the remaining platforms (often just API server)
- logs show prior `discord disconnected` lines but **no fresh `Connecting to discord...` / `discord connected`** after restart

### 4. Do a stale-secret sweep

Even after active removal, old Discord tokens may still exist in:
- `state-snapshots/`
- old skill references / notes
- archived `.bak` files

These are not active runtime config, but they are still stale secret material and should be scrubbed if security hygiene matters.

## Workflow: Retiring Legacy Frontends While Standardizing on Hermes Workspace

When Pantheon UI, AionUI, Kitchen, or other experimental frontends are no longer part of the deployment, retire them as an operational cleanup — not just a repo tidy-up.

### 1. Inventory active services and stray processes

Check both systemd and raw processes:

```bash
systemctl --user list-units --type=service --all --no-pager | grep -Ei 'aion|kitchen|ui|workspace|frontend|web'
systemctl --user list-unit-files --type=service --no-pager | grep -Ei 'aion|kitchen|ui|workspace|frontend|web'
ps -ef | grep -Ei 'aionui|pantheon-ui|the-kitchen|workspace' | grep -v grep
```

Do not assume everything is under systemd. A frontend backend may still be running from an old shell launch.

### 2. Identify what must remain

Before removing anything, confirm the intended surviving path. In the Pantheon deployment described here:

- keep the Hermes Workspace repo/path
- keep `pantheon-workspace.service`
- keep `pantheon-mcp-bridge.service` if Workspace still depends on it

### 3. Stop and disable retired units

For example:

```bash
systemctl --user stop pantheon-ui.service 2>/dev/null || true
systemctl --user disable pantheon-ui.service 2>/dev/null || true
systemctl --user stop pantheon-kitchen-bridge.service 2>/dev/null || true
systemctl --user disable pantheon-kitchen-bridge.service 2>/dev/null || true
```

Then run:

```bash
systemctl --user daemon-reload
```

### 4. Kill stray legacy processes by exact command

Use exact process matching for anything that was started outside systemd. Example:

```bash
PIDS=$(ps -eo pid,args | grep '/home/konan/pantheon/pantheon-ui-backend/venv/bin/python main.py' | grep -v grep | awk '{print $1}')
if [ -n "${PIDS:-}" ]; then
  kill $PIDS || true
  sleep 1
  kill -9 $PIDS 2>/dev/null || true
fi
```

### 5. Archive retired assets out of live paths

Prefer moving retired frontends into a timestamped archive rather than deleting immediately. This preserves rollback while removing them from the active runtime:

```bash
ARCHIVE=/home/konan/retired-frontends-$(date +%Y%m%d-%H%M%S)
mkdir -p "$ARCHIVE/systemd-user" "$ARCHIVE/home" "$ARCHIVE/workspace"
```

Typical move targets:

- `~/.config/systemd/user/pantheon-ui.service`
- `~/.config/systemd/user/pantheon-kitchen-bridge.service`
- `~/aionui.service`
- `~/aionui-src`
- `~/aionui`
- `~/.aionui-server`
- `~/workspace/the-kitchen`

### 6. Verify the cleanup actually changed the live system

Check that retired paths are gone from their active locations, and that only the approved Workspace path remains:

```bash
systemctl --user list-unit-files --type=service --no-pager | grep -E 'pantheon-ui|pantheon-kitchen-bridge|pantheon-workspace|pantheon-mcp-bridge' || true
ps -ef | grep -Ei 'pantheon-ui-backend|aionui-src|the-kitchen' | grep -v grep || true
```

Expected result:
- no live `pantheon-ui.service`
- no live `pantheon-kitchen-bridge.service`
- no active legacy frontend processes
- Hermes Workspace path still present

### 7. Treat historical references separately

Athenaeum notes, rollback snapshots, and old docs may still mention the retired frontends. That is a separate cleanup pass. Do not confuse “inactive operationally” with “fully purged historically.”

## Shared Brain Setup

Every god now ships with persistent memory via flat markdown files — the **Shared Brain Protocol**. This ensures gateway resets don't wipe context, and Konan can read/edit the god's memory directly.

### Location: `Codex-God-{name}` in the Athenaeum

The shared brain files live in the Athenaeum at `~/athenaeum/Codex-God-{name}/`. This puts them in the same knowledge ecosystem as everything else — searchable via Athenaeum tools, discoverable, and part of the self-feeding structure.

**These codices are EXCLUDED from Hades management** (nightly consolidation, archival, distillation). The `Codex-God-` naming convention is the exclusion mechanism — Hades skips anything with this prefix.

### One-time setup for a new god

```bash
# 1. Create the Codex-God-{name} directory in the Athenaeum
mkdir -p ~/athenaeum/Codex-God-{name}/journal

# 2. Write the INDEX.md
cat > ~/athenaeum/Codex-God-{name}/INDEX.md << 'INDEXEOF'
# Codex-God-{name}

**Domain:** {god name} — shared brain (memory + journal)
**Status:** LIVING — dynamically written by {god name}
**Hades:** EXCLUDED — this is active memory, not canonical knowledge

## Contents

| Path | Description |
|------|-------------|
| `memory.md` | Curated long-term memory |
| `journal/` | Daily session logs |

---

> This Codex is part of the Shared Brain Protocol. Hades does NOT archive,
> distill, or consolidate this content. Files here are actively maintained
> by {god name} and overwritten as context evolves.
INDEXEOF

# 3. Copy the memory.md template
cp ~/pantheon/templates/god/memory.md ~/athenaeum/Codex-God-{name}/memory.md

# 4. Create today's first journal entry
cp ~/pantheon/templates/god/journal/TEMPLATE.md ~/athenaeum/Codex-God-{name}/journal/$(date +%Y-%m-%d).md
```

### 5. Add the Shared Brain Protocol to the harness

Open `~/pantheon/harnesses/{god}-base.yaml` and paste the protocol block from `~/pantheon/templates/god/SHARED_BRAIN_PROTOCOL.md` into the `identity:` section (after personality, before `routing:`). Adjust the file paths to match the god's Codex name.

### 6. Verify the god reads its brain on next startup

After restarting the gateway, check that the god loads the memory at session start. The protocol is self-executing — no extra config needed.

### Template files

| File | Purpose |
|------|---------|
| `~/pantheon/templates/god/memory.md` | Curated long-term memory (god maintains it) |
| `~/pantheon/templates/god/journal/TEMPLATE.md` | Daily session journal format |
| `~/pantheon/templates/god/SHARED_BRAIN_PROTOCOL.md` | Harness identity block to copy in |

---

### Profile → God UI: nesquena/hermes-webui

The community-maintained **Hermes WebUI** (https://github.com/nesquena/hermes-webui) maps directly to Pantheon god management. **Architecture decision (May 2026):**

- **Each Pantheon god is a Hermes profile** → switchable via the web UI's profile dropdown
- The Web UI's profile system **IS** the god system — no Gateway involvement needed for non-default profiles
- Gateway serves ONLY the default profile (Telegram/Discord access for Konan). Other gods interact through the browser.
- Switching profiles in the Web UI is byte-for-byte identical to `hermes --profile {god}` in terminal
- Thread-local profile isolation enables multiple god tabs simultaneously
- Session tags (projects with name/color) can categorize conversations by god or domain
- Deployed at `http://0.0.0.0:8787` — serves as the sole browser frontend for all gods

See `pantheon-operations` skill → "Web UI (nesquena/hermes-webui)" section for full deployment and config details.

---

## Quick Reference

```bash
# List all running gateway processes
ps aux | grep "hermes.*gateway" | grep -v grep

# List all profiles
ls ~/.hermes/profiles/

# Read a profile's soul document
cat ~/.hermes/profiles/{god}/SOUL.md

# Read the god registry
cat ~/athenaeum/Codex-Pantheon/constitution/GODS.md

# List available god packages
ls ~/pantheon/god-packages/

# Read a harness
cat ~/pantheon/god-packages/god-{god}/harness.yaml

# Check gateway log
cat ~/.hermes/profiles/{god}/logs/gateway.log | tail -20

# Quick model test via Ollama
curl -s http://localhost:11434/api/chat -d '{"model":"{model}:{tag}","messages":[{"role":"user","content":"ping"}],"stream":false}'

# Quick model test via LiteLLM proxy
curl -s http://localhost:4000/v1/chat/completions \
  -H "Authorization: Bearer sk-pantheon-proxy" \
  -d '{"model":"opencode/{model}","messages":[{"role":"user","content":"ping"}]}'

# List available LiteLLM models
curl -s http://localhost:4000/v1/models -H "Authorization: Bearer sk-pantheon-proxy" | python3 -m json.tool

# Check what OpenCode Go actually offers (live API query)
curl -s https://opencode.ai/zen/go/v1/models -H "Authorization: Bearer $OPENCODE_GO_API_KEY" | python3 -m json.tool
```
