---
name: pantheon-migration
description: "Migrate a full Pantheon deployment — Hermes Agent, gods, Athenaeum, profiles, configs, systemd services — from one machine to another over Tailscale/SSH/USB. Covers WSL→Linux, Linux→Linux, and bare-metal transfers."
version: 1.0.0
author: Konan
license: MIT
metadata:
  hermes:
    tags: [pantheon, migration, wsl, tailscale, transfer, backup, deployment, systemd]
    related_skills: [hermes-agent, pantheon-god-configuration]
---

# Pantheon Migration

Migrate a full Pantheon system (Hermes Agent + all gods + Athenaeum + Pantheon-Core) between machines. Designed for the common case: **WSL2 (work machine) → native Linux (home server like B-Link U55)** over Tailscale, but works for any source→target setup.

## When to Use This Skill

Load this when the user wants to:
- Move their entire Hermes/Pantheon setup to a new machine
- Migrate from WSL to a dedicated Linux box
- Clone their setup to a second machine (e.g., laptop + homelab)
- Back up the full system for disaster recovery

Do NOT load this for:
- Just installing Hermes Agent fresh (`hermes-agent` skill)
- Just spinning up a new god on an existing deployment (`pantheon-god-configuration`)
- Git repo cloning or dotfile sync (those are simpler)

## Inventory: What We're Migrating

From the standard Hermes + Pantheon layout:

| Path | Typical Size | Notes |
|------|-------------|-------|
| `~/.hermes/config.yaml` | ~4K | Core config — must migrate |
| `~/.hermes/.env` | ~1K | API keys — SECRET, migrate carefully |
| `~/.hermes/profiles/` | **1-4 GB** | Each god's state DBs, sessions, skills, memories |
| `~/.hermes/hermes-agent/` | **1-2 GB** | Python venv, Node.js deps, source code |
| `~/.hermes/node/` | 500-700 MB | Node.js runtime |
| `~/.hermes/skills/` | ~10 MB | Installed skills |
| `~/.hermes/scripts/` | ~20K | Custom scripts |
| `~/.hermes/hooks/` | ~4K | Shell hooks |
| `~/.hermes/plugins/` | ~100K | Plugins |
| `~/.hermes/cron/` | ~7 MB | Cron job data |
| `~/.hermes/memories/` | ~12K | Persistent memory |
| `~/.hermes/state.db*` | 50-60 MB | Gateway state DB + WAL |
| `~/.hermes/gateway_state.json` | ~4K | Gateway runtime state |
| `~/.hermes/channel_directory.json` | ~4K | Channel/platform mapping |
| `~/.hermes/sessions/` | 100-200 MB | Chat history (optional to migrate) |
| `~/.hermes/cache/` | ~16K | Cache (optional to migrate) |
| `~/.hermes/image_cache/` | ~4K | Image cache (skip) |
| `~/.hermes/audio_cache/` | ~100K | Audio cache (skip) |
| `~/pantheon/` | ~5 MB | Pantheon-Core repo + gods config |
| `~/athenaeum/` | ~8-10 MB | Codex vault (git repos) |
| `~/.ssh/` | ~28K | SSH keys |
| `~/.gitconfig` | ~1K | Git config |
| `~/.bashrc` / `~/.profile` | ~5K | Shell config |
| `~/.config/systemd/user/` | ~4K | User systemd service files |
| Ollama models | varies | Pull fresh on target — cloud models are instant |

**Total: ~4-7 GB** depending on session history and state DBs.

## Transfer Methods

### Method A: Tailscale (Recommended for WSL → Home Server)

**WSL quirk:** Tailscale is on the **Windows host**, not inside WSL. The `tailscale` binary won't exist in WSL, but **magic DNS works** (ping `100.100.100.100` to verify). Tailscale IPs are reachable because Windows routes them.

1. Get the target's Tailscale IP (ask user or have them check on the target machine: `tailscale ip -4`)
2. Verify connectivity from WSL: `ping -c 2 <TARGET_IP>`
3. Check SSH: `ssh konan@<TARGET_IP> -o ConnectTimeout=5`
4. If SSH needs a key (see "SSH Auth Setup" below), set that up first

```bash
# Build tarball (trimmed — exclude WAL, session history)
tar czf ~/pantheon-migration.tar.gz \
  ~/.hermes/config.yaml \
  ~/.hermes/.env \
  ~/.hermes/skills/ \
  ~/.hermes/scripts/ \
  ~/.hermes/hooks/ \
  ~/.hermes/plugins/ \
  ~/.hermes/cron/ \
  ~/.hermes/memories/ \
  ~/.hermes/pantheon/ \
  ~/.hermes/state.db \
  ~/.hermes/gateway_state.json \
  ~/.hermes/channel_directory.json \
  ~/.hermes/profiles/ \
  ~/.hermes/hermes-agent/ \
  ~/.hermes/node/ \
  ~/.hermes/bin/ \
  ~/pantheon/ \
  ~/athenaeum/ \
  ~/.ssh/ \
  ~/.gitconfig \
  ~/.bashrc \
  ~/.profile \
  ~/.config/systemd/user/ \
  --exclude='*.wal' --exclude='*-shm' --exclude='__pycache__' --exclude='.git'

# Transfer over Tailscale
scp ~/pantheon-migration.tar.gz konan@<TARGET_IP>:~/
```

### Method B: USB / External Drive (No Network)

Same tarball, but write to a USB drive mounted on the source, then read on the target.

```bash
# Find the USB mount
lsblk
# Mount and copy
sudo mount /dev/sdX1 /mnt/usb
cp ~/pantheon-migration.tar.gz /mnt/usb/
sudo umount /mnt/usb
```

### Method C: Direct Network (LAN without Tailscale)

If on the same LAN and no Tailscale, use the local IP:

```bash
# Source machine
ip addr show | grep "inet " | grep -v 127.0.0.1
tar czf ~/pantheon-migration.tar.gz ... # same as above
scp ~/pantheon-migration.tar.gz konan@<LAN_IP>:~/
```

## SSH Auth Setup

Since SSH keys are machine-specific, the source machine usually won't have a key for the target. Options:

**Option 1: Tailscale SSH** — if enabled on both sides, skip keys entirely:
```bash
tailscale ssh konan@<TARGET_IP>
```

**Option 2: Push a key** — generate on source, add to target:
```bash
# On source
ssh-keygen -t ed25519 -f ~/.ssh/migration_key -N ""
ssh-copy-id -i ~/.ssh/migration_key konan@<TARGET_IP>

# Or manually:
cat ~/.ssh/migration_key.pub
# Paste into ~/.ssh/authorized_keys on target
```

**Option 3: Password auth** — if `PasswordAuthentication yes` on target, just use `ssh konan@<TARGET_IP>` with the password.

## Target Machine Setup (Post-Migration)

After `tar xzf pantheon-migration.tar.gz -C ~/` on the target:

### 1. Install Core Dependencies

```bash
# Ollama — needed for cloud model proxies
curl -fsSL https://ollama.com/install.sh | sh

# Pull cloud models (instant — they're API proxies, not local downloads)
ollama pull kimi-k2.6:cloud
ollama pull gemma4:31b-cloud
ollama pull deepseek-v4-flash:cloud
```

### 2. Fix WSL→Linux Path Differences

WSL-specific paths may be baked into configs. Check for:
```
/mnt/c/Users/...  →  no equivalent, those files don't exist on Linux
```
No action needed unless cron scripts reference `/mnt/` paths.

### 3. Update Hermes Agent

```bash
hermes update
```

### 4. Re-Pair Gateway Platforms

**Gateway auth tokens do NOT transfer.** All platforms (Discord, Telegram, etc.) need re-pairing:

```bash
hermes gateway setup
# Follow prompts for each platform
```

Per-god platforms also need re-pairing:
```bash
hermes --profile hephaestus gateway setup
hermes --profile apollo gateway setup
```

### 5. Enable and Start Services

```bash
# Enable linger so services survive logout
sudo loginctl enable-linger $USER

# Reload systemd
systemctl --user daemon-reload

# Enable and start all services
systemctl --user enable hermes-gateway.service
systemctl --user enable hermes-gateway-hephaestus.service  # if applicable
systemctl --user enable hermes-gateway-apollo.service       # if applicable
systemctl --user enable pantheon-mcp.service               # if applicable

systemctl --user start hermes-gateway.service
systemctl --user start hermes-gateway-hephaestus.service
systemctl --user start hermes-gateway-apollo.service
systemctl --user start pantheon-mcp.service
```

### 6. Verify

```bash
# Check all services are running
systemctl --user status hermes-gateway

# Hermes health check
hermes doctor

# Check logs for errors
tail -20 ~/.hermes/logs/gateway.log
```

## Tarball Variations (What to Include/Exclude)

### Minimal Migration (~1.5 GB — fastest transfer)
Skip session history, state DBs (start fresh), caches:
```bash
tar czf ~/pantheon-migration.tar.gz \
  ~/.hermes/config.yaml \
  ~/.hermes/.env \
  ~/.hermes/profiles/*/config.yaml \
  ~/.hermes/profiles/*/SOUL.md \
  ~/.hermes/profiles/*/skills/ \
  ~/.hermes/skills/ \
  ~/.hermes/scripts/ \
  ~/.hermes/hooks/ \
  ~/.hermes/plugins/ \
  ~/pantheon/ \
  ~/athenaeum/ \
  ~/.ssh/ ~/.gitconfig \
  ~/.config/systemd/user/
```

### Full Migration (~6.5 GB — includes everything)
```bash
tar czf ~/pantheon-migration.tar.gz \
  ~/.hermes/ \
  ~/pantheon/ \
  ~/athenaeum/ \
  ~/.ssh/ ~/.gitconfig ~/.bashrc ~/.profile \
  ~/.config/systemd/user/ \
  --exclude='*.wal' --exclude='*-shm' --exclude='__pycache__' --exclude='.git'
```

## Pitfalls

- **WAL files don't transfer** — Always `--exclude='*.wal' --exclude='*-shm'`. These are SQLite write-ahead logs and transaction shm files; they're temp state that regenerates on next open.
- **Auth tokens are machine-bound** — Discord bot tokens, Telegram bot tokens, API keys in `auth.lock` files will NOT work on a new machine. The user must re-pair via `hermes gateway setup`.
- **`/mnt/` paths in cron scripts** — WSL has `/mnt/c/...` for Windows files. If cron scripts reference these, they'll break on native Linux. Rewrite to use Linux-native paths instead.
- **Hermes Agent version** — The source might be behind. Run `hermes update` on the target. Large version jumps may need `hermes config migrate` to update config schema.
- **`~/.hermes/auth.json` vs `~/.hermes/.env`** — Auth.json stores OAuth tokens (machine-bound); `.env` stores API keys (moveable). Don't expect auth.json to work on a new machine.
- **Ollama models are not in the tarball** — Local GGUF models live in `~/.ollama/` and can be gigabytes. For cloud-proxy models (`kimi-k2.6:cloud`, etc.), just `ollama pull` on the target — they're instant since they're API endpoints. For real local models, either rsync `~/.ollama/models/` separately or pull fresh.
- **WSL `systemd=true` in `/etc/wsl.conf`** — Without this, WSL can't run systemd services. On native Linux, systemd just works. If migrating *to* WSL, verify `/etc/wsl.conf` has `systemd=true` set.
- **GitHub PAT store** — `git config --global credential.helper store` might reference stale tokens. After migration, verify: `cat ~/.git-credentials`. If empty, re-auth.
- **SSH config references `github_pantheon`** — This private key is in `~/.ssh/` and transfers fine. Verify file permissions: `chmod 600 ~/.ssh/github_pantheon`.
