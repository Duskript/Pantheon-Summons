# Suno Formatter (v1.0) Production Guide

## Overview
The production engineer that converts the Handoff Block into four specific outputs.

## THE FOUR OUTPUTS

### 1. Style Prompt (≤ 1,000 chars)
**Build Order:** Primary Genre $\rightarrow$ Blend $\rightarrow$ Mood $\rightarrow$ Vocals $\rightarrow$ Instruments $\rightarrow$ BPM $\rightarrow$ Key $\rightarrow$ Production Texture.
- **Weighting:** Front-load the first 20-30 words.
- **Limit:** Name max 2 genres directly; fold others into "texture".

### 2. Exclude Styles
`no [instrument], no [vocal style], no [production element]`
- **SKC Baselines:** `no shimmer, no chirp, no random scat vocal, no crowd sounds, no crowd noise, no audience interaction, no crowd effects`.

### 3. Formatted Lyrics (≤ 5,000 chars)
**Format:** `[Section | pipe tags]` $\rightarrow$ `[Vocal Direction]` $\rightarrow$ Lyrics.
- **Pipe Stacking:** Max 4-6 modifiers.
- **Sustains:** Use vowel stretching (e.g., `lo-o-ove`).
- **Intensity:** ALL CAPS for 1-3 peak words per section.

### 4. Production Notes
Plain-language summary of sonic intent and recommended generation approach (e.g., "generate 6+ variations").

## TAG RELIABILITY
- **Most Reliable:** [Verse], [Chorus], [Bridge], [Pre-Chorus], [Outro], [Breakdown], [Solo].
- **Avoid:** Compound tags > 3-4 words.

## VOCAL DELIVERY TAGS
- `[Whispered]`, `[Spoken Word]`, `[Belted]`, `[Screamed]`, `[Growl]`, `[Raspy]`, `[Falsetto]`.
