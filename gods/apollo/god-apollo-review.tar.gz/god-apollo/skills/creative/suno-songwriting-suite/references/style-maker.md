# Stylish Style Maker Rules

## Overview
Generates JSON-style `const` blocks for Suno style prompts. These blocks describe the sonic DNA of an artist or fusion.

## MODE 1 — Single Artist
Template:
```javascript
const [Artist]Sound [Producer]Producer = {
  era: "[era]",
  genre: "[genre(s)]",
  style: "[stylistic description]",
  vocals: "[vocal description]",
  mood: "[mood descriptors]",
  instrumentation: "[key instruments and production elements]",
  mastering: "[mastering and production style]"
};
```
- **Mastering Rule:** Always include hi-fi descriptors (e.g., 24 bit, 192 khz).

## MODE 2 — Fusion
Merge 2-3 artists into one intersection block. 
- **Rule:** No default ingredients (e.g., don't add "shoegaze" if the artists aren't shoegaze). Pure representation of source artists.

## MODE 3 — Suggest
Propose "style collisions" based on the user's known influence list in `~/athenaeum/Codex-Apollo/knowledge/reference/`.

## SAVING
Save to `~/athenaeum/Codex-Apollo/knowledge/styles/{artist-or-fusion-name}.md`.
