---
name: suno-songwriting-suite
description: "Complete end-to-end workflow for AI music production from conceptualization to Suno V5 formatting. Three modules: Lyric Smith (writing), Stylish Style Maker (sonic DNA), Suno Formatter (production files)."
category: creative
trigger: "Write a song OR Create lyrics OR Start songwriting OR Lyric Smith OR Emulate a band OR Create a style profile OR Sonic DNA OR Style Maker OR Format for Suno OR Suno production OR Suno handoff OR Suno formatter"
---

# 🎵 Suno Songwriting Suite — Conceptualization to Production

Complete end-to-end pipeline from musical idea to Suno V5-ready production files. Three modules form a linear pipeline:

```
Lyric Smith → Stylish Style Maker → Suno Formatter
```

- **Lyric Smith** — The Creative Architect. Hook conceptualization, structural planning, lyric generation.
- **Stylish Style Maker** — The Sonic DNA Designer. Artist emulation, genre fusion, Suno style tags.
- **Suno Formatter** — The Production Engineer. Converts creative output into Suno V5 technical format.

Load this skill for any music creation task. Route internally to the relevant module section below.

---

## MODULE 1: Lyric Smith

### 1A — Standard Workflow (v3.5, primary)

Trigger: "Write a song" / "Create lyrics" / "Start songwriting" / "Lyric Smith"

**PHASE 1: SETUP (Numbered Lists)**
Present options sequentially (one category at a time), wait for user selection:
1. **Hook Concepts**: 1–6 examples + "Write my own" + "Get more"
2. **Mood**: 5–6 mood options + "Get more"
3. **Genre/Style**: 6–8 options + fusion option + "Get more"
4. **Rhyme Structure**: Genre-aware options (AABB, ABAB, Slant, etc.) with feel descriptions
5. **Verse Length**: Genre-aware line counts (4, 6, 8 lines) with feel descriptions

**PHASE 2: CREATION LOOP (Button Menus)**
- Buttons: Intro, Verse, Pre-Chorus, Chorus, Bridge, Post-Chorus, Hook, Outro, Finish Lyrics
- Generate 5–7 options → User selects → Patch to Canvas
- **Single-Query Rule**: Ask ONE question at a time
- **Suno Optimization**: Keep verses under ~8 lines

**PHASE 3: FINALIZATION (Button Menus)**
- **Add New Section**: Return to Phase 2
- **Edit Section**: Rewrite specific section (5–7 options)
- **Quality Analysis**:
  - Cliché Inversion (Identify → Alternatives)
  - Critical Reflection (Impact/Authenticity)
  - Metrical Analysis (Syllable/Rhythmic flow)
- **Persist to Athenaeum**: Save completed Canvas to `Codex-SKC/lyrics/[title-slug].md`
- **Suno Handoff**: Generate the `SUNO HANDOFF BLOCK` for the Formatter

### 1B — Talon Variant (Gritty / Anti-AI-ism)

Trigger: "Talon's Smith" / "Talon Lyric Smith" / "Gritty Lyrics"

Use when the user wants high-texture, linguistically adventurous lyrics that kill AI-isms.

**Core Interaction Loop:**
- **Section-by-Section:** Never generate a full song at once
- **The Power of 5:** Always provide at least 5 numbered options per creative decision
- **Sequential Approval:** Wait for user selection before moving to next section
- **Anti-Stacking:** Present ONE category at a time

**Phase 1: Discovery & Blueprint** (5 creative suggestions each, wait for response):
1. Genre Mashups (e.g., "Industrial Folk", "Baroque Grunge")
2. Narrative Perspectives (e.g., "Unreliable narrator", "Fading memory")
3. Mood & Atmosphere (e.g., "Clinical and sterile", "Vibrant decay")
4. Rhyme & Meter Strictness (e.g., "Perfect AABB", "Slant/Half-rhymes", "Polyrhythmic")
5. Structural Blueprints (e.g., "A-B-A-B-C-B", "Through-composed")

**Phase 2: Iterative Writing — Five Linguistic Filters**
Apply these filters to break the AI mold:
1. **Visceral/Granular:** Specific, heavy, physical words
2. **Technical/Jargon-Heavy:** Biology, architecture, mechanical fields
3. **Archaic/Literary:** Ancient or academic words
4. **Street/Vernacular:** Raw, unpolished, regional slang
5. **Impressionistic:** Weird color theory, synesthesia

**Refinement:**
- **Cliché Kill:** Identify the obvious metaphor, provide lateral/antonymous alternatives
- **Tier 3 Vocab:** Precise, evocative words; avoid Tier 1 filler

**Phase 3: Final Polish** — 5 numbered options each:
- Word-Swap Audit (identify clichés → sophisticated replacements)
- Specifics Check (general terms → specific species, object parts, precise locations)

**STRICT CONSTRAINTS:**
- **FORBIDDEN AI-ISMS:** NEVER use: tapestry, whispers, echoes, shimmering, dance, symphony, intertwined (unless explicitly requested)
- **DNA Adherence:** If user provides "Songwriter DNA" file, banned words are forbidden, "Golden Words" must be prioritized
- **No Politeness Filler:** No "for goodness sake" or Victorian fillers. Use language of the chosen genre

### 1C — Rebuild from Existing Lyrics

When the user brings existing lyrics to refine/rework:
1. Read full lyrics, identify **core concept**, **strongest lines**, **problem areas** (wordiness, clichés, abstract noun stacking, trope repetition)
2. Initialize Canvas with existing material's framework (hook, mood, style, instrumentation)
3. Work **section by section from the top** — Intro → V1 → Pre-Chorus → Chorus → etc.
4. For each section: identify what to keep, generate 4–6 rewrite options at the right length. User selects → patch to Canvas
5. **Never rewrite the entire song at once.** Always iterate section-by-section with user confirmation
6. Keep the best bones — even wordy drafts usually have 2–3 killer lines worth preserving

### Canvas Protocol

Maintain a persistent markdown artifact. **NEVER** recreate the full artifact for small changes; use targeted patching.

**Template:**
```markdown
# [Title]
**Hook/Concept**: [idea]
**Style**: [genre]
**Mood**: [mood]
**Rhyme Structure**: [pattern]
**Verse Length**: [count]
**Vocal Direction**: [character]
**Instrumentation Intent**: [prominent elements]
---
## Lyrics
### [Section Name]
[Lyrics]
```

**Workspace file:** `~/athenaeum/Codex-Apollo/sessions/lyric-smith-workspace.md`
- On first lock, CREATE. Every subsequent change: `patch` ONLY the changed field.

### Core Rules
- **Single-Query Rule:** Ask ONE question at a time
- **Human Grounding:** Hooks must be images/actions, not abstracts (e.g., "standing in a parking lot at 2am" vs "feeling lost")
- **Singability:** Read aloud; ensure consistent syllable flow
- **Suno Optimization:** Keep verses under ~8 lines
- **Handoff:** Every song must end with a completed `SUNO HANDOFF BLOCK`

### Pitfalls
- **Session memory ≠ persistent lyrics:** The Athenaeum indexes session summaries, but session summaries are not lyrics files. Always write the Canvas to `Codex-SKC/lyrics/` — this was the failure mode for "God Mode" (March 2026), where the song existed in session logs but the lyrics file was never saved.
- **"Looking for the source/signal" trope:** Flagged as a recurring problem. Chorus lines like "They're looking for the source" or "They're hunting for the signal" are cliché and pull focus from the transformation itself. Power should be *stated*, not defended. The room reacts — the singer doesn't react to the room.
- **Verse length creep:** Verses over 8 lines become dense and hard to sing/rap at 95–100 BPM. If a verse exceeds 8 lines, it needs cutting. Abstract noun stacks ("the weight, the misery, the history") should become one concrete image.
- **Pop culture as structural direction:** When the user references a scene (e.g., "Super Saiyan transformation," "Neo's Matrix monologue"), treat it as **narrative scaffolding**, not just a vibe. A DBZ transformation = atmospheric shift, quiet confidence, world shaking but the singer stays calm. A Matrix monologue = direct address, quiet certainty, invitation not lecture. See `references/pop_culture_framing.md` for active frameworks.
- **Don't rewrite from scratch when user brings existing lyrics:** When the user pastes existing lyrics and says "rework this" or "use this as a frame," do NOT produce a full rewrite. Work section-by-section from the top, generating 4–6 options per section and patching to Canvas. Keep the best parts — the user's original voice is the base, not disposable.
- **KB reference files may not exist:** Genre KB files (e.g., `genre_numetal_raprock.md`, `artist_dna_core.md`) are aspirational — many don't exist yet. If `athenaeum_read` returns "File not found," skip gracefully and proceed. Don't retry or loop on missing KB files.

### Knowledge Base — Module Loading

Load Athenaeum files at trigger points using `athenaeum_read`. Load only what's needed.

| Trigger | File to Load |
|---------|-------------|
| Phase 2 generation begins | `Codex-Apollo/knowledge/reference/artist_dna_core.md` |
| Pop culture reference given | `references/pop_culture_framing.md` (in-skill reference) |
| Genre: Post-Hardcore / Gazecore | `Codex-Apollo/knowledge/reference/genre_posthardcore_gazecore.md` |
| Genre: Alt-Metal / Progressive | `Codex-Apollo/knowledge/reference/genre_altmetal_progressive.md` |
| Genre: Shoegaze / Dream-Gaze | `Codex-Apollo/knowledge/reference/genre_shoegaze_dreamgaze.md` |
| Genre: Classic Rock / Soft Rock | `Codex-Apollo/knowledge/reference/genre_classicrock_softrock.md` |
| Genre: Progressive Rock | `Codex-Apollo/knowledge/reference/genre_progressive_rock.md` |
| Genre: Blues-Rock | `Codex-Apollo/knowledge/reference/genre_blues_rock.md` |
| Genre: Pop-Punk | `Codex-Apollo/knowledge/reference/genre_pop_punk.md` |
| Genre: Alt-Rock / Indie | `Codex-Apollo/knowledge/reference/genre_altrock_indie.md` |
| Genre: Nu-Metal / Rap-Rock | `Codex-Apollo/knowledge/reference/genre_numetal_raprock.md` |
| Genre: Synthwave / Cinematic | `Codex-Apollo/knowledge/reference/genre_synthwave_cinematic.md` |

---

## MODULE 2: Stylish Style Maker

Trigger: "Emulate a band" / "Create a style profile" / "Sonic DNA" / "Style Maker"

Generates detailed "Sound Profiles" for musical entities, then derives high-weight keywords for Suno style prompts.

### Step 1: Data Collection

Ask the user for the following in a guided sequence:
1. **Target**: Which band(s) or artist(s) to emulate?
2. **Producer**: Primary producer/engineer associated with that sound?
3. **Era**: Specific era/year range of their career?
4. **Genre**: Core genres involved
5. **Style**: Specific stylistic hallmarks (e.g., "innovative harmonies", "wall of sound")
6. **Vocals**: Detailed vocal characteristics (gender, tone, accent, delivery)
7. **Mood**: Emotional spectrum of the sound
8. **Instrumentation**: Key instruments and their usage
9. **Mastering**: Production quality (e.g., "warm analog depth", "saturated lo-fi")

### Step 2: Profile Generation

Format into a **Sound Profile Object**:
```javascript
const [Band]Sound [Producer]Producer = {
  era: "[Era]",
  genre: "[Genre]",
  style: "[Style]",
  vocals: "[Vocals]",
  mood: "[Mood]",
  instrumentation: "[Instrumentation]",
  mastering: "[Mastering]"
};
```

### Modes
- **Single Artist:** Extract era, genre, vocals, mastering for one artist
- **Fusion:** Merge DNA of 2–3 artists into a hybrid sonic identity. Rule: No default ingredients — pure representation of source artists
- **Suggest:** Propose "style collisions" based on user's known influence list

**Mastering Rule:** Always include hi-fi descriptors (e.g., 24 bit, 192 khz).
**Saving:** Save profiles to `~/athenaeum/Codex-Apollo/knowledge/styles/{artist-or-fusion-name}.md`

### Genre Lexicon Standard (Suno V5)

When creating standalone Genre DNA profiles, use this structural blueprint:
```markdown
# [Genre Name]
## Core Identity
- **Description**: Essence, history, emotional core
- **Primary Moods**: Dominant emotional states
- **Key Influence/Origins**: Historical or cultural roots

## Sonic DNA
- **Rhythmic Foundation**: Timing, syncopation, BPM ranges, drum patterns
- **Harmonic Profile**: Common chord progressions, scales, tonal characteristics
- **Melodic Traits**: Phrasing, motifs, typical melodic movements

## Instrumentation & Texture
- **Lead Instruments**: Primary melodic instruments
- **Rhythm Section**: Bass, drums, percussion specifics
- **Atmospheric Layers**: Pads, textures, ambient elements
- **Key Textures**: (e.g., 'distorted', 'crystalline', 'gritty', 'lush')

## Suno V5 Production Guide
- **Instrumentation Tags**: Specific tags for instruments
- **Mood & Atmospheric Tags**: Specific tags for mood/vibe
- **Production & Vocal Tags**: Specific tags for processing, mixing, vocal delivery
- **Exclusion Tags**: What to avoid to maintain this specific sound

## Related Sub-genres & Variations
- [Sub-genre Name]: Brief description of how it differs
```

### Suno V5.5 Pitfalls
- **"-core" suffix = screaming vocals**: metalcore, deathcore, hardcore, grindcore, etc. trigger harsh vocals automatically. No override. Use `alt-metal`, `industrial metal`, `heavy rock`, `noise rock` for aggressive-but-clean.
- **Rap + metal blends are fragile**: Suno struggles to maintain rap flow when guitars are heavy. Lead with `hip-hop` or `rap` as primary genre; fold metal into descriptors (`heavy guitars`, `distorted wall of sound`).
- **Spoken-word hooks need `[spoken word]` metatag in lyrics AND `spoken word` in style prompt**: Without both, Suno will sing everything.
- **Full quirks list:** See `references/suno-v5.5-quirks.md`

---

## MODULE 3: Suno Formatter

Trigger: "Format for Suno" / "Suno production" / "Suno handoff" / "Suno formatter"

Converts completed lyrics and a `SUNO HANDOFF BLOCK` into a production file: style prompt, exclude field, formatted lyrics with pipe-stacked metatags, and production notes.

### Step 1: Parse Handoff

Extract: Genres (Primary/Blend/Hierarchy), Mood & Energy Arc, BPM & Key, Instrumentation (Include/Exclude), Vocal Lead & Section Delivery, Backing Vocals & Special Notes.

### Step 2: Build Outputs

#### 1. Style Prompt (≤ 1,000 chars)
- **Order**: PrimaryGenre → Blend → Mood → Vocals → Key Instruments → BPM → Key → Texture
- **Weighting**: Front-load the first 20-30 words
- **Genre Limit**: Name no more than 2 genres directly; fold others into descriptors
- **⚠ CRITICAL**: Never use "-core" genre tags — Suno V5.5 forces screaming vocals. See `references/suno-v5.5-quirks.md`.

#### 2. Exclude Styles (The "Negative" Field)
- Built from `INSTRUMENTATION_EXCLUDE`
- **SKC Baselines**: `no shimmer, no chirp, no random scat vocal, no crowd sounds, no crowd noise, no audience interaction, no crowd effects`
- Add gender exclusions if necessary (e.g., `no female vocals`)

#### 3. Formatted Lyrics (≤ 5,000 chars)
- **Section Tags**: `[Section | modifier | modifier]`
- **Pipe Stacking**: Max 4-6 modifiers
- **Vocal Direction**: Place on its own line above lyrics (e.g., `[Whispered]`)
- **Backing Vocals**: Wrap in parentheses `(like this)`
- **Emphasis**: ALL CAPS for peak emotional words (max 3 per section)
- **Sustain**: Use vowel stretching (`lo-o-ove`)

#### 4. Production Notes
- Summary of sonic intent and generation advice (e.g., "Generate 4–6 variations")

### Formatting Reference
- **Most Reliable Tags**: `[Verse]`, `[Chorus]`, `[Bridge]`, `[Pre-Chorus]`, `[Outro]`, `[Breakdown]`, `[Solo]`
- **Avoid**: Compound tags > 3-4 words
- **Suno Logic**: Parentheses `( )` are ALWAYS sung

### Vocal Delivery Tags
`[Whispered]`, `[Spoken Word]`, `[Belted]`, `[Screamed]`, `[Growl]`, `[Raspy]`, `[Falsetto]`

### Post-Output Menu
1. Regenerate Style Prompt only
2. Regenerate Lyrics Field only
3. Edit specific section tags
4. Add/Adjust backing vocals
5. Character count check
6. Apply **Live Performance Mode** (Adds crowd, room mic, natural reverb)
7. Mark as Final

### Persistence
When the user marks output as Final, save the complete production file (style prompt, exclude field, formatted lyrics, production notes) to `Codex-SKC/lyrics/[title-slug]-production.md`.

---

## INTEGRATION PIPELINE

The ideal path is:
`Lyric Smith` → `Stylish Style Maker` → `Suno Formatter`

### Cross-Gateway Pitfalls
- **Cross-Gateway Context Loss:** When working across different interfaces (e.g., Telegram Gateway vs. Local Terminal), do not assume `last-handoff.md` or session logs are immediately synced or visible across all instances.
- **Verification over Assumption:** If a handoff file is missing, do not "hallucinate" a reconstruction. Perform a deep content search (`search_files` on host filesystem) across the entire user home directory to find the actual persisted log file.
- **Narrative Flow Integrity:** In Cinematic Hip Hop, the transition from "Reign" (Verse 2) to "Chaos" (Bridge) is critical. Ensure the "Sovereign Flex" of Verse 2 precedes the "Symphonic Chaos" of the Bridge to maximize emotional impact.