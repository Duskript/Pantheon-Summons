# Suno Instrumental Arrangement Direction Format

Proven format for directing Suno instrumental tracks. Discovered through "Crown the Sun" (Industrial Phonk, 160 BPM C# Minor).

## The Format

Each section uses bracketed directions with this pattern:
```
[instrument/element] + [action/technique] + [quality/texture detail]
```

## Examples by Category

### Instrument + Action + Texture
```
[sustained low 808 bass drone, C# minor]
[distorted 808 bass plays main riff — syncopated, aggressive]
[djent guitar chugs lock with 808 rhythm, tight palm-mute]
[cinematic brass section — triumphant fanfare, high register]
[metallic percussion driving — crash cymbals on every beat]
```

### Energy/Dynamics
```
[all instruments drop — sudden silence]
[EXPLOSIVE HIT — full band slams back in, maximum volume]
[1 beat vacuum — total silence]
[full chorus arrangement — holds for 2 bars, then strips]
```

### Atmospheric/Production
```
[glitchy synth stutters, panning left to right]
[distant djent guitar chugs, muted and filtered]
[brass pads swell — dark, haunting reverb]
[glitchy synth echoes, isolated and distant]
```

### Rhythmic Direction
```
[kick drum on 1 and 3, snare on 2 and 4, heavy compression]
[metallic percussion accelerates — doubling rhythm each bar]
[808 bass slides upward — rising pitch, sustained]
```

## Rules

1. **3-6 directions per section max** — more than ~6 confuses Suno
2. **Be specific about playing technique**: "tremolo picking", "palm-mute", "legato" — not just "guitar plays"
3. **Include production quality**: "heavy compression", "stadium reverb", "muted and filtered" — these matter
4. **Mark energy changes explicitly**: "sudden silence", "EXPLOSIVE HIT", "strips down"
5. **First line must be [Instrumental]** — prevents Suno from adding vocals
6. **Use em-dashes (—) for secondary detail**, not commas — makes the primary instruction clearer

## What NOT to Do

- ❌ `[guitar plays loudly]` — too vague
- ✅ `[djent guitars — full power chords, open and ringing]` — specific instrument, technique, quality
- ❌ Put contradictory directions in same section: `[calm]` + `[aggressive]`
- ❌ More than 6 directions per section
- ❌ Forget the `[Instrumental]` tag on line 1
