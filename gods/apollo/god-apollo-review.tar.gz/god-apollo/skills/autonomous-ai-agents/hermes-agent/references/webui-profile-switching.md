# Hermes Web UI — Profile Switching Internals

> **Applies to:** Hermes Web UI (`~/hermes-webui/`, nesquena build — port 8787)
> **Not to be confused with:** Hermes Dashboard (port 9119), Hermes Workspace, LiteLLM Admin UI

## Architecture

The Hermes Web UI uses a **cookie-based, per-client** profile model. Unlike the CLI (`hermes -p <name>`), the web UI does NOT change the process-global `HERMES_HOME` or `_active_profile` when switching. Instead:

1. **Profile switch request:** JS POSTs to `/api/profile/switch` with `{"name": "marvin"}`
2. **Server sets cookie:** Response includes `Set-Cookie: hermes_profile=marvin; HttpOnly; Path=/; SameSite=Lax`
3. **Subsequent requests:** JS uses `fetch()` with `credentials: 'include'`, so the browser automatically sends the cookie
4. **Per-request routing:** `server.py` calls `get_profile_cookie(handler)` → `set_request_profile(name)` — thread-local profile context scoped to that HTTP request
5. **Session isolation:** A running stream in the old profile continues unaffected; switching creates a new session for the new profile

## Key Files & Functions

| Component | File | Purpose |
|-----------|------|---------|
| `api()` helper | `static/workspace.js` | `fetch()` wrapper with `credentials: 'include'` |
| `switchToProfile()` | `static/panels.js:3768` | JS function that triggers the switch |
| `activateCurrentProfile()` | `static/panels.js:3687` | Wrapper for the "Activate" button in profiles panel |
| `POST /api/profile/switch` | `api/routes.py:4061` | Server endpoint, calls `switch_profile(name, process_wide=False)` |
| `switch_profile()` | `api/profiles.py:662` | Validates profile exists, returns `{active, profiles, default_model, default_workspace}` |
| `build_profile_cookie()` | `api/helpers.py:283` | Builds `Set-Cookie` header |
| `get_profile_cookie()` | `api/helpers.py:261` | Reads and validates cookie from request |
| `set_request_profile()` | `api/profiles.py:186` | Sets thread-local profile context |
| `get_active_profile_name()` | `api/profiles.py:173` | Returns thread-local profile or process-global fallback |

## API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/profiles` | GET | List all profiles + process-global active |
| `/api/profile/active` | GET | Get currently active profile for this request's cookie |
| `/api/profile/switch` | POST | Switch to a named profile, sets cookie |
| `/api/profile/create` | POST | Create a new profile (optionally clone from existing) |
| `/api/profile/delete` | POST | Delete a named profile |

## The SOUL.md Gotcha (Most Common Bug)

**When a profile is cloned from default, its `SOUL.md` still contains the ORIGINAL profile's persona.**

Even after switching to the new profile via the web UI, starting a new conversation will use the old profile's persona because `SOUL.md` (= `PERSONA.md`, the base system prompt) was inherited from the clone source.

**Fix:** Update the new profile's `SOUL.md` to contain the desired persona. Each profile has its own:
```
~/.hermes/profiles/<name>/SOUL.md
```

In the Pantheon, every god has a unique SOUL.md. Apollo, Hephaestus, and Marvin each get their own. The default profile (`~/.hermes/SOUL.md`) is Hermes.

## Debugging Profile Switch Issues

### Step 1: Verify the profile exists and is healthy
```bash
hermes profile list           # Shows all profiles + active + gateway status
hermes profile show <name>    # Details: model, path, skills, .env, SOUL.md
```

### Step 2: Test the API directly
```bash
# Switch to profile
curl -s -X POST http://localhost:8787/api/profile/switch \
  -H "Content-Type: application/json" \
  -d '{"name": "marvin"}'
# Response should include "active": "marvin"

# Verify the switch with cookie
curl -s -H "Cookie: hermes_profile=marvin" \
  http://localhost:8787/api/profile/active
# Should return {"name": "marvin", "path": "/home/konan/.hermes/profiles/marvin"}
```

### Step 3: Check the cookie is actually being sent
- Open browser DevTools → Application → Cookies → `localhost:8787`
- Look for `hermes_profile` cookie
- If missing, check for browser cookie blocking or extensions

### Step 4: Check for JS errors
- Open browser DevTools → Console
- Look for `switch_failed` or network errors on `/api/profile/switch`

### Common Pitfalls

| Symptom | Likely Cause |
|---------|-------------|
| Switching profiles doesn't change chat behavior | SOUL.md still has old persona — update it |
| Cookie not being stored | `HttpOnly` flag prevents JS access but doesn't block browser storage — check DevTools |
| Profile dropdown shows correct active but sessions aren't loading | In-progress session creates a new session on switch — check sidebar for new empty session |
| API returns 404 on switch | Profile doesn't exist — verify with `hermes profile list` |
| Switch succeeds but no visible UI change | The profile chip label updates but workspace/model/session changes may be subtle — refresh page |

## Quick Verification Round-Trip

```bash
echo "=== Switch to marvin ==="
curl -D - -s -X POST http://localhost:8787/api/profile/switch \
  -H "Content-Type: application/json" \
  -d '{"name": "marvin"}' | grep -E 'Set-Cookie|HTTP/'

echo "=== Verify with cookie ==="
curl -s -H "Cookie: hermes_profile=marvin" \
  http://localhost:8787/api/profile/active

echo "=== Switch back ==="
curl -s -X POST http://localhost:8787/api/profile/switch \
  -H "Content-Type: application/json" \
  -d '{"name": "default"}'

echo "=== Verify back to default ==="
curl -s -H "Cookie: hermes_profile=default" \
  http://localhost:8787/api/profile/active
```
