# Pantheon Embedding Architecture

Konan's stack has **three independent embedding paths** that all feed ChromaDB. When you see `401 Unauthorized` for `https://openrouter.ai/api/v1/embeddings` in agent.log, it's coming from one of these.

## 1. Hermes Pantheon Plugin (`~/.hermes/plugins/pantheon/__init__.py`)

- **Class:** `_OllamaEmbedder`
- **Default:** `http://localhost:11434/api/embeddings` with `nomic-embed-text`
- **Configured via:** `~/.hermes/pantheon.json` — keys `ollama_host`, `embed_model`
- **This one is always Ollama** — no OpenRouter fallback path.
- Logger name: `_hermes_user_memory.pantheon`
- Error messages: `"Embedding failed for query: %s"` at line 549

## 2. Pantheon MCP Server (`~/pantheon/pantheon-core/mcp_server.py`)

- **Class:** `_Embedder` (line 60)
- **Logic:** If `ATHENAEUM_EMBED_API_KEY` or `OPENROUTER_API_KEY` is set → uses OpenRouter. Otherwise → Ollama fallback.
- **OpenRouter URL:** `https://openrouter.ai/api/v1/embeddings`
- **Model:** `nvidia/llama-nemotron-embed-vl-1b-v2:free`
- Loads `.env` at startup via `os.environ.setdefault()`
- Logger name: `pantheon-mcp`

## 3. Mnemosyne Client (`~/pantheon/pantheon-core/mnemosyne/client.py`)

- Checks `ATHENAEUM_EMBED_PROVIDER` env var
- If `"ollama"` → uses Ollama `/api/embeddings` format (`{model, prompt}`)
- Otherwise → OpenAI-compatible format (`{model, input}` + `Authorization` header)
- **Default embed URL:** `https://openrouter.ai/api/v1/embeddings` (overridable via `ATHENAEUM_EMBED_URL`)
- **Default model:** `nvidia/llama-nemotron-embed-vl-1b-v2:free` (overridable via `ATHENAEUM_EMBED_MODEL`)

## Switching to Ollama (what was done to fix the 401 spam)

1. Comment out `ATHENAEUM_EMBED_API_KEY` in `~/.hermes/.env` — MCP server falls through to Ollama
2. Set `ATHENAEUM_EMBED_PROVIDER=ollama` in `~/.hermes/.env` — Mnemosyne client uses Ollama format
3. Create `~/.hermes/pantheon.json` with `{"ollama_host": "http://localhost:11434", "embed_model": "nomic-embed-text"}` — Hermes plugin already defaults to Ollama, this makes it explicit
4. Restart the MCP server: `systemctl --user restart pantheon-mcp`
5. Verify Ollama is running: `curl http://localhost:11434/api/tags` — should show `nomic-embed-text:latest`
