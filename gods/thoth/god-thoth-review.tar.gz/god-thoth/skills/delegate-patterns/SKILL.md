---
name: delegate-patterns
description: "When and how to use delegate_task for parallel sub-agents — heuristics, battle-tested patterns, and pitfalls."
version: 1.0.0
metadata:
  hermes:
    tags: [delegation, subagent, parallel, patterns, pantheon]
---

# Delegate Patterns

When to use `delegate_task` and how to do it well. Load this skill into any session where complex multi-step work is expected.

## Trigger Heuristics

**Delegate when:**
- **2+ independent subtasks** — they can run in parallel and don't depend on each other's output
- **Research-heavy task** — web searches, multi-file reading, external API calls. Keeps YOUR context clean.
- **Code review + fix pair** — one reviews, one fixes. The reviewer's output is context for the fixer.
- **Long context tasks** — anything that would produce 200+ lines of intermediate output. Delegation keeps your session lean.
- **Task takes >3 tool calls** — if you'd need 4+ sequential tool calls, consider delegating instead.
- **User sends an image** — screenshot, photo, diagram, or UI mock. Load this skill and jump to **Pattern 7: Vision Analysis**. Do NOT attempt to analyze images yourself before delegating.

**Do NOT delegate:**
- **Single-file simple edit** — overhead outweighs benefit. Just use read_file + patch.
- **Task requires user judgment** — sub-agents can't use `clarify`. You must make the call.
- **Sequential dependencies that can't parallelize** — if every step depends on the previous, delegation adds latency with no gain.
- **Critical infrastructure changes** — sub-agents have `auto_approve`, so they can `rm -rf` without asking. You must review their output before trusting.

## Pattern 1: Parallel Research

Two+ independent research topics. Each sub-agent does its own web searches and file reads, returns findings.

```
delegate_task(tasks=[
  {
    goal: "Research X: find the latest docs, API changes, and community best practices...",
    context: "We're evaluating X for use in the Pantheon project. Focus on production readiness, known issues, and migration effort.",
    toolsets: ["web"]
  },
  {
    goal: "Research Y: compare alternatives, pricing, and community size...",
    context: "Y is the competitor. We need a feature comparison table and adoption metrics.",
    toolsets: ["web"]
  }
])
```

**When to use:** Evaluating new tools, comparing approaches, gathering requirements before building.

## Pattern 2: Code Review + Fix

One sub-agent reviews code for issues (security, style, bugs), another applies fixes. The reviewer runs first, fixer gets the review as context.

```
# Step 1: Review
delegate_task(goal="Review ~/pantheon/pantheon-core/mcp_server.py for bugs, security issues, and style violations. Return a numbered list of findings with file:line references.",
  context="This is the Pantheon MCP server. Look for: unhandled exceptions, hardcoded paths, missing error handling, race conditions.",
  toolsets=["terminal", "file"])

# Step 2: Fix (after reviewing output)
delegate_task(goal="Apply all fixes from the review. Each fix should be minimal and focused.",
  context="Review findings: [paste review output here]. File: ~/pantheon/pantheon-core/mcp_server.py. Fix each issue, one at a time.",
  toolsets=["terminal", "file"])
```

**When to use:** Pre-commit review, post-refactor validation, hardening before deployment.

## Pattern 3: Multi-File Refactor

Split a refactor across files. Each sub-agent handles its own file with the same spec.

```
delegate_task(tasks=[
  {
    goal: "Refactor ~/pantheon/gods/hephaestus/harness.yaml per spec below...",
    context: "SPEC: Add 'delegation_preference' field to god harness schema. Update validation. Keep backward compat. File: ~/pantheon/gods/hephaestus/harness.yaml",
    toolsets: ["terminal", "file"]
  },
  {
    goal: "Refactor ~/pantheon/pantheon-core/god_registry.py per spec below...",
    context: "SPEC: Add 'delegation_preference' field to god harness schema. Update validation. Keep backward compat. File: ~/pantheon/pantheon-core/god_registry.py",
    toolsets: ["terminal", "file"]
  }
])
```

**When to use:** API changes touching multiple files, schema migrations, renaming across a codebase.

## Pattern 5: Fan-Out Content Generation

Generate N independent files from a shared template. Each sub-agent gets the template definition + its specific topic, and writes one file. Perfect for populating knowledge bases, documentation, or any structure where entries are independent and order doesn't matter.

```python
# Step 1: Write a template exemplar yourself (sets quality bar + format)
# Step 2: Fan out the remaining entries
delegate_task(tasks=[
  {
    goal: "Write a comprehensive reference entry for [Topic A] following the exact template from [exemplar file]. File must be written to Codex-X/subfolder/topic-a.md",
    context: "TEMPLATE: [paste template sections]. SPECIFICS: [topic-specific detail: presentation, timeline, treatment landscape, red flags, prevention]. SOURCES: [Tier 1 URLs]. WARNINGS: path format is Codex-<Name>/subfolder/file.md not just subfolder/file.md. Target 5-12KB. Include a real Sources section with URLs.",
    toolsets: ["file"]
  },
  {
    goal: "Write a comprehensive reference entry for [Topic B]...",
    context: "...",
    toolsets: ["file"]
  },
  # ... up to concurrent limit (default 4)
])
```

Critical success factors:
- **Template exemplar** must be written first by YOU — sub-agents follow the format you set, they don't invent it
- **Assign disjoint file paths** per sub-agent — no shared files, no merge conflicts
- **Set a size target** (5-12KB) — without this, sub-agents produce 30KB+ monsters or 2KB stubs
- **Provide real source URLs** in context — sub-agents hallucinate URLs easily
- **Warn about path format** — they often drop the Codex prefix. `Codex-Asclepius/subfolder/file.md`, not `subfolder/file.md`
- **Verify after delegation** (Pattern 4) — confirm files exist via walk/read

**When to use:** Knowledge base population, documentation sprints, multi-entity reference writing, generating template-based content where entries are truly independent.

**Pitfall — template drift:** Sub-agents will subtly vary the format over time. You don't need to enforce pixel-perfect consistency, but catch structural drift (missing sections, reordered headings) early. Fix the drift in subsequent batch contexts.

### When to use with `orchestrator_enabled`

Set `orchestrator_enabled: false` when all tasks are truly independent with no sub-grouping. An orchestrator adds a full round-trip of latency with zero benefit for flat fan-out.

Set `orchestrator_enabled: true` when the work is hierarchical — e.g., one sub-agent produces a taxonomy, then others write entries for each node in the taxonomy.

## Pattern 9: Sequential Phase Build (Backend → Frontend)

When building full-stack features (backend API + frontend UI), the frontend depends on the backend's API contract. **Do NOT parallelize these** — they must run sequentially with a verification gate between phases.

```python
# Phase 1: Backend (API endpoints, data model, routes)
delegate_task(
    goal="Implement Phase 1 (Backend API Extensions) for the [Feature Name] feature. Add new GET endpoints and extend the POST export endpoint...",
    context="[Full context: file paths, existing code patterns, API contract details]",
    toolsets=["terminal", "file"]
)

# VERIFY GATE — always confirm Phase 1 before starting Phase 2
# Run curl commands against the new endpoints to confirm they work
terminal("curl -s http://localhost:8788/api/endpoint | python3 -m json.tool")

# Phase 2: Frontend (UI components that consume Phase 1 APIs)
delegate_task(
    goal="Build the frontend UI for [Feature Name]. The following API endpoints are now available: [list endpoints + response shapes]...",
    context="[Full context: file paths, existing UI patterns, API contract to call]",
    toolsets=["terminal", "file"]
)
```

**Critical flow:**
1. Backend subagent writes endpoints, **restarts the server**, and reports what it returns
2. YOU verify the endpoint responses yourself with curl
3. Only then delegate the frontend, **including the exact API response shapes** in its context
4. Frontend subagent gets the backend's actual contract, not guesses

**When to use:** New feature that touches both `api/routes.py` (or equivalent) AND a UI file. Frontend code literally cannot work until the backend responds with the right shape.

**Do NOT use for:** Pure backend work, pure frontend work, or features where the frontend can mock the API contract.

### Pitfall — Subagent file modification invalidates parent reads

When a subagent modifies a file that the parent agent has already read (via `read_file`), the parent's cached version becomes stale. Subsequent `patch` operations from the parent will fail with:

> "subagent modified files the parent previously read — re-read before editing"

**Prevention:**
- After a subagent returns, **always re-read files** the subagent modified before attempting further edits
- Use `read_file(path)` to refresh your view of the file
- Only then attempt `patch` operations
- This applies across ALL delegation patterns, not just sequential phase builds

**Example — the wrong way:**
```python
delegate_task(goal="Edit api/routes.py to add endpoint X", ...)
# Subagent modifies api/routes.py
# Parent tries to patch api/routes.js WITHOUT re-reading → FAILS
```

**The right way:**
```python
delegate_task(goal="Edit api/routes.py to add endpoint X", ...)
read_file("api/routes.py")  # Re-read after subagent
# Now patch works
```

## Pattern 7: Vision Analysis

When a user shares an image (screenshot, photo, diagram, UI mock), **always delegate** to a vision-capable subagent. Do NOT attempt to analyze images directly — your toolset lacks pixel-level vision models.

```python
delegate_task(
    goal="Describe everything visible in the screenshot at /path/to/image.jpg. Look for: layout, text content, colors, UI state, icons, errors, visual issues.",
    context="The user shared this image to diagnose a problem or show a result. Be thorough — note every visible element, error message, and UI state.",
    toolsets=["vision", "file"]
)
```

**Key heuristics:**
- **The `vision` toolset provides vision-capable model access** — always include it when images need analysis
- **Also include `file`** so the sub-agent can read the image file path
- **The same applies to screenshots** in `~/.hermes/cache/screenshots/` or `~/.hermes/cache/images/`
- **Pass the full absolute path** in the goal — sub-agents can't infer relative paths
- **Be explicit about what to look for** — errors, layout issues, colors, UI state
- **The sub-agent may lack vision model credentials** (no API key configured). If so, fall back to whatever file metadata you can extract (file size, dimensions via PIL, EXIF data, color histograms) and report that the vision model wasn't available

**Pitfall — vision model not available:** If no vision-capable model is configured (e.g., Ollama Cloud returns 401), the sub-agent will fail to actually "see" the image. In that case, extract what you can via PIL/terminal analysis (pixel color distribution, file metadata, EXIF) and tell the user you couldn't get a visual read.

**Pitfall — premature analysis:** Don't try to analyze images yourself before delegating. Sending a `vision_analyze` call that doesn't exist or guessing at image content wastes turns and frustrates the user. Delegate first, ask questions later.

## Pattern 6: Verify-After-Delegate (CRITICAL — applies to ALL delegation patterns)

Sub-agents are **self-reporters, not verified fact-checkers**. A sub-agent that claims "file written" or "tests pass" may be wrong.

**Always verify after delegation:**
```python
# After a sub-agent claims to write a file:
read_file(path)  # confirm content exists and is correct

# After a sub-agent claims tests pass:
terminal("cd ~/pantheon && python -m pytest tests/ -x -q")

# After a sub-agent claims to push/upload:
# Check the remote yourself — URL, API status, git log
```

**When to use:** EVERY TIME a sub-agent produces side effects. This is not optional.

## Toolsets Quick Reference

| Toolset | Contains | Use for |
|---------|----------|---------|
| `["terminal", "file"]` | Shell, read/write/patch/search | Code work (most common) |
| `["web"]` | web_search, web content extraction | Pure research |
| `["terminal", "file", "web"]` | Everything | Full-stack tasks |
| `["search"]` | web_search only (lighter) | Quick lookups |

Default: `["terminal", "file"]` for code tasks, `["web"]` for research.

## Pattern 8: Background Terminal Tasks (Non-Blocking Work)

Not everything needs `delegate_task`. Use **`terminal(background=true, notify_on_complete=true)`** for work that doesn't need your immediate attention — it runs independently and taps you when done.

### Decision Matrix

| Execution Mode | Use Case | Blocks Turn? | Can Notify? | Detects Hung? |
|---|---|---|---|---|
| **Background terminal** | Long searches, batch reads, research | No ✅ | **Yes** — `notify_on_complete` ✅ | You poll with `process(action='poll')` ✅ |
| **Blocking inline** | `execute_code`, file writes, deploys, server restarts | Yes (intentional) | N/A | N/A |
| **Instant inline** | Single small `read_file`, quick grep | Barely (sub-second) | N/A | N/A |

### When to Background

**Background (fire & forget with notify_on_complete):**
- `search_files` — batch searches across a codebase
- `session_search` — digging through past conversations
- `read_file` (bulk or large) — batch reads, or one big file
- `web_search` / `web_extract` — research errands

**Blocking (pause — the user expects to wait):**
- `execute_code` — multi-step logic or side effects
- File writes (`patch`, `write_file`) — user wants confirmation it landed
- Deployments, server restarts

**Instant inline (sub-second — not worth backgrounding):**
- Single `read_file` for a small config or snippet
- Quick `grep` via terminal

### The Flow

```python
# 1. Kick off in background, respond to user immediately
terminal(command="python3 ~/scripts/search-gods.py 'vision'", background=True, notify_on_complete=True)
# "Started the search, I'll pipe up when results land."

# 2. Keep talking with the user — results arrive asynchronously

# 3. When notify fires, process results in your next turn
# The system handles this — you just respond naturally
```

### Execution Modes — When Not to Block

Avoid blocking the user on tasks that don't need their attention. The `terminal(background=true)` + `notify_on_complete=true` pattern is the correct alternative to `delegate_task` for non-coding work because:

- It doesn't consume a sub-agent slot
- It doesn't require a separate model call
- It doesn't block the conversation
- The notification fires on completion, so you don't need to remember to check
- You can `process(action='poll')` mid-flight if the user asks for a status update

### Pitfalls

1. **Don't background `execute_code` or file writes** — these need blocking for the user to confirm results before proceeding.
2. **Wrap searches in Python scripts with built-in timeouts** — so a hung API call self-terminates rather than running forever.
3. **`notify_on_complete` fires once on exit.** If you're mid-turn when it fires, you catch it on your next response. No lost notifications.
4. **You can't react to results automatically** — the user has to say "check on that search" or you pick up the notification on your next turn. That's the trade-off for not blocking.

### Interruption Recovery (Critical)

When a turn gets interrupted mid-tool-processing (system note says *"Your previous turn was interrupted before you could process the last tool result(s)"*):

**STOP. Do not guess or jump to old tasks.**

1. Acknowledge the gap explicitly
2. Ask the user where you left off
3. Do not re-execute completed work, re-fix bugs you already fixed, or re-answer questions already answered
4. Do NOT autonomously start new tasks — discuss first

This is the single biggest source of context confusion. An interrupted turn + guessing = re-doing work and frustrating the user. Always ask.

## Pitfalls

1. **Sub-agents have NO memory of your conversation.** Pass ALL relevant context (file paths, error messages, constraints, project conventions) in the `context` field. Be verbose.

2. **Sub-agents can't ask questions.** They cannot use `clarify`. If they hit ambiguity, they guess. Make your `goal` unambiguous.

3. **Sub-agent summaries are SELF-REPORTS.** A sub-agent saying "done successfully" means nothing. Verify side effects yourself (Pattern 4).

4. **Missing tools cause silent failures.** If a sub-agent needs `web` but only gets `["terminal", "file"]`, it'll hit "tool not found" errors and potentially produce incomplete work. Set toolsets carefully.

5. **Parallel tasks can race on shared files.** Two sub-agents writing the same file = one wins, one loses silently. Assign disjoint file sets.

6. **Timeout kills work in progress.** `child_timeout_seconds: 600` (10 min). For longer tasks, split into smaller subtasks.

7. **Network-dependent sub-agents stall on slow API calls** — Web-dependent tasks (`web_search`, `web_extract`) are the most common cause of sub-agent timeout. The sub-agent sends a call, the API hangs (slow server, rate-limiting, transient failure), and the sub-agent burns through its iteration budget waiting rather than doing productive work. This happened 3× in one session when researching multi-domain skill ecosystems — each sub-agent had only completed 5-6 calls before timing out at 600s.

   **Mitigations:**
   - Keep web-dependent sub-agent goals **narrow and focused** — 1-2 search queries, not 5-8. Limit `max_iterations` for web-only tasks.
   - **Prefer batch-and-switch**: Run web searches yourself (in main context), collect the results, then delegate file-writing/code work to sub-agents that don't need network access.
   - If you must delegate web work, split into **more sub-agents with less work each** (2 search queries per sub-agent) rather than fewer sub-agents with heavy work — this contains the blast radius of a single hanging API call.
   - Consider lowering `child_timeout_seconds` for web-only tasks (e.g., 180s instead of 600s) so failed sub-agents recycle faster.
   - **Log the failure pattern** — if the same API endpoint keeps timing out, avoid delegating work that depends on it.

7. **Orchestrators add latency.** If `max_spawn_depth: 1` and `orchestrator_enabled: true`, an orchestrator sub-agent can spawn its own children — but this adds a full round-trip. Use only for clearly hierarchical work.

8. **Deepseek V4 Flash reasoning tokens.** The delegation model may dump content into reasoning tokens. Set `max_iterations` high enough (50 is fine) and don't micromanage token budgets.

9. **MCP/server outages cause sub-agent retry loops.** When critical infrastructure (MCP server, APIs, databases) is down, sub-agents will blindly retry failing calls, burning through their iteration budget on dead-end retries. In one observed case, a sub-agent spent 7 of 9 total API calls re-trying a dead MCP server before giving up and returning stale training data. **Prevention:** If you know about an outage before delegating, pass a `context` note like `"MCP server is down — avoid all mcp_pantheon_* tools, use directly available APIs (terminal, curl, file) instead."` This short-circuits the retry cycle. If you discover an outage mid-flight, re-delegate with the context note.

## Config Reference

Current delegation config (Hephaestus profile):
```yaml
delegation:
  model: opencode/deepseek-v4-flash
  provider: local-litellm
  max_iterations: 50
  child_timeout_seconds: 600
  max_concurrent_children: 4
  orchestrator_enabled: true
  subagent_auto_approve: true
```

To change: edit `~/.hermes/profiles/hephaestus/config.yaml`, then `/reset` the session.