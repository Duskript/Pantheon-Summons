---
name: codex-authoring
description: "Author structured, sourced knowledge base entries into any Athenaeum Codex — template-driven reference content with authoritative sourcing, evidence hierarchies, and parallel sub-agent generation. For medical/health content, scientific references, how-to guides, or any domain where accuracy and provenance matter."
version: 1.0.0
---

# Codex Authoring — Structured Knowledge Base Population

Authoring entries for an Athenaeum Codex: identifying authoritative sources, defining a template, writing a reference exemplar, then parallelizing the remaining entries via `delegate_task`.

## When to Use

- User asks to build/kickstart a knowledge base in any domain
- A Codex exists but is empty (0 files) or underpopulated
- You need to write structured, consistently formatted reference entries that cite authoritative sources

Do **NOT** use for: one-off creative writing, raw data dumps, or temporary notes belonging in the General codex.

## Workflow

### Phase 1: Reconnaissance

1. **Check existing Codex** — walk the Codex to confirm the directory tree and any pre-existing content
   ```
   mcp_pantheon_athenaeum_walk(path="Codex-<Name>/")
   ```
2. **Check pre-existing reference files** — especially `references/` subfolder which may have source evaluations already
3. **Check existing entries** in subfolders (`conditions/`, `protocols/`, etc.) to avoid duplication and confirm schema
4. **Confirm audience and scope** with the user — are these consumer-facing, clinician-facing, or both? How many entries?

### Phase 2: Source Identification

Identify **Tier 1 authoritative sources** for the domain. The medical pattern (from Codex-Asclepius) is a good analogy:

| Tier | Type | Examples (Medical) |
|------|------|--------------------|
| 1 (Core) | Free, comprehensive, authoritative | Merck Manual, MedlinePlus, DailyMed, CDC |
| 1 (Core) | Evidence-backed (subscription if budget allows) | UpToDate, Cochrane, NICE |
| 2 (Supplement) | Strong, free, consumer-friendly | Mayo Clinic, NHS Inform |
| 3 (Specialized) | Niche or premium | Isabel, DrugBank, Science-Based Medicine |

**General principle for any domain**: prefer sources that are:
- **Non-commercial** (government, academic, non-profit) over commercial
- **Peer-reviewed** or editorially independent
- **Evidence-graded** (uses explicit quality ratings like GRADE, A/B/C/D)
- **Freely accessible** where possible

**Write source evaluation** to `Codex-<Name>/references/` as a reference file if one doesn't exist.

### Phase 3: Template Definition

Define a template with consistent sections. Medical template as example:

| Section | Purpose |
|---------|---------|
| **Overview** | What it is, cause/etiology, prevalence, key demographics |
| **Presentation** | Signs, symptoms, typical timeline (day-by-day), distinguishing features |
| **Self-Care** | What the person can do at home — rest, hydration, diet, comfort |
| **OTC / Treatment** | Drug options with evidence, what doesn't work, safety warnings |
| **Red Flags** | Specific thresholds for when to see a doctor vs. ER |
| **Prevention** | Vaccination, hygiene, lifestyle — with honest efficacy |
| **Sources** | Real URLs from Tier 1 sources |

Write the template to `Codex-<Name>/conditions/INDEX.md` (or equivalent subfolder INDEX.md) so entries are discoverable.

### Phase 4: Reference Exemplar

Write the **first entry yourself** — this sets the template, quality bar, and tone for all subsequent entries. Target 5-12KB. It must be complete enough that sub-agents can infer the format without ambiguity.

### Phase 5: Parallel Generation

For the remaining entries, use `delegate_task` with:

- A **complete context** parameter that includes:
  - The template format (can reference the exemplar)
  - The specific condition/topic to cover
  - Domain-specific detail: causes, symptoms, treatment landscape, red flags, prevention
  - Required source list (Tier 1 URLs)
  - Target file path in the Athenaeum

- **Why delegate_task works here**: each entry is independent — no shared state, no ordering constraints, no merge conflicts. Perfect for fan-out parallelism.

- **Pitfalls to avoid in the prompt**:
  - Specify the exact write function: `mcp_pantheon_athenaeum_write(codex="Codex-<Name>", path="full/path.md")`
  - Warn about path format: use `Codex-<Name>/subfolder/file.md`, not just `subfolder/file.md`
  - Set a target size (5-12KB) so sub-agents don't generate 30KB monsters or 2KB stubs
  - Remind them to reference actual authoritative sources, not invented URLs
  - Request they include a "Sources" section with real URLs

### Phase 6: Update Shared Context

After the batch completes:
1. Write a progress tracker to `~/pantheon/shared/active/kb-population.md`
2. Log to a shared brain memory (or journal) for long-lived context
3. Save a durable **memory** entry summarizing the Codex and what's been populated

## Evidence Hierarchy (Resolving Source Conflicts)

When sources disagree on claims, use this general hierarchy:

1. **Systematic reviews / meta-analyses** (Cochrane-grade or equivalent)
2. **Graded clinical guidelines** (formal recommendations with evidence levels)
3. **Evidence-graded clinical decision support** (with explicit GRADE ratings)
4. **Regulatory labels / approved indications** (for safety and dosing only)
5. **Standard clinical references** (textbook-level, peer-reviewed)
6. **Consumer health information** (Mayo Clinic, MedlinePlus, NHS)
7. **Health news interpretation** (Harvard Health, Behind the Headlines)

## Pitfalls

- **Template drift**: Sub-agents will subtly vary the format. Accept minor formatting variation but catch structural drift (missing sections, different section ordering).
- **Source hallucination**: Sub-agents may invent URLs. Always spot-check. Prefer giving them known-good URLs in the context.
- **read_file corrupts content**: The regular `read_file` tool injects line-number prefixes into content output (e.g. `'   42|| line text'`). Using that output with `write_file` writes the corrupted data back. Always use `mcp_pantheon_athenaeum_read` to read Athenaeum files — it returns clean content without line-number prefixes. When using `patch` on Athenaeum markdown files, be aware that the fuzzy matcher can strip leading `||` pipes from markdown table rows — read the full file first and verify the diff.

- **patch tool + markdown tables**: The `patch` tool's fuzzy matching can inadvertently strip leading `||` markers from table rows in markdown files. Always read the full file first, verify the diff after patching, and use `mcp_pantheon_athenaeum_write` as fallback if patch corrupts formatting.
- **Size explosion**: Without a target size, sub-agents write 25KB+ behemoths or 2KB stubs. Set explicit bounds.
- **Parallel conflicts**: Two sub-agents writing different files is fine. Two writing the same file is not. Assign unique paths.
- **Evidence overreach**: Don't let consumer content sound like clinical advice ("take this drug"). Use disclaimers ("OTC options", "self-care" not "treatment").
- **Scope creep**: When the user says "keep going," define the next batch clearly rather than trying to do everything at once.

## Related Skills

- `athenaeum-maintenance` — handles the downstream: embedding, entity extraction, health checks after content is written
- `delegate-patterns` — heuristics for when and how to use delegate_task (this skill uses it as a tactical tool for fan-out)