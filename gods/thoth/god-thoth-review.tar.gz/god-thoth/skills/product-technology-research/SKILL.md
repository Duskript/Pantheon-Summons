---
name: product-technology-research
description: "Deep-dive on external products, platforms, and technologies — scrape docs/blogs/GitHub via curl when web_search unavailable, synthesize findings, and map to our infrastructure."
version: 1.0.0
---

# Product & Technology Deep-Dive Research

Systematic approach for researching external products, platforms, or technologies when the user asks "what is X" or "can we build something like Y."

## When to Use

- User asks "What is [product/technology]?" — no web_search tool available
- User asks "Can we build something similar?" and needs architecture comparison
- User mentions a project/service/startup you're unfamiliar with
- User shares a link to an article/post (including paywalled content) that makes claims needing validation
- Any time you need to evaluate external tech against our Pantheon infrastructure

## The Research Pipeline (5 Phases + Paywall Handling + Multi-Angle Delegation)

### Phase 1: Source Discovery

Hit multiple surfaces in parallel:

```
# Product homepage — primary positioning
curl -sL "https://product.io"

# Blog / announcements — detailed technical content
curl -sL "https://product.io/blog/introducing-foo/"

# GitHub — actual code, stars, README
curl -sL "https://api.github.com/repos/owner/repo"

# Docs — architecture, API reference
curl -sL "https://docs.product.io"
```

**Always scrape at least 3 sources** (homepage, blog, docs/GitHub) to cross-validate claims vs reality. A homepage hypes; a blog post explains trade-offs; a GitHub README tells you what's actually shipped.

#### Paywalled / Subscriber-Only Content as Research Starting Point

When the user shares a link to a paywalled article (Substack, Medium members-only, Google Doc behind auth), **don't treat it as a dead end**. Instead:

1. **Extract available metadata** — title, description, OG tags, H1s. These usually contain the thesis and key claims even when body is blocked.
2. **Decompose the article's claims** into independently-searchable sub-topics. If the article says "vector search is demoted" and "85% of agent effort is retrieval," those are testable claims — search for independent validation.
3. **Validate each claim independently** by scraping vendor blogs, competitor sites, and industry announcements. If multiple sources converge on the same figures (e.g. "85%" appearing in both a Substack post and Pinecone's launch blog), that's signal.
4. **Cross-reference with our existing knowledge base** — search the Athenaeum to find prior research that already covers the topic.

**Example from May 2026:** User shared a paid Substack post "RAG for AI Agents: Knowledge Layer Architecture Guide." Instead of hitting the paywall wall, we:
- Extracted title/description/OG tags (confirmed the thesis)
- Searched independently: found Pinecone Nexus launch, Weaviate Engram, LangChain Context Hub — all shipping exactly the "knowledge layer for agents" concept
- Cross-referenced Pantheon Athenaeum (already had AGENTS.md compiler spec + ADR-001 matching the architecture)
- Result: validated the article's claims without accessing the full text

#### Multi-Angle Subagent Delegation

For large research tasks, **decompose the topic into 2-3 parallel angles** and delegate each to a subagent:

```python
# Example decomposition for "knowledge layer for agents" research:
tasks = [
  {"topic": "Industry shift — vector search demoted, knowledge layers emerging",
   "sources": ["Anthropic", "Google DeepMind", "venturebeat", "techcrunch"]},
  {"topic": "Practical architecture patterns — retrieval contracts, Stack ADRs, failure triage",
   "sources": ["LangChain blog", "LlamaIndex blog", "engineering blogs"]},
  {"topic": "Vendor perspectives — what Pinecone, Weaviate, Mem0 are saying",
   "sources": ["Pinecone blog", "Weaviate blog", "Mem0 docs"]}
]
```

Each subagent searches independently and returns findings. This covers more ground than a linear approach and surfaces conflicting perspectives.

**Pitfall — Subagent timeouts on web search:** Subagents that hit search engine blocks (Google/DuckDuckGo rate limiting) will time out. When this happens, fall back to **direct blog scraping of known sources** (vendor blogs, product pages, GitHub repos) using curl — skip the search engine altogether.

### Phase 1b: GitHub Repo Hunting (when looking for open-source projects to fork/use)

When the user asks "find me an open-source X we can fork," don't look at individual repos — **search the catalog first** using the GitHub search API:

```
# Broad search by category + tech stack
curl -s "https://api.github.com/search/repositories?q=android+music+player+kotlin+compose&sort=stars&order=desc&per_page=30"

# Filter out forks for clean candidates
curl -s "..." | jq '[.items[] | select(.fork == false) | {name, stars, language, description, license, updated, topics, url}]'
```

**Search strategy tips:**
- Combine feature keywords with tech stack: `"android+music+player+open+source"`, `"android+music+player+kotlin+compose"`
- Use `sort=stars&order=desc` to surface established projects first
- Set `per_page=30` — GitHub's max without pagination
- Filter out forks with `select(.fork == false)` — forked repos pollute results
- After finding candidates, get detail on each via individual repo endpoint for full metadata (license, created date, topics, description)
- Get recent commit activity to gauge maintenance: `.../commits?per_page=5`

**GitHub API repo reconnaissance patterns:**

1. **Branch-hopping for WIP features:** When a repo's default branch is stale, check feature branches — they often contain the real architecture:
    ```
    # List all branches to find active development
    curl -s "https://api.github.com/repos/owner/repo/branches" | jq -r '.[].name'

    # Read files from a specific branch
    curl -s "https://api.github.com/repos/owner/repo/contents/path/to/file?ref=feature-branch"
    curl -sL "https://raw.githubusercontent.com/owner/repo/feature-branch/path/to/file"
    ```

2. **Structural reconnaissance via /contents/ API:** Explore the directory tree as JSON without cloning:
    ```
    # List top-level directories
    curl -sH "Accept: application/vnd.github+json" "https://api.github.com/repos/owner/repo/contents/" | jq -r '.[] | select(.type == "dir") | .name'

    # Drill into a specific module
    curl -sH "Accept: application/vnd.github+json" "https://api.github.com/repos/owner/repo/contents/lib/modules" | jq -r '.[].name'

    # Check build system complexity
    curl -s "https://raw.githubusercontent.com/owner/repo/main/build.gradle.kts" | head -50
    ```
    Look for multi-module layouts — they indicate good separation of concerns and easier forking.

3. **Commit log health check:** Gauge maintenance cadence and bus factor:
    ```
    curl -s "https://api.github.com/repos/owner/repo/commits?per_page=5" | jq '.[] | {sha: .sha[0:8], message: .commit.message, date: .commit.author.date, author: .commit.author.name}'
    ```
    Warning signs: gaps >6 months between commits, single author for 100% of commits (bus factor = 1), messages that are all "chore" or "fix typo".

4. **Changelog analysis for fork readiness:** Read the latest release notes to detect maintenance mode, feature freeze, or licensing changes:
    ```
    curl -s "https://api.github.com/repos/owner/repo/releases/latest" | jq '{tag: .tag_name, name: .name, published: .published_at, body: .body}'
    ```
    A repo in "maintenance mode" (bug fixes only, no new features) is **ideal for a fork** — you inherit stability without fighting upstream feature churn.

5. **Architecture pattern matching from the repo tree:** Before committing to a fork, identify the pattern for extending the app. Look for:
    - Multi-module projects with separate source directories (e.g. `innertube/`, `kugou/`, `paxsenix/` alongside `app/`) — these show the project was designed to be extended
    - Standard build tooling (no NDK, no patched submodules, no custom cmake) — keeps fork maintenance low
    - Existing "import from URL" or "download for offline" features — the closer the existing architecture matches your target, the less you need to rebuild

### Phase 1c: Deep Repo Dive

- **Banner/hero sections** — the core positioning: "X is a [category] for [audience] that [value prop]"
- **Feature lists** — `<section>`, cards, grid layouts, comparison tables
- **Metrics/quotes** — numbers, benchmarks, customer results
- **Tags/pills** — what category they claim ("Knowledge Engine for agents", "serverless vector database")

For GitHub API responses, extract: `description`, `language`, `topics`, `stars`, `license`, `created_at`.

### Phase 3: Synthesis Structure

### Deep Repo Dive (for when you need full source access)

For projects where you need to understand internals — not just evaluate for forking — git clone beats API crawling:

```bash
# Clone the repo for full access
git clone https://github.com/owner/repo.git /tmp/repo-name

# Get the high-level topography FAST
find /tmp/repo-name -type f -name "*.md" | grep -i readme | sort     # find all READMEs
find /tmp/repo-name -type f -name "Cargo.toml" -o -name "package.json" -o -name "go.mod" 2>/dev/null  # find manifest files

# For Rust projects: Cargo.toml = module dependency graph
cat /tmp/repo-name/Cargo.toml                                        # full dependency list + feature flags
# For JS projects: package.json or workspace root
cat /tmp/repo-name/package.json | jq '.workspaces, .dependencies, .scripts'
```

**Systematic documentation drilling** — for well-structured projects with per-module READMEs:

1. Clone the repo
2. Find every README.md: `find /tmp/repo -type f -name "README.md" | sort`
3. Read them in **dependency order**:
   - Root README.md (project overview, what it is)
   - docs/architecture.md or gitbooks/ (full architecture)
   - Each module's README.md following the dependency graph (manifest lists module deps)
   - Deepest submodules last (these handle the fine-grained detail)
4. Each README tells you: what the module owns (Public surface), what it calls into (Calls into), what calls it (Called by), and how it's tested

**This pattern yielded immediate dividends on OpenHuman** — the 30+ per-module READMEs formed a complete architecture document that would have taken days to reconstruct from code alone. Cargo.toml showed the full dependency graph and feature flags in one place.

**When to clone vs API query:**
- **Clone:** Need architecture understanding, code structure, thorough documentation
- **API query (curl):** Quick reconnaissance — stars, recent commits, top-level README, license check
- **Clone + API:** Do both — clone for deep docs, API for social signals (star count, maintenance cadence, contributor health)

### Research Output Storage

After completing the analysis, persist it for future sessions:

1. **Write the full analysis** to the appropriate Codex in the Athenaeum:
   - `Codex-God-thoth/research/<project-name>-analysis.md` — general tech/product research
   - `Codex-<domain>/research/` for domain-specific research
   
2. **Include in the analysis document:**
   - One-sentence definition
   - Core idea/insight
   - Key components / subsystems
   - Architecture comparison (them vs. us)
   - Gap analysis with priority ranking
   - Files examined (for reproducibility)
   
3. **Write a session handoff** to the Codex's `memory.md` referencing:
   - Where the full analysis lives
   - Key findings (one paragraph)
   - Any open questions or next steps

4. **Notify the user** that research is complete with a pointer:
   ```bash
   god-notify <your-god-name> info "Research complete" "Analysis written to Codex-God-thoth/research/<project>-analysis.md"
   ```

5. **Update shared context** at `~/pantheon/shared/active/` for cross-session awareness.

### Phase 3: Synthesis Structure

Always output in this order:

1. **One-sentence definition** — what it *is* (not what it *does*)
2. **Core idea/insight** — the key architectural insight or design philosophy
3. **Key components** — bullet list of major subsystems/features
4. **Performance/evidence** — benchmarks, metrics (use a simple key:value list or bullets; NO pipe tables for Telegram)
5. **Architecture comparison table** — map their components to ours (if relevant):
   - Their thing | Our equivalent | Gap
6. **Availability** — is it released? Early access? Open source?

### Phase 4: Feasibility Assessment (if user asks "can we build this?")

### General: 4-Part Structure

1. **What's easy** — we already have the pieces
2. **What's hard** — gaps we'd need to build
3. **What's not worth it** — proprietary data, network effects, infra scale
4. **Recommended approach** — build a lean version vs. wait/watch

### Phase 4b: API-Product / MCP-Server Replication Assessment

When the product is an API, MCP server, or SaaS wrapper — i.e., a service that exposes tools/endpoints backed by underlying data sources — use this specialized variant. The question is always: *what's a thin proxy for a paid API vs. what's real proprietary value?*

### Phase 4c: Subscription / Pricing Comparison Analysis

When the user wants a cost comparison between coding plans, SaaS tiers, or model-access bundles, do **pricing analysis as a grounded sourcing task**, not a vibes summary.

#### Step 1: Separate the three pricing layers

For each option, identify which layer(s) apply:
- **Base subscription** — flat monthly or annual price
- **Included usage envelope** — credits, dollar-value caps, request limits, seat limits, or soft caps bundled in the plan
- **Overage / PAYG exposure** — token-based billing, optional balance fallback, soft throttles, or post-cap usage

A "$10 plan" and a "$20 plan" are not comparable unless you know whether they are hard-capped subscriptions, soft-capped bundles, or just entry points into metered billing.

#### Step 2: Pull vendor-first pricing anchors

Prefer direct vendor pricing/docs pages over affiliate blogs or Reddit summaries. Good source order:
1. Official pricing page
2. Official docs / help center / rate card
3. Official product page describing limits
4. Third-party summaries only as gap-fillers, never as the main anchor

Capture exact numbers when available:
- monthly price
- annual equivalent if relevant
- included limits (per 5h / week / month / credits / seats)
- whether overages exist
- whether the plan is free, hard-capped, soft-capped, or effectively uncapped but metered

#### Step 2b: Separate inference APIs from account / billing APIs

Do not assume that a product with documented model endpoints also exposes a documented way to inspect plan state.

Check these separately:
- **Inference API** — endpoints used to call models or list models
- **Account / billing API** — current subscription, remaining credits, cycle usage, invoices, balance, or hard-cap status
- **Console-only features** — settings like monthly limits, auto top-up, or "Use balance" that may exist only in the web app

Research rule:
- If you find model endpoints but no documented account endpoints, say exactly that. Do not imply there is a usable usage API just because the product has an API key and model routes.
- If the docs mention balance, limits, or billing controls without showing endpoints, treat that as evidence the web console likely knows the data, not evidence of a public API.
- If needed, propose inspecting the authenticated web app traffic to confirm whether there is an undocumented endpoint behind the console.

#### Step 3: Verify the user's live baseline before comparing

Before recommending a switch, inspect the live config or current setup so the analysis is grounded in reality:
- which provider is actually configured
- which models are active by default
- which subsystems also depend on that provider
- whether the current system already mixes multiple providers

A price comparison without the current baseline is fake precision.

#### Step 4: Check telemetry, but don't overclaim if telemetry is broken

If local state/usage DB exists, inspect the schema first and verify whether usable cost fields are populated before claiming actual spend.

Common pattern:
- Find the sessions table schema first
- Look for `actual_cost_usd`, `estimated_cost_usd`, or equivalent fields
- Verify whether values are non-zero and trustworthy
- If the DB logs zeros or missing cost data, say so explicitly and switch the analysis framing to **published plan ceilings + usage-pattern fit**, not "your real spend"

#### Step 5: Produce the recommendation in this order

1. Cheapest predictable option
2. Best value if current setup mostly works
3. Best low-risk trial option
4. High-performance but low-predictability option to avoid unless the user explicitly wants it

This matches Konan's preference for hard ceilings and cost predictability over open-ended usage optimism.

#### Step 6: Persist the pricing research

If the work involved multiple vendor pages, direct docs, and plan-specific quirks, add a short reference file under this skill's `references/` directory with:
- plan names
- direct source URLs
- exact prices and caps captured
- caveats about overages or ambiguous limits
- any telemetry limitations discovered locally

#### Step 1: Architecture Classification

Determine the architecture tier:

| Tier | Signature | Example |
|------|-----------|---------|
| **Thin Proxy** | Wraps upstream API with minimal/no logic. 2-3 source files. All "intelligence" lives on a backend server. | MyMedi-AI MCP (2 source files, all tools → HTTP POST to mymedi-ai.com) |
| **Hybrid** | Some local processing + some upstream API calls. Has its own DB/cache layer. | healthcare-mcp-public (wraps FDA/PubMed APIs directly but also does local DICOM parsing) |
| **Self-Contained** | Runs fully locally with embedded data. No external API dependency. | medical-terminologies-mcp (queries WHO/NIH public APIs directly, no middleman) |

**How to detect:** Clone the repo, count source files, check `package.json`/`pyproject.toml` for dependencies. If every tool handler is `fetch()` to a single base URL, it's a thin proxy.

#### Step 2: Tool-by-Tool Data Source Mapping

For each tool/endpoint the product exposes, catalog:

```
Tool: code_reimbursement
Price: $0.01
Endpoint: /agent/v1/codes/reimbursement
Parameters: {code}
Returns: RVU values, estimated CMS payment amounts
Real Backend: CMS PFS RVU 2026 (public domain, free CSV download)
Replicable: ✅ — free from CMS, no license needed
Difficulty: Easy
```

Sources to check for each tool:
- **Is the data government/public domain?** → CMS, CDC, FDA (openFDA), NIH (RxNorm), ClinicalTrials.gov, NPI Registry — all free, no API key needed
- **Is it a proprietary AI model?** → Clinical text → code suggestion, prior auth prediction, NER — requires ML
- **Is it a crosswalk/mapping?** → ICD-10↔CPT↔HCPCS mappings exist in CMS publications but are fragmented; proprietary curated crosswalks are common value-adds
- **Is it a payer-integration feature?** → Prior auth status checking requires payer partnerships (near-impossible without them)

#### Step 3: Open-Source Alternative Scan

For each category of tool, search for existing free/open-source MCP servers that already do the same thing:

```bash
# Search for existing MCP servers in the space
curl -s "https://api.github.com/search/repositories?q=mcp+healthcare+icd10&sort=stars&per_page=10"
# Check awesome lists
curl -sL "https://raw.githubusercontent.com/sunanhe/awesome-medical-mcp-servers/main/README.md"
# Search npm/PyPI for MCP packages
npm search mcp medical
```

Build a replacement map:

| Their Tool | Existing Free Alternative | Status |
|------------|--------------------------|--------|
| `code_lookup` | medical-terminologies-mcp (ICD-11), nlm-codes-mcp (ICD-10/HCPCS) | ✅ Full replacement |
| `drug_lookup` | healthcare-mcp-public, medical-mcp | ✅ Full replacement |
| `provider_search` | nlm-codes-mcp (NPI method) or direct NPPES API | ✅ Full replacement |

#### Step 4: Replication Phase Plan

Output a build plan with estimated effort per phase:

```
Phase 1: Fork the proxy scaffold (1 day) — take their MIT-licensed MCP infra
Phase 2: Government API wrappers (1 week) — 13/20 tools are just free API calls
Phase 3: Local code database (1-2 weeks) — ICD-10/HCPCS/CPT index
Phase 4: AI models (months, or use LLM) — code suggestion, NER, compliance audit
Phase 5: Payment layer (optional) — only needed if reselling
```

For each phase, note:
- **Effort:** hours/days/weeks
- **License constraints:** e.g., CPT codes are © AMA (can reference but can't redistribute), ICD-10-CM is public domain
- **Hard vs. easy:** what's a known solved problem vs. what needs original work

#### Step 5: The "Proprietary Tax" Breakdown

Show the user what they're actually paying for:

| Category | # Tools | Data Source | Cost if DIY |
|----------|---------|-------------|-------------|
| Government API wrappers | ~13 | Free APIs | $0 (just hosting) |
| AI models | ~5 | Proprietary ML | $XX/mo for API or self-hosted model |
| Crosswalk DB | ~1 | Licensed/curated | 1-4 weeks of data work |
| Payer integrations | ~1 | Business partnerships | Effectively non-replicable |

This makes the build-vs-buy decision transparent: a huge chunk of the "value" is just marking up free government data.

#### Step 6: Save the Analysis

1. Write full report to `Codex-God-thoth/research/<product>-replication-analysis.md`
2. Add a reference file under the skill: `skill_view(name="product-technology-research", file_path="references/<product>-replication-YYYY-MM.md")`
3. Include in the reference: tool catalog, data source mapping, alternative scan, phase plan
4. Update shared context at `~/pantheon/shared/active/`

## Pitfalls

- **Don't trust the homepage alone** — it's marketing. Cross-reference with docs and GitHub
- **Raw HTML is huge** — pipe to `head -200` or `grep` for early cuts. Don't dump 200k chars of JS framework garbage
- **404 pages are informative too** — a 404 on a blog post URL might mean the thing hasn't launched yet
- **Rate limiting** — GitHub API is 60 req/hr unauthenticated. Batch calls or use `?per_page=1` for minimal responses
- **No web_search tool** — accept this constraint and use direct curl + heuristic URL patterns
- **Page is client-side rendered (Next.js)** — you'll get JS not content. Look for `<script id="__NEXT_DATA__"` or `<!--$!-->` SSR bailout markers. If it's client-only, try the `/md/` alternate endpoint (Pinecone blog supports this pattern)
- **JSON within script tags** — many modern sites embed data as JSON in `<script type="application/json">` or `__NEXT_DATA__`. Extract with: `grep -oP '"description":"[^"]*"'` or similar patterns
- **Route claims markdown but returns site shell** — some static-site routes return `Content-Type: text/markdown` while still serving the global HTML shell or truncated rendered output. If the page content looks wrong, do not trust the route just because the header says markdown. Cross-check with `web_extract`, inspect the raw body, and fall back to official vendor pricing/docs pages for the specific services being compared.
- **Broken local cost telemetry** — a local DB can have cost columns that exist but are all zero. Check both schema and real values before using telemetry as evidence. If costs are zeroed, say the local telemetry is not sufficient for an audited spend report.

### Ecosystem List Processing

When the user shares an awesome list, curated directory, ecosystem roundup, or "what's out there" link:

1. **Get the full content** — clone if GitHub, extract full page if web (not just the summary). Awesome lists often truncate in web_extract
2. **Fast-scan all entries** — skim descriptions with focus on:
   - Direct relevance to current Pantheon needs
   - Pattern matches with recent discussions this session
   - Maturity tags: production > beta > experimental
3. **Identify top candidates** — pick 3-5 for deeper inspection, not 20. Signal-to-noise ratio matters
4. **Deep dive on each** — clone source code, read implementation, assess architectural fit
5. **Cross-reference against existing stack** — don't recommend building what we already have. Be explicit: "already covered" vs "genuinely new"
6. **Rank by actionability** — P0: install today, P1: prototype this week, P2: keep on radar, ❌: skip
7. **Check for our own projects** — awesome lists are the canonical directory. If Pantheon isn't listed and should be, note it as an opportunity

**Pitfall — Maturity inflation:** A "production" tag on an awesome list only means the list author considers it stable. Check real signals: recent commits, open issues, user count. A project with "production" tag and 1 commit is still experimental.

**Pitfall — Scope creep:** Awesome lists tempt you to evaluate everything. Stick to the 3-5 that are most relevant to the conversation arc. Note the rest for later if the user asks.

### Phase 5: Live CLI Tool Benchmarking (for performance-claim tools)

When a tool claims performance improvements (token compression, speed gains, memory savings):

1. **Install in the test environment** — binary, pip package, whatever the real install path is
2. **Run on Pantheon's actual workloads** — not synthetic benchmarks from the README. Use our repos, our git history, our dir structures
3. **Measure raw vs processed side-by-side** — capture:
   - Output size in bytes (before and after)
   - Execution time overhead
   - Format quality — is the compressed output *better* or just smaller?
4. **Identify where it doesn't help** — every tool has blind spots. Document them honestly (e.g. `git log --oneline` and `find` showed 0% savings with RTK)
5. **Assess integration cost** — how hard to wire into our stack? Plugin hook? Config change? Environment variable?
6. **Fail-open verification** — does the tool crash silently? Does the fallback path work? (This is a dealbreaker for production tools)

**Example from May 2026 RTK benchmark on Pantheon codebase:**

| Command | Raw | RTK | Savings | Notes |
|---------|-----|-----|---------|-------|
| `git diff` | 60,078B | 24,407B | 59% | Also reformats output to be more readable |
| `ls -la ~/pantheon` | 2,736B | 763B | 72% | Strips noise from directory listings |
| `ls -la /usr/bin` | 92,882B | 32,030B | 65% | Large dirs see biggest gains |
| `git status` | 723B | 369B | 48% | Cleaner output format |
| `git log --oneline` | 1,290B | 1,290B | 0% | Already minimal format |
| `find` | 674B | 902B | -34% | RTK format less compact here |

The `git diff` case is the killer — RTK adds a `--stat` summary before the changes and compacts diff output. The model gets a *better* view of what changed in *fewer* tokens.

### Phase 5b: Live Smoke Test (when the product has a downloadable app)

Before committing to a fork, **confirm the app actually works** on the user's device. Release notes and READMEs lie — the app in your hand doesn't.

```
# Get the latest APK download URL from the releases page
curl -s "https://api.github.com/repos/owner/repo/releases/latest" | jq '.assets[] | select(.name | endswith(".apk")) | .browser_download_url'
```

Ask the user to download, install, and test the critical path (playback, import, offline, Android Auto if applicable). If the app throws errors out of the box (e.g. 401 from a third-party API), that's a strong signal the plugin/source architecture is fragile.

## Fork Candidate Comparison Table

When the user wants to fork an OSS project, always produce a structured comparison after Phase 1b:

| Candidate | Stars | Compose? | Key Feature Match | Build Complexity | Community Health |
|---|---|---|---|---|---|
| Repo A | N | ✅/❌ | What aligns | Low/Med/High | Active/Stale |
| Repo B | ... |

Also include in the analysis:
- **What stays untouched** — existing features we keep
- **What we extend** — modifications to existing modules
- **What we add** — new modules/screens/services
- **Upstream posture** — is the parent in maintenance mode? (If yes, that's *good* for a fork — stable but feature-frozen means fewer conflicts)
- **License compatibility** — GPL-3.0 means your fork must also be GPL

Reference example: See `references/sono-player-fork-metrolist-2026-05.md` for a worked example comparing Auxio, Symphony, Metrolist, Spotube, and umihi-music.

### Phase 6: Concept Absorption Pipeline

When the goal isn't "should we adopt this whole product" but "what individual ideas/mechanisms should we steal and in what order" — this phase extracts the signal from the noise and builds a ranked adoption plan.

**Use when:** The user says "check out this project" or "what do you think of X" and the natural next question is "should we do something like that?"

#### Step 1: Concept Extraction

For each major mechanism in the target project, capture:

1. **What it does** — the core mechanism, not the marketing
2. **How it works** — the architectural pattern (what makes it tick)
3. **Why it matters** — the problem it solves that we might also have

Example from HyMem:
> **Decay mechanism:** Laplace-smoothed confidence = (pos+1)/(pos+neg+2). Facts that get contradicted or fall dormant decay and auto-retract below 0.15 threshold. Solves: stale facts persist forever in our flat list-based memory.

#### Step 2: Gap Analysis (Us vs. Them)

Map each concept against what you already have. Be honest about what's truly missing:

| Concept | We Have It? | How We Do It | Their Approach | Gap |
|---|---|---|---|---|
| Decay/eviction | No | Error when over limit | Auto-prune by confidence | We need this |
| Evidence weighting | Partial | Exact duplicate detection | Counter-based reinforcement | Simple upgrade |
| Type system | No | Freeform prose | Locked-vocabulary markers | Nice to have |

**No pipe tables in Telegram output** — use bullet lists or labeled key:value pairs.

#### Step 3: Priority Ranking

Score each gap on three axes:

- **Effort** — Lo (hours), Med (days), Hi (weeks)
- **Impact** — does this unblock something, improve quality of life, or just look cool?
- **Urgency** — is there a concrete pain point *right now* without it?
- **Dependencies** — does this concept require another concept to be built first?

Then rank. A common pattern:
- **P0:** High urgency + low effort (painkiller, ship today)
- **P1:** High impact + low effort (force multiplier, ship this week)
- **P2:** Medium impact, no dependencies (nice polish)
- **P3:** High impact + high effort + lots of dependencies (ambitious, needs foundation)

#### Step 4: Go / Steal / Wait Decision Per Concept

For each extracted concept, decide one of:

- **Go** — build it directly, right away (P0)
- **Steal** — adopt the idea via a simplified version adapted to existing infra (P1-P2)
- **Wait** — the project is too young, needs a license, or the concept only pays off at scale (P3 or defer)
- **Skip** — doesn't solve a real problem for us

Document why — especially for "Wait" decisions, so future sessions don't re-litigate.

#### Step 5: Implementation Roadmap

Output a short build order that respects dependencies:

```
Now ──→ P0: Concept A   (solves immediate pain)
 │
 ├──→ P1: Concept B      (makes P0 smarter, enables P2)
 │
 └──→ P2/P3: Concepts C, D  (big builds, need foundation)
 ↓
Done
```

**Pitfall — Don't confuse "concept adoption" with "code import."** The value is in understanding *why* something works and adapting it to your architecture, not in copy-pasting someone else's implementation. A 30-line eviction function is more valuable than importing a 3,200-line memory engine that does 15 things you don't need.

**Pitfall — Young projects have no track record.** A project created 5 days ago with 0 stars and no license might have great ideas embedded in well-written code, but it's unproven. Extract the concepts, not the code. Revisit in a month if the project survives.

Reference example: See `references/hymem-concept-absorption-2026-05.md` for a worked example of this pipeline applied to the HyMem project.

## Post-Research: Session Output & Persistence

### Research Output Storage

After completing the analysis, persist it for future sessions:

1. **Write the full analysis** to the appropriate Codex in the Athenaeum:
   - `Codex-God-thoth/research/<project-name>-analysis.md` — general tech/product research
   - `Codex-<domain>/research/` for domain-specific research

2. **Include in the analysis document:**
   - One-sentence definition
   - Core idea/insight
   - Key components / subsystems
   - Architecture comparison (them vs. us)
   - Gap analysis with priority ranking
   - Files examined (for reproducibility)

3. **Write a session handoff** to the Codex's `memory.md` referencing:
   - Where the full analysis lives
   - Key findings (one paragraph)
   - Any open questions or next steps

4. **Notify the user** that research is complete with a pointer:
   ```bash
   god-notify <your-god-name> info "Research complete" "Analysis written to Codex-God-thoth/research/<project>-analysis.md"
   ```

5. **Update shared context** at `~/pantheon/shared/active/` for cross-session awareness.

## Reference Files in This Skill

These contain session-specific detail and condensed research from past deep-dives:

| File | Covers |
|------|--------|
| `references/pinecone-nexus-2026.md` | Pinecone Nexus Knowledge Engine architecture, Context Compiler, KnowQL, KRAFTBench |
| `references/agent-knowledge-layer-industry-shift-2026.md` | Industry-wide shift from vector-search-alone to Knowledge Layer for agents (Weaviate Engram, LangChain, Mem0, Pantheon mapping) |
| `references/hymem-concept-absorption-2026-05.md` | HyMem concept extraction — decay mechanisms, evidence weighting, type systems |
| `references/sono-player-fork-eval-2026-05.md` | Fork candidate evaluation (Auxio, Symphony, Metrolist, Spotube, umihi-music) |
| `references/openhuman-architecture-2026-05.md` | OpenHuman architecture exploration |
| `references/youtube-creator-investigation.md` | Reverse-engineering YouTube creator setups — link resolution, GitHub hunting, business model classification |
| `references/mymedi-ai-replication-2026-05.md` | SaaS/MCP-server replication assessment — thin proxy detection, tool-by-tool data source mapping, open-source alternative scan, phase plan for building a clone |
| `references/coding-plan-pricing-anchors-2026-05.md` | Coding-plan cost analysis anchors — OpenCode Go, Gemini Code Assist, Mistral, and OpenAI Codex pricing/cap notes plus telemetry caveats |
| `references/opencode-aggregators-and-account-api-2026-05.md` | OpenCode Go/Zen vs router-style aggregator notes, plus the key distinction between documented model APIs and undocumented account/billing APIs |
| `references/rtk-hermes-benchmark-2026-05.md` | RTK Rust Token Killer — installation, pre_tool_call hook architecture, benchmarks on Pantheon codebase (48-72% savings on common commands), integration caveats |
| `references/openhuman-memory-system-internals-2026-05.md` | OpenHuman memory retrieval internals — zero-LLM hybrid scoring (FTS5 + brute-force cosine + graph traversal), heuristic event extraction, subconscious engine, safety layer, SQLite-backed vector store |

Load any reference with: `skill_view(name="product-technology-research", file_path="references/<file>")`

## Verification

Before reporting, ask yourself:
- Did I find the actual *mechanism* (how it works) or just the *marketing* (what it claims)?
- Can I map at least one component to something in our stack?
- Do I know the licensing/pricing model?
- If it's open source, did I check the repo?