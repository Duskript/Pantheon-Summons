---
name: thoth-deep-research
description: "Structured deep research for Thoth — auto-generate outline, parallel deep-dive via delegate_task, synthesize markdown report. No human-in-the-loop gates."
version: 1.1.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [research, thoth, deep-dive, delegate, report, comparison, pricing]
    related_skills: [product-technology-research]
---

# Thoth Deep Research

## ⚠️ CRITICAL: Load This Skill Before Starting Any Research

**Before you begin ANY research session, call `skill_view('thoth-deep-research')`.**
- Check the available reference files in `references/` — they may contain prior work on the same topic
- Check for the correct pattern below (Pattern A/F/B/D/Naming) — using the wrong pattern produces wrong output
- If the user's request matches Pattern F (cross-provider synthesis), do NOT fall back to Pattern A (open-ended deep dive) — they produce fundamentally different outputs

This skill was created because the alternative is unstructured rabbit holes. Reading it first is not optional — it's the step that makes the output useful.

Autonomous structured research workflow — generate an outline, dive deep with parallel subagents, and synthesize a report. No hand-holding, no confirmation gates. Thoth sees a topic and *goes*.

## When to Use

- User asks "research [topic]" or "deep dive into [topic]"
- User says "I want to know everything about [subject]"
- User mentions a broad topic that needs systematic investigation
- You have a curiosity rabbit hole that needs structure
- Any research task that would benefit from parallel investigation
- **User asks to compare N providers/plans on cost, features, or usage** → use Pattern B (Comparative Research)
- **User asks to research/investigate an API, data source, or external tool** → use Pattern D (Infrastructure Research)

## Don't Use For

- Single quick questions (just answer directly)
- Topics needing live data from specific APIs (use Pattern D if the API needs discovery/testing, or route to Caduceus for medical APIs)
- Personal/private research the user hasn't explicitly asked for

## Prerequisites

### Research Tooling

This skill uses lightweight tools for source retrieval. **Firecrawl is NOT available on this system** — it was evaluated and cannot run on the current hardware/network. The tools below are the lightweight alternatives that work reliably:

| Tool | Role | How |
|------|------|-----|
| **`web_search`** | Primary discovery | Search engine queries |
| **`web_extract`** | Page/PDF → markdown | Standard HTTP extraction |
| **`curl` via terminal** | API-based extraction | arxiv, Semantic Scholar, GitHub APIs |
| **Arxiv API** | Academic paper search | Free REST, no key needed, Atom XML |
| **Semantic Scholar API** | Citations + recommendations | 1 req/sec free, JSON responses |
| **Blogwatcher** | RSS/Atom feed monitoring | Go binary, lightweight, local DB |

No heavy dependencies, no browser automation, no Playwright required.

---

## Workflow Pattern Selection

Two distinct patterns live under this skill. Pick the one that matches the request:

| Pattern | Best For | Method |
|---|---|---|
| **Open-Ended Deep Dive** (Original) | Exploring a broad topic, understanding a category | outline + delegate_task parallel agents |
| **Comparative Research** (v1.1) | Side-by-side comparison of N items across defined dimensions | sequential search → extract → compile → rank |
| **Infrastructure Research** (v1.2) | API discovery, endpoint testing, tool evaluation, skill building | sequential: discover → test → document → skill-author |
| **Naming Research** (v1.3) | Business/product naming with domain + conflict checking | iterative: brainstorm → filter → DNS check → conflict check → recommend |

## Companion Tools & Integrations

These tools work alongside this skill for ongoing research coverage:

| Tool | Role | Location |
|------|------|----------|
| **Blogwatcher** | RSS feed monitoring | `~/.local/bin/blogwatcher-cli` — arXiv cs.AI, cs.CL, cs.LG, HN, Lilian Weng |
| **Arxiv skill** | Academic paper search + citation graph | `~/.hermes/skills/thoth/arxiv/` |
| **llm-wiki** | Durable knowledge persistence | `~/wiki/` with SCHEMA.md + entities/ + concepts/ |
| **product-technology-research** | External product/company analysis | Companion skill in thoth category |

**Wiki ingest rule:** After every Pattern A or B research session, extract durable knowledge (entities, concepts, comparisons) into `~/wiki/`. This compounds over time — future research sessions start by checking the wiki first, avoiding re-discovery.

**Feed scanning:** Before starting a research session on a time-sensitive topic, run `blogwatcher-cli scan` to check if relevant articles have appeared since the last scan.

---

## Pattern A: Open-Ended Deep Dive

The original pattern — define items and fields upfront, explore in parallel.

### Phase 1: Outline Generation

**Goal:** Generate `outline.yaml` (items to research) and `fields.yaml` (what attributes to capture for each item).

1. **Initial framework** — based on your knowledge of the topic, generate:
   - A list of **items** (specific objects to research — products, papers, people, technologies, etc.)
   - A **field framework** — categories of information to collect for each item

2. **Web search supplement** — search the web to:
   - Verify no major items are missing
   - Find additional items within the topic
   - Add or refine field categories based on what's relevant
   - Auto-detect a reasonable time range (no asking)

3. **Save outline files** to the research directory:

   Path: `~/athenaeum/Codex-God-thoth/research/{topic-slug}/`

   **`outline.yaml`:**
   ```yaml
   topic: "Research Topic Name"
   created: "2026-05-16"
   items:
     - name: "Item Name"
       category: "Category"
       description: "Brief description"
   batch_size: 3  # items per delegate_task agent
   output_dir: "results"
   ```

   **`fields.yaml`:**
   ```yaml
   categories:
     - name: "Basic Info"
       fields:
         - name: "Company"
           description: "Company that developed it"
           detail_level: "brief"
         - name: "Release Date"
           description: "When it was released"
           detail_level: "brief"
     - name: "Technical Features"
       fields:
         - name: "Architecture"
           description: "Technical architecture and design"
           detail_level: "detailed"
   ```

   **`detail_level` hierarchy:** `brief` → `moderate` → `detailed`

### Phase 2: Deep Research

**Goal:** Research every item in parallel using `delegate_task` subagents.

1. **Read** `outline.yaml` to get items list, batch_size, and output_dir
2. **Group items** into batches of `batch_size`
3. **Launch one `delegate_task` per batch** — all run concurrently:

   ```
   Goal: "Research these [N] items using web_search. For each item, output structured JSON matching the field definitions."
   Context: The full outline.yaml, fields.yaml, item details, output paths
   Toolsets: ["web", "file", "terminal"]
   ```

4. Each subagent:
   - Gets assigned its batch of items + the fields definitions
   - Uses `web_search` and `web_extract` to research each item
   - For each item, writes a JSON file to `{output_dir}/{item-slug}.json` with field values
   - Marks uncertain values with `[uncertain]`
   - Includes an `uncertain` array listing fields whose values are uncertain

5. **Verify results** — after all subagents return, check:
   - **Every item** in `outline.yaml` has a corresponding `.json` file in the output directory
   - **Every JSON file is valid** — parse each with `json.loads()` in a try/except. If any file has malformed JSON (common: JS object-literal syntax `{key, value}` instead of proper key-value pairs), repair and re-validate before proceeding
   - **Every JSON file has meaningful content** — no files that are empty, contain only `{}`, or consist entirely of `[uncertain]` values
   - Any items with all-uncertain fields need a retry (spawn a focused single-item re-research)

### Phase 3: Report Synthesis

**Goal:** Turn JSON results into a readable markdown report.

1. **Read all JSON files** from the output directory
2. **Read `fields.yaml`** to understand the field structure
3. **Generate a report** using the report generator approach below

Use `execute_code` with a Python script to generate the report. Template:

```python
import json, yaml, os, sys
from pathlib import Path

topic = "{topic_slug}"
base_dir = Path("~/athenaeum/Codex-God-thoth/research") / topic
results_dir = base_dir / "results"
fields_path = base_dir / "fields.yaml"

# Load field definitions
with open(fields_path) as f:
    fields_config = yaml.safe_load(f)

# ── Defensive accessors (handle inconsistent subagent key naming) ──
def gv(data, *keys, default="—"):
    """Gracefully dig into nested dicts, returning default at any missing level."""
    d = data
    for k in keys:
        if isinstance(d, dict):
            d = d.get(k, default)
        else:
            return default
    return d if d is not None else default

def dig(data, *path):
    """Same as gv but returns empty dict instead of string default (for nested traversal)."""
    d = data
    for key in path:
        if isinstance(d, dict):
            d = d.get(key, {})
        else:
            return {}
    return d

def flatten_val(v):
    """Safely coerce a value to string regardless of type."""
    if isinstance(v, str):
        return v
    elif isinstance(v, list):
        items = [str(x) for x in v[:5]]
        return ", ".join(items) + ("..." if len(v) > 5 else "")
    elif isinstance(v, dict):
        for preferred in ("description", "summary", "value"):
            if preferred in v:
                return str(v[preferred])
        return str(v)[:200]
    return str(v) if v is not None else "—"
# ──────────────────────────────────────────────────────────────────

# Load all result JSONs (skip unparseable, log them)
results = []
for f in sorted(results_dir.glob("*.json")):
    try:
        with open(f) as fh:
            data = json.load(fh)
        results.append(data)
    except json.JSONDecodeError as e:
        print(f"⚠️  MALFORMED JSON in {f.name}: {e}. Repair before rerunning synthesis.")

# Generate report sections
sections = []

for category in fields_config.get("categories", []):
    cat_name = category["name"]
    cat_key = cat_name.lower().replace(" ", "_")
    section = f"## {cat_name}\n\n"
    for result in results:
        item_name = result.get("name") or result.get("item") or result.get("title") or result.get("item_name", "Unknown")
        section += f"### {item_name}\n\n"
        for field_def in category.get("fields", []):
            field_name = field_def["name"]
            field_key = field_name.lower().replace(" ", "_")

            # Try multiple key resolution strategies
            val = result.get(field_name, None)
            if val is None:
                val = result.get(field_key, None)
            if val is None and cat_key in result:
                nested = result[cat_key]
                val = nested.get(field_name, nested.get(field_key, None))
            for alt_key in list(result.keys()):
                if alt_key.endswith(cat_key) and isinstance(result[alt_key], dict):
                    val = result[alt_key].get(field_name, result[alt_key].get(field_key, None))
                    if val is not None:
                        break
            if val is None:
                val = "—"
            if isinstance(val, str) and val.lower() in ("[uncertain]", "n/a", "unknown", "—"):
                val = "—"
            section += f"- **{field_name}:** {flatten_val(val)}\n"
        section += "\n"
    sections.append(section)

# TOC
toc_lines = ["# Research Report: {topic}\n\n", "## Table of Contents\n\n"]
for i, result in enumerate(results, 1):
    name = result.get("name") or result.get("item") or result.get("item_name", f"Item {i}")
    toc_lines.append(f"{i}. [{name}](#{name.lower().replace(' ', '-')})\n")

report = "".join(toc_lines) + "\n" + "\n".join(sections)

# Write report
report_path = base_dir / "report.md"
with open(report_path, "w") as f:
    f.write(report)

print(f"Report written to {report_path}")
```

4. **Save** the report to `~/athenaeum/Codex-God-thoth/research/{topic-slug}/report.md`

### Phase 4: Wiki Ingest (Durable Knowledge)

**Goal:** Extract durable knowledge from the research into `~/wiki/` so it compounds.

1. **Identify what's worth keeping** — entities (products, companies, frameworks), concepts (techniques, patterns, ideas), and comparisons that would be valuable in future sessions.
2. **Check `~/wiki/index.md`** — see what already exists before creating anything new.
3. **Create or update wiki pages:**
   - **New entities:** Create in `~/wiki/entities/{slug}.md` with YAML frontmatter, wikilinks, source references.
   - **New concepts:** Create in `~/wiki/concepts/{slug}.md` with definition, key points, related concepts.
   - **Comparisons:** If the research was a side-by-side comparison, write to `~/wiki/comparisons/{slug}.md`.
4. **Update `~/wiki/index.md`** — add new pages to the correct section.
5. **Update `~/wiki/log.md`** — append entry: `## [YYYY-MM-DD] ingest | {topic} — {N} entities, {N} concepts`.

Skip wiki ingest for quick fact-finds (Pattern C) — only Pattern A and B produce enough depth to warrant wiki entries.

5. **Notify** the user with a summary:
   - Topic researched
   - Number of items covered
   - Key findings (top 2-3 most interesting)
   - Link to report location
   - Any items with significant uncertain data

---

## Pattern D: Infrastructure/Tool-Building Research

For investigating external data sources, APIs, tools, or services to understand how they work, test their interfaces, and package the findings as a reusable workflow or skill. This pattern's output is not a research report — it's a **reference document**, **pipeline script**, or **skill** that a god (or the user) can use again.

### When to Use This Pattern

- User asks "can we integrate [API/data source] into [system]?"
- You need to discover how an external tool or API works before using it in research
- Goal is to produce a reusable reference, not a one-time finding
- Multiple candidate sources need discovery and evaluation (which APIs are free? which work? which have useful data?)
- The research output will become infrastructure: a skill, reference document, MCP server wire-up, or pipeline script

### Don't Use For

- Finding information about a product or company (use Pattern A)
- Comparing similar providers (use Pattern B)
- Quick answers to narrow questions (use Pattern C)
- Topics where the output is a finding, not a tool/workflow

### Methodology

#### Phase 1: Source Discovery

**Goal:** Identify what APIs, data sources, or tools exist in the domain. Don't test yet — just find.

1. **Search broadly** — `web_search("[domain] API free no key" "REST API" "[domain] data source")`
2. **Compile a candidate list** — Source name, base URL, what it provides, auth requirements
3. **Prioritize** — Free > paid. No key > API key. REST > SDK. Well-documented > obscure. Most useful data first.

**Phase 1 output:** A ranked list of candidates with basic metadata.

#### Phase 2: API Discovery & Authentication

**Goal:** For each high-priority candidate, read the docs and understand how to call it.

1. **Find the official documentation** — `web_extract(source_url)` or search for API docs
2. **Document the basics:**
   - Base URL
   - Authentication (key in header? query param? OAuth? none?)
   - Rate limits
   - Request format (JSON? XML? form-encoded?)
   - Response format
3. **Identify key endpoints** — What are the most useful queries? What fields do they return?
4. **Note any gotchas** — Discontinued features (like RxNorm's DDI API), version differences, format quirks

#### Phase 3: Live Testing

**Goal:** Verify every assertion from Phase 2 with actual curl commands. This is the most important phase — docs lie, APIs drift.

1. **Test authentication** — Call the simplest endpoint first (status, search, or version)
2. **Test each key endpoint** — Write a curl command that exercises the endpoint with a real-world query
3. **Test edge cases** — Empty results, pagination (first page + second page), error responses, rate limiting
4. **Verify response parsing** — Pipe the JSON/XML response through Python to extract useful fields
5. **Document the working commands** — Save the exact curl commands that worked into the output
6. **Flag things that didn't work** — A failing endpoint that the docs claim should work is an important finding. Document why it failed and move on.

**Phase 3 output:** A collection of verified curl commands for every useful endpoint, plus notes on what didn't work.

#### Phase 4: Workflow Documentation

**Goal:** Package the verified commands into reusable workflows that a god can follow.

1. **Organize by use case** — "Full Drug Profile" pipeline: get RXCUI → get label → get adverse events → search clinical trials → check literature
2. **Write pipeline scripts** — Shell scripts or Python pipelines that chain multiple API calls together
3. **Document field mappings** — What do the API fields mean? Which ones are most useful? Any `openfda.*`-style harmonized fields?
4. **Add evidence notes** — Rate limits that were actually observed, endpoints that returned empty despite docs, workarounds discovered

#### Phase 5: Skill Authoring

**Goal:** If the research produced durable workflows, package them as a skill for the relevant god.

1. Create the skill at `~/athenaeum/Codex-God-{god}/skills/{skill-name}/SKILL.md`
2. Include a quick-reference table of all sources
3. Write individual reference files under `references/` (one per source): endpoint tables, exact curl commands, field documentation
4. Include pipeline scripts and workflow descriptions
5. Write handoff to the god's memory.md so they know the skill exists

### Diff vs Pattern A (Exploratory Deep Dive)

| Dimension | Pattern A | Pattern D |
|-----------|-----------|-----------|
| **Objects** | Products, companies, people, papers | APIs, data sources, tools |
| **Output** | Structured research report | Reusable skill + reference files |
| **Method** | delegate_task parallel sub-agents | Sequential: discover → test → document |
| **Testing** | None (read existing content) | Live curl commands against endpoints |
| **Target** | A finding for the user | Infrastructure for a god |
| **Success** | "I know what this is" | "I can query this source reliably" |

### Worked Example: Medical Data Pipeline (Caduceus Pass 2)

Phase 1: Searched for "medical API free no key" → found OpenFDA, RxNorm, ClinicalTrials.gov, DailyMed, PubMed, ICD-10 NIH

Phase 2: Read docs for each — documented base URLs, auth (all free, no keys), rate limits, key endpoints

Phase 3: Tested each with curl:
- OpenFDA ✅ drug/label, drug/event, drug/enforcement all returning data
- RxNorm ✅ rxcui, drugs, rxclass, displaynames all working
- ClinicalTrials.gov ✅ studies search, AREA syntax, pagination
- PubMed E-utilities ✅ esearch, esummary, efetch all working
- DailyMed ✅ drugnames, ndcs working
- ICD-10 NIH Clinical Tables ❌ returned empty — documented alternative

Key finding: RxNorm DDI API discontinued Jan 2024 — documented with alternatives

Phase 4: Wrote drug profile pipeline, condition research pipeline, interaction screening script

Phase 5: Authored `medical-data-retrieval` skill with 7 reference files (25KB total) for Caduceus
# Hermes Memory Provider Architectural Synthesis — 2026-05-20
## Worked example: Pattern F (Cross-Provider Architectural Synthesis)

**⚠️ IMPORTANT UPDATE:** This research was done without Phase 0 (Infrastructure Audit). Subsequent investigation revealed that most of the "Hydra" design already exists under the Ichor/Crucible umbrella (Tier A extraction, FTS5, Hybrid Scorer, Memory Trait Contract, query-less Ichor Brief, Subconscious Engine, Ichor Gates plugin). Future work on this topic should START by auditing `~/pantheon/lib/*.py`, `~/.hermes/plugins/`, and `~/pantheon/pantheon-core/mcp_server.py` before proposing new components. See the full audit in `~/athenaeum/Codex-God-thoth/research/hermes-memory-provider-architecture/report.md` Section 4 for what already exists vs. what was proposed.

For researching multiple providers, systems, or architectures side-by-side and synthesizing a **hybrid design** that combines the best concepts from each. This is NOT a flat comparison — it's architectural pattern extraction + cross-cutting analysis + design synthesis. The output is a distilled knowledge base + implementation roadmap.

### When to Use This Pattern

- User asks "research [N providers] and figure out how we could incorporate their ideas"
- User asks "architectural deep-dive of [vendors/systems/approaches]"
- User says "I want to pull the best features from all of these into [our system]"
- The research goal is not just "what exists" but "what should we build"
- Cross-provider synthesis — extracting *mechanisms*, not just features
- User provides 3+ sources/vendors and wants to understand trade-offs through the lens of building our own

### Don't Use For

- Straight comparison with a clear winner (use Pattern B)
- Exploring a single product/project (use Pattern A or product-technology-research)
- Quick list of "which is cheapest" (use Pattern B with cost-focused dimensions)
- Topics where the output is a recommendation *from* the list, not a design *from* patterns

### Methodology

#### Phase 0: Infrastructure Audit

**Goal:** Before researching any provider, check what the user has **already built** in this domain. Without this step, you will design from scratch what already exists — wasting the session and frustrating the user.

1. **Audit config:** Check `~/.hermes/config.yaml` for `memory.provider`, `plugins.enabled`, and any custom config sections. These tell you what's already active.

2. **Audit plugins:** Check `~/.hermes/plugins/` for directories with `__init__.py` + `plugin.yaml`. These are already-built memory providers, gate harnesses, or middleware. Read the source.

3. **Audit library code:** Check `~/pantheon/lib/` for Python modules — especially anything with `ichor_`, `memory_`, `hybrid_`, `tier_`, `forge_`, `gate_` prefixes. Read the headers and class/function signatures.

4. **Audit MCP tools:** Check `~/pantheon/pantheon-core/mcp_server.py` for registered tool functions (search for `# Tool:` comments). These are the public API of what's already built.

5. **Audit state:** Check `~/.hermes/memories/MEMORY.md` and `USER.md` for mentions of existing systems. Check for `ichor.db`, `graph.db`, `chroma/` in `~/.hermes/`.

6. **Audit shared context:** Check `~/pantheon/shared/` for DIGEST.md and decisions/ — these contain running records of what's been built and what's broken.

7. **Audit your own Codex:** Check `~/athenaeum/Codex-God-thoth/research/` for prior research on the same or overlapping topics. Check `~/athenaeum/Codex-Pantheon/` for system documentation and PRDs.

8. **Audit session search:** Run `session_search("recent memory system changes OR built OR deployed")` to catch recent work that may not be in file-based logs.

9. **Compile the "what's already here" list** before you start researching external providers. Keep it visible — refer back to it during Phase 3 to avoid re-proposing what already exists.

**Phase 0 output:** A document (or section of your working notes) listing every existing component, what it does, and whether it's live or needs activation. This is your ground truth for the rest of the analysis.

### Phase 1: Per-Provider Architectural Deep Dive

**Goal:** For each provider/system, produce a structured architectural breakdown. Do NOT flatten into a table yet — each provider gets its own analysis section.

For each provider, capture:

```
### 1.N Provider Name — [One-line: what it does best]

**What it does:** [1-2 sentence description of the product/system]

**Architecture:** [ASCII/description of the system architecture — how data flows, what the components are]

**Core mechanisms:** [Table or bullet list of the key operational mechanisms]

| Mechanism | What It Does | Cost/Complexity |
|-----------|-------------|-----------------|
| ...       | ...         | ...             |

**Key design decisions:** [Bullet list of the architectural choices that make this system different]

**What to steal:** [What pattern/concept from this provider belongs in our system]
```

**Phase 1 steps:**
1. **Initial identification** — list all providers/systems to research. Verify coverage with web_search.
2. **Per-provider source acquisition** — for each provider, pull 2-3 sources: official docs, architecture blogs, source code (if open), GitHub. Use `web_extract`, `curl`, and repo cloning as appropriate.
3. **Architecture extraction** — identify how the system actually works (not just marketing claims). Look for:
   - **Core mechanisms** — what makes it tick (the operational patterns)
   - **Key design decisions** — trade-offs the architects chose (why not the other way?)
   - **Dependencies** — what infra does it require? (LLM? embedding? database? none?)
   - **Unique concepts** — things this provider does that no other does
4. **Write the per-provider analysis** — structured as the format above. Save individually first, synthesize later.

**Critical rule:** Each provider gets its OWN section with full depth. Do NOT flatten to comparison table rows at this stage. The point is to understand each one deeply *before* comparing.

#### Phase 2: Cross-Cutting Pattern Map

**Goal:** Find the patterns that span multiple providers — these are architecture-level insights, not per-provider features.

1. **Build a dimension matrix** comparing all providers on key architectural dimensions:

   | Dimension | Provider A | Provider B | Provider C | ... |
   |-----------|-----------|-----------|-----------|-----|
   | LLM dependency | | | | |
   | Embedding dependency | | | | |
   | Vector store | | | | |
   | Graph support | | | | |
   | Session extraction | | | | |
   | Cost model | | | | |
   | Local-first? | | | | |
   | Human-readable? | | | | |
   | Self-correcting? | | | | |

2. **Identify 3-5 cross-cutting patterns** — repeatable architectural strategies that multiple providers use in different ways. Name each pattern and describe it generically:

   ```
   **Pattern N: [Pattern Name]**
   - **What it is:** [Generic description of the pattern]
   - **Who uses it:** [Provider A, Provider B, Provider C]
   - **Variations:** [How each provider adapts the pattern]
   - **Why it matters:** [Why this pattern is useful architecturally]
   ```

3. **Document anti-patterns** — approaches that look promising but have hidden costs (lock-in, latency, hallucination risk, cost explosion).

**Phase 2 output:** 3-5 named, described architectural patterns with provider-specific variations.

#### Phase 3: Hybrid Design Synthesis

**Goal:** Design a unified system that absorbs the best patterns from each provider. This is NOT "pick one winner" — it's "combine the best mechanisms."

1. **Build the concept inventory** — for each provider, list what to steal:
   
   | Provider | Pattern/Concept | How It Would Map to Our System | Priority |
   |----------|----------------|-------------------------------|----------|
   | Provider A | Mechanism X | Maps to existing component Y | P0/P1/P2 |
   | Provider B | Mechanism Y | Requires new component Z | P0/P1/P2 |

2. **Design the unified architecture** — an architecture diagram (ASCII or SVG) showing:
   - The new system's components
   - How concepts from each provider map to specific components
   - Data flow between components
   - The query/retrieval pipeline
   - The write/ingest pipeline

3. **Write the detailed design** — for each major subsystem, describe:
   - **What it does** (the mechanism)
   - **Which provider(s) inspired it** (with references back to the per-provider analysis)
   - **How it differs from the original** (adapted to our architecture)
   - **Dependencies** (what else needs to exist)
   - **Open questions** (what's not yet decided)

#### Phase 4: Implementation Roadmap

**Goal:** Produce a phased build plan, NOT a single recommendation.

1. **Phase 0 — Audit** (hours): What already exists, what needs verification
2. **Phase 1 — Quick Wins** (~1 week): High-value, low-effort improvements that can be built today
3. **Phase 2 — New Functions** (~2 weeks): New components that enable the hybrid design
4. **Phase 3 — System Integration** (~1 week): Wiring everything together, replacing old components

Each phase should have:
- Concrete checklist items with verification criteria
- Estimated effort
- Dependencies between items
- "Done" definition

#### Phase 6: Process vs LLM Footprint Analysis

**Goal:** Classify every component of the hybrid design by what engine it uses — pure process, small model, or LLM. This is not optional; it's the step that prevents designing systems that are too expensive to run.

1. **Build the classification table:**

   | Component | Engine | Cost | Can it be moved down a tier? |
   |----------|--------|------|------------------------------|
   | T0: Query Cache | Pure process | Free | — |
   | T1: BM25/FTS5 | Pure process | Free | — |
   | T2: Vector search | Small model (embedding) | Low | Only if BM25 suffices |
   | T3: Graph traversal | Pure process | Free | — |
   | T4: Reflect/Synthesis | LLM fallback | High | Only if query is SYNTHESIS AND cheaper tiers fail |
   | ... | ... | ... | ... |

2. **Apply the 90/10 rule** — identify which tiers handle 90% of requests. Those tiers should be process-only or small-model-only. The LLM should be a rare fallback.

3. **Document cost escape hatches** — for every component that uses an LLM, document:
   - The condition that triggers it (what query patterns, what failure modes)
   - The fallback if the LLM is unavailable (can it degrade gracefully?)
   - The cadence/backoff (how often can it fire before it's cost-prohibitive?)

4. **Flag shortcut temptations** — for every tempting "just use an LLM for this" decision, document the process alternative:

   | Tempting shortcut | LLM cost | Process alternative |
   |------------------|----------|-------------------|
   | LLM-based query classification | Per-turn | Regex classifier |
   | LLM-based entity extraction | Per-session | spaCy NER or regex |
   | LLM-based priority scoring | Per-compression | Regex scoring (already done) |
   | LLM-based content dedup | Per-write | Jaccard overlap |
   | LLM-based session summarization | Per-session | Priority-scored extraction |

5. **Write the analysis** into the report as a dedicated section, so future readers understand the cost model of the design.

**Example output:** See `references/hermes-memory-provider-architectural-synthesis-2026-05.md` Section "Process vs LLM Footprint Analysis" for a worked example covering 25+ components.

#### Phase 7: Knowledge Deposit

1. **Write the full analysis** to `~/athenaeum/Codex-God-thoth/research/{topic-slug}/report.md`
2. Include ALL sections: per-provider analysis, pattern map, hybrid design, implementation roadmap
3. Add a reference file under the skill:
   ```
   skill_manage(action="write_file", name="thoth-deep-research",
     file_path="references/{topic-slug}-synthesis-{YYYY-MM}.md",
     file_content="Condensed version: patterns, hybrid design, key decisions")
   ```
4. Update shared context at `~/pantheon/shared/athenaeum-writes.md`
5. Notify the user with the TL;DR

### Diff vs Other Patterns

| Dimension | Pattern B (Comparative) | Pattern F (Synthesis) |
|-----------|----------------------|----------------------|
| **Goal** | "Which is best" | "What can we build" |
| **Output** | Ranked comparison table | Hybrid architecture design |
| **Phase after comparison** | Recommendation | Cross-pattern synthesis |
| **Per-provider depth** | Same fields, flat rows | Individual analysis sections |
| **Design phase** | None | New architecture from patterns |
| **User expectation** | "Pick one" | "Combine the best" |

### Worked Example: Hermes Memory Provider Synthesis (2026-05-20)

See `references/hermes-memory-provider-architectural-synthesis-2026-05.md` for a full worked example covering 8 providers (Honcho, OpenViking, Mem0, Hindsight, Holographic, RetainDB, ByteRover, Supermemory) synthesized into the Hydra Athenaeum design.

### Common Pitfalls

1. **Going straight to comparison without per-provider depth** — The user explicitly wants to understand each provider's architecture *before* seeing the synthesis. If you flatten to a table too early, you lose the mechanisms. Each provider MUST get its own narrative section first.
2. **Missing the "what to steal" column** — The point of this pattern is action. Every provider analysis MUST end with a concrete recommendation for what to absorb.
3. **Designing the hybrid before understanding the patterns** — The cross-cutting pattern map (Phase 2) is the bridge between per-provider depth and the unified design. Don't skip it. It's where the non-obvious insights live.
4. **Zealot design** — Taking the most complex feature from every provider and jamming them together creates an unbuildable mess. The design should be coherent: patterns that reinforce each other, not conflict. ByteRover's 5-tier progressive retrieval and Hindsight's multi-strategy RRF are complementary (tiers decide *when* to query, RRF decides *how* to merge). Holographic's trust scoring and Honcho's dialectic cadence are complementary (scoring decides *what's reliable*, cadence decides *when to re-evaluate*).

7. **Skipping the infrastructure audit (Phase 0)** — The most expensive mistake this skill can produce. Without checking what the user has already built, you will design features that already exist, propose components that are already deployed, and waste the session. The user will call this out and rightly so. Phase 0 is not optional — it is the gate that prevents re-invention.
5. **No implementation phases** — A beautiful design without a build plan is a daydream. Every proposed feature needs a phase and an estimated effort.
6. **Forgetting the "what does it do best" one-liner** — Every provider analysis MUST start with what this provider uniquely excels at. Without this framing, the value of including it in the analysis is unclear.

---

For helping a user choose a name for a business, product, or project — researching availability, conflicts, and connotation. This is a creative-iterative pattern: brainstorm → filter → DNS check → conflict check → rank → recommend. Results are consultative, not a standard report.

### When to Use This Pattern

- User asks "help me name [business/product/project]"
- User says "I need a name for [entity] that relates to [theme]"
- You're being asked to evaluate candidate names for availability and conflicts
- User wants domain availability + company name conflict checking
- **User says "don't be afraid of unusual names or spellings"** — this is your green light to go creative, not a signal to stop. Iterate deeper into unusual territory.

### Don't Use For

- Naming a child or pet (different considerations — trademark/domain don't apply)
- Choosing a brand name for a public company that needs trademark filing (you can surface conflicts but this is not legal advice — flag that)
- Situations where the name is already decided and just needs domain checking (that's a quick domain check, not a naming research session)

### Methodology

#### Phase 1: Brainstorming

**Goal:** Generate candidate names organized by thematic category.

1. **Understand the brief:**
   - Is there an existing product/entity name the business name should relate to? (e.g., Pantheon)
   - What's the relationship? (parent company, product family, sibling brand)
   - Are there constraints? (no "AI" in name, must be "solutions" based, must sound corporate)
   - Who's involved? (founder names like "Tallon" may inspire Talon/Talon-like variants)

2. **Generate thematic lanes** — at least 3-4 distinct directions:
   - Direct reference (Olympus, Synod, Pantheon itself)
   - Oblique reference (words for "gathering," "divine," "all")
   - Architectural (temple features — oculus, cella, portico)
   - Abstract corporate (positional words — summit, sovereign, keystone)
   - Compound/portmanteau (Pan+forge = Panforge, Theon+onyx = Theonix)
   - Latin/Greek roots (words for "bridge," "key," "council," "forge")
   - Unusual spellings (Konverge, Zenyth, Panteon)

3. **Generate 30-50 candidates** across lanes. Don't self-censor in this phase — the creative oddballs often turn out to be the only available domains.

4. **Group by tier:**
   - **Tier 1:** Strongest connection to the reference, best corporate feel
   - **Tier 2:** Moderate connection, worth checking
   - **Tier 3:** Oblique or unusual — "don't be afraid of unusual names"

#### Phase 2: DNS Availability Check

**Goal:** Check which candidates have available domains. This is the primary technical gate.

1. **Tool choice:**
   - **`host {domain} 2>&1`** — primary check. NXDOMAIN = strong availability signal.
   - **`dig {domain} ANY +short 2>&1`** — fallback for domains where `host` returns empty. No output = no DNS = likely available.
   - **NOTE:** `whois` is often NOT available on the system. Don't assume it is. Check with `which whois` first.

2. **Batch processing** — check ~20-35 domains per batch using `execute_code`. The `host` command is fast (~0.5-1s per domain).

   ```python
   for domain in candidates:
       result = terminal(f"host {domain} 2>&1 | head -2")
       output = result.get('output', '')
       if 'NXDOMAIN' in output or 'not found' in output.lower():
           print(f"🟡 AVAIL: {domain}")
       elif 'has address' in output or 'has IPv6' in output or 'mail is handled' in output or 'is an alias' in output:
           pass  # registered — skip
       elif not output.strip():
           print(f"⚪ EMPTY: {domain}")  # retry with dig
       else:
           print(f"⚪ OTHER: {domain}")
   ```

3. **Empty responses** — some domains return empty from `host` (the command produces no output at all). Re-check these with `dig`:
   ```python
   result = terminal(f"dig {domain} ANY +short 2>&1 | head -3")
   if not result.get('output', '').strip():
       print(f"🟡 NO DNS: {domain}")
   ```

4. **Status codes:**
   - `🟡 AVAIL (NXDOMAIN)` — Strong indicator the domain is available for registration
   - `🔴 REGISTERED (has DNS)` — Domain is taken
   - `🟡 NO DNS` — Likely available but no DNS set up yet
   - `⚪ EMPTY/UNCERTAIN` — May need manual verification

5. **Supports `.com` by default** — the default TLD most naming research targets. Check other TLDs only if the user asks (`.com` is the gold standard for corporate names).

#### Phase 3: Company/Business Name Conflict Check

**Goal:** For every domain that passed Phase 2, verify there isn't already an existing company with the same or confusingly similar name.

1. **Web search pattern** — for each candidate, search:
   ```
   web_search("\"Candidate Name\" OR \"Candidate Solutions\" company OR business")
   ```

2. **Check these sources:**
   - LinkedIn company pages (most comprehensive)
   - Crunchbase (startup/tech companies)
   - ZoomInfo (general business directory)
   - Companies House / SEC (UK/US registered entities)
   - Wikipedia (notable companies)
   - USPTO or trademark databases (if available)

3. **Conflict severity:**
   - ❌ **Exact match** in the same industry — disqualify
   - ❌ **Confusingly similar** (e.g., "Consule Solutions" when checking "Consulate Solutions") — disqualify
   - ❌ **Active competitor under substantially similar name** (e.g., "TheoForge" AI consultancy when checking "Theoforge Solutions") — disqualify unless the user explicitly accepts the risk
   - ⚠️ **Same name, different industry** — flag with context (e.g., "Theonix Collection" is activewear, not tech — low risk)
   - ⚠️ **Same root word, different suffix** (e.g., "Aureole Group" exists, checking "Aureole Solutions") — evaluate closeness
   - ✅ **No conflicts found** — clean

4. **Document what you found** — for flagged candidates, note the conflicting company name, industry, and why it's a conflict.

#### Phase 3b: Social Media Handle Audit

**Goal:** Check whether the short-form name (without "Solutions") is already claimed on major platforms. Handles matter for brand consistency — even squatted/dormant accounts can cause confusion.

1. **Check these platforms** using `curl -s -o /dev/null -w '%{http_code}' -L`:
   - `x.com/{name}` and `x.com/{name}solutions` (X/Twitter)
   - `github.com/{name}` and `github.com/{name}solutions` (GitHub orgs)
   - `instagram.com/{name}` and `instagram.com/{name}solutions`
   - `reddit.com/user/{name}` and `reddit.com/r/{name}`
   - `pypi.org/project/{name}` (Python package name)
   - `npmjs.com/package/{name}` (Node package name)
   - `docker.com/{name}` (Docker Hub)
   - `linkedin.com/company/{name}` (LinkedIn company page)
   - `medium.com/@{name}`

2. **Status interpretation:**
   - HTTP 200/301/302 = **Taken** — account exists
   - HTTP 404 = **Available** — no account at that handle
   - HTTP 403 = **Restricted** — may be available but requires login to verify
   - HTTP 000 (curl timeout) = **Unknown** — retry or skip

3. **Investigate taken handles** — don't just mark them "taken" and move on. Use `web_extract` or `browser_navigate` to see *what's actually there*:
   - **Dormant personal account** (0 posts, 0 followers, random bio) = low risk, can coexist
   - **Active business in the same industry** = high risk, candidate may need disqualification
   - **Dormant org with no repos** = low risk, GitHub handle can be reclaimed if needed
   - **Active brand in a different industry** = medium risk, flag for user awareness

4. **Report findings** in the comparison table as:
   - ✅ Mostly available
   - ⚠️ Some taken (dormant/squatted)
   - ❌ Heavily contested (active competitors or deep brand conflicts)

#### Phase 4: Evaluation & Ranking

**Goal:** Produce a ranked shortlist of the best candidates.

1. **Build a comparison table** with these dimensions:

   | Name | Domain | Biz Conflicts | Brand Connection | Corporate Feel | Memorable? |
   |------|--------|:-------------:|:----------------:|:--------------:|:----------:|
   | Name A | ✅/❌ | ✅/⚠️/❌ | ⭐⭐⭐ | Strong/Weak | Yes/No |

2. **Rank by:**
   - Domain available (strict gate — must pass)
   - No business conflicts (strict gate — must pass, or minor)
   - Strength of connection to the reference (for the brief)
   - Corporate/corporate feel (for the use case)
   - Pronunciation clarity (can people say it?)
   - Avoids negative associations

3. **Tier the results:**
   - 🥇 **Top candidates** — domain available + no conflicts + strong brand connection
   - 🥈 **Second tier** — available but weaker connection or minor conflict
   - ❌ **Disqualified** — domain taken or major conflict found

4. **Write the recommendation** with a clear favorite and rationale.

#### Phase 5: Report & Deposit

1. **Write report** to `~/athenaeum/Codex-God-thoth/research/business-naming/report.md`
   - Include methodology summary
   - Full comparison table
   - Tier-based recommendations
   - All disqualified names with reasons (so the user knows *why* the obvious ones didn't work)
   - Date-stamp the research

2. **Notify the user** with:
   - Top 3-5 recommendations
   - Which one you'd pick and why
   - Link to the full report

3. **Do NOT wiki-ingest naming research** — company names are user-specific, not durable knowledge. Exception: if you learned a general technique (like DNS-based domain checking), store that here in the skill's references.

---

#### Phase 6: Deep Due Diligence (Follow-Up Pass)

**Goal:** When the user says "check [candidate] thoroughly," run a second-pass deep investigation on that single candidate. This is NOT a repeat of Phase 2-3 — it's a *deeper* check across vectors the initial screening didn't cover.

**When to trigger this phase:** User says "make sure everything is clean for [name]" or "do the full due diligence on [name]."

### Phase 6a: Trademark & Legal Search

1. **Check trademark databases:**
   - **Trademarkia** (`trademarkia.com`) — search for the exact name, any close variants (e.g., "TheoForge" when checking "Theoforge Solutions")
   - **USPTO** TESS database (or trademarkia as proxy) — covers US federal trademarks
   - **Justia Trademarks** (trademarks.justia.com) — alternative USPTO search
   - Search for both the compound name AND its component parts (e.g., search both "Panforge" AND "Forge" for context)

2. **Check business registries:**
   - **OpenCorporates** (opencorporates.com) — global business entity search
   - **Companies House** (UK) — find-and-update.company-information.service.gov.uk
   - **US SEC of State** — search via OpenCorporates or direct state-level searches
   - Search for the exact name and any close variants

3. **Categorize risk:**
   - 🔴 **Existing trademark in same class** — highest risk, recommend against
   - 🟡 **Active mark in commerce without registration** (e.g., someone using "TheoForge" as a brand with a live site but no filed trademark) — real risk if they file before you do
   - 🟢 **No trademarks, no active commercial use** — clean

### Phase 6b: Competitive Landscape Review

1. **Search for the exact business name in active use:**
   ```
   web_search("\"Exact Name\" -\"yoursite.com\" company OR business OR llc OR inc")
   ```

2. **Inspect any live sites or profiles found** — use `web_extract` or `browser_navigate` to determine:
   - Is it an active business or a dormant portfolio project?
   - What industry does it serve?
   - How long has it been operating?
   - Is there client evidence (testimonials, case studies, published work)?
   - Does the GitHub description say "portfolio project" or "production business"?

3. **Assess the conflict's practical significance:**
   - **Same name, same industry, active** — HIGH risk. Confusion is inevitable
   - **Same name, same industry, portfolio/demo** — MEDIUM risk. May formalize; could cause confusion if they scale
   - **Same name, different industry** — LOW risk. Courts consider industry separation
   - **Similar but not identical name, same industry** — MEDIUM risk. Depends on closeness and geography

4. **Document the competitor's details:**
   - Founder/operator (if identifiable)
   - When they started (check copyright dates, domain registration dates, repo creation dates)
   - What they do (one-paragraph summary)
   - Why they're a risk (or not)

### Phase 6c: Risk Matrix & Recommendation

Synthesize findings into a risk matrix:

| Risk Factor | Severity | Details | Mitigation |
|------------|----------|---------|-----------|
| Trademark conflict | 🔴/🟡/🟢 | What was found | Steps to reduce |
| Competitor confusion | 🔴/🟡/🟢 | Existing entity details | Differentiate with suffix/logo |
| Domain availability | 🟢/🟡 | Primary + alternatives | Register immediately |
| Social handle recovery | 🟢/🟡/🔴 | Which are taken, by whom | Squatter recovery or accept loss |
| Business registration | 🟢 | No existing entity | File LLC before competitor does |

End with a clear **go / no-go / modified-go** recommendation.

### Phase 6d: Save & Notify

1. Write the due diligence report to `~/athenaeum/Codex-God-thoth/research/{name}-due-diligence/report.md`
   - Include all Phase 6a-6c findings
   - Risk matrix
   - Clear recommendation

2. Notify the user with the verdict:
   ```
   god-notify thoth info "Due diligence complete for [Name]" "Verdict: [go/no-go/modified-go]. [Key finding]. Full report at [path]"
   ```

3. Do NOT wiki-ingest — this is client-specific due diligence, not durable knowledge.

---

### Common Pitfalls

2. **Confusing DNS availability with business availability** — A domain might have no DNS (technically available) but the brand name might already be in use by an active company. Always cross-reference with web searches.

3. **Not checking business conflicts for *before* presenting** — Presenting a name that sounds great only to have the user find the existing company undermines trust. Check conflicts before the user sees the name.

4. **Missing the "empty host response" trap** — `host {domain}` can return zero output for registered domains in certain configurations (especially with `.com` TLDs). Always re-check empty responses with `dig ANY +short` before classifying as available.

5. **Using delegate_task for naming research** — Don't. Naming is a creative iterative process where you build on each wave's findings. Sub-agents can't iterate creatively — they produce flat results.

6. **Forgetting that the user said "don't be afraid of unusual names"** — This is a key signal. When you hear this, your normal-name filter should relax. Push into compound words, foreign roots, alternate spellings, and portmanteaus.

7. **Domain `s` suffix mismatch** — When checking "X Solutions" domains, note that many will be taken. Don't get discouraged — try the root word alone with different suffixes (Group, Partners, Collective, etc.) or try unusual compounds.

8. **Untested whois availability** — `whois` may not be installed. Use `which whois` to check. If absent, `host` and `dig` are your tools. DNS-based checking is a reasonable proxy but not 100% — some registered domains lack DNS.

11. **Not date-stamping** — Name/domain checks go stale. Domain registrations expire, companies change names. Put the date on the report.

12. **Missing the "deep due diligence" pass** — When the user asks "check X thoroughly," the initial screening isn't enough. You need a full trademark search, business registry check, social media audit, and competitive landscape review. Don't half-ass the follow-up.

13. **Treating a social handle as "available" without verifying what's at the URL** — A 404 on x.com/theoforge means the handle is free. A 200 that shows a personal account with 0 followers is *not* the same thing. Use `web_extract` or `browser_navigate` to inspect the actual profile, not just the HTTP status code.

14. **Missing the "portfolio project" vs "real business" distinction** — A live site at theoforge.vercel.app with client testimonials could be a real consultancy OR a developer's portfolio template. The GitHub description saying "presented as a polished public-facing portfolio project" is a critical clue. Always check the repo README, commit history, and site content to distinguish.

15. **Forgetting to search for the name WITHOUT the "Solutions" suffix** — The root word (e.g., "TheoForge") may be in active use even when "TheoForge Solutions" domain is available. Always search for both the compound and its root. The root-name-in-use is the real conflict, not the "Solutions"—suffixed domain availability.

16. **Not using `dig ANY +short` as fallback for empty `host` responses** — Some `.com` domains return zero output from `host` even when registered. Always re-check empty responses with `dig`. This can misclassify registered domains as available.

For side-by-side comparisons of N items across defined dimensions (pricing, features, specifications). This is NOT an open-ended deep dive — it's a structured comparison where the items are known upfront and the goal is to rank/compare them.

### When to Use This Pattern

- User asks "compare [providers/plans/tools] on [cost/features/usage]"
- User provides a source page listing multiple options and wants a ranking
- The request is about "which is cheapest/best" — ranking-oriented
- Multiple similar items need side-by-side comparison across fixed dimensions
- Any research where the output is a comparison table, not an exploratory narrative

## User Correction Protocol (Applies to ALL Patterns)

If the user calls out that you didn't do a named skill or did it wrong:

1. **Acknowledge immediately** — "You're right, I should have [loaded/followed] that skill"
2. **Do not argue or explain** — the user's correction is the signal
3. **Load the skill now** if you haven't — this is not optional
4. **Pivot to the correct pattern** — restart from the skill's Phase 1, don't try to retroactively adapt what you already did
5. **Verify completeness** — once you finish, double-check you covered everything the skill requires
6. **Patch the skill** if the reason you missed it was that the skill was unclear, missing triggers, or had gaps that this session revealed

## Design Philosophy: Minimize LLM Footprint

When designing systems or architectures (especially Pattern F), apply this constraint by default:

**Prefer pure process over small models over LLMs, in that order.**

Before adding a component that requires an LLM, ask:
- Can this be done with pure process? (regex, math, SQL, FTS5, file operations)
- Can this be done with a small model? (nomic-embed-text ~50MB, spaCy NER ~10MB, BERT-based reranker)
- If it truly needs an LLM, can it be a fallback that fires only when cheaper methods fail?

Document the LLM footprint of every design decision in Pattern F Phase 6. The goal is 90%+ of operations handled without an LLM call.

This is a user preference, not negotiable per-session. Encode it in every hybrid design.

This is NOT a user preference to memory — it's a workflow response pattern that belongs in every skill.

### Don't Use For

- Open-ended exploration of a category (use Pattern A)
- Deep-diving into a single item (use Pattern A with 1 item)
- Topics where items aren't known upfront

### Methodology

#### Phase 1: Source Acquisition

**Goal:** Build the master item list. Start with any source the user provides, then supplement.

1. **Extract user-provided source** — if the user shares a URL:
   ```
   web_extract(url) → get baseline list of items + their attributes
   ```
   
   **⚠️ Truncation check:** `web_extract` often cuts off long pages (especially comparison tables with 20+ rows). After extraction, scan the result for clues of truncation: sentences ending mid-word, tables cut off, "continued" markers, or a "..." truncation notice. If the page was truncated:
   - Do NOT proceed with partial data
   - Search for the missing sections explicitly:
     ```
     web_search("site:example.com [topic] aggregators plugins 2026")
     web_search("[source site name] pricing providers complete list")
     ```
   - Cross-reference: compare what you got vs what the page title/description promises
   
   A single `web_extract` call that returns 60-70% of a page is a trap — you'll produce confident-looking but incomplete research.

2. **Search for supplementary sources** — find items missing from the baseline:
   ```
   web_search("topic providers/plans comprehensive list 2026")
   web_search("alternatives to [item] similar comparison")
   ```

3. **Cross-reference** — merge sources, deduplicate, flag gaps. Don't trust a single source's schema.

4. **Categorize items by type** — if the source list contains fundamentally different kinds of items (e.g., direct model providers vs aggregator gateways vs IDE plugins), split them into categories before comparing. A direct API provider like Anthropic should NOT be in the same comparison row as a gateway like LLM Gateway — they serve different roles, have different pricing models (per-token vs subscription vs credits), and different dimensions matter for each.

   Create separate comparison sections per category, each with its own dimension set:
   - **Direct Providers:** Dimensions = per-token cost, model quality, context window, tool-calling quality
   - **Aggregators/Plugins:** Dimensions = monthly subscription, model selection breadth, convenience features, markup/fees
   
   A single flat comparison of 27 items with the same row schema will be misleading when half are providers and half are resellers.

5. **Define comparison dimensions** — these emerge from the research but should be finalized before Phase 2. For direct providers and aggregators, use separate dimension sets (see step 4). Typical dimensions:
   - **Cost:** Monthly price, per-token price, minimum commitment
   - **Usage:** Rate limits, request quotas, concurrent connections
   - **Models:** Model names, context windows, capabilities
   - **Quality:** Benchmarks, tool-calling support, real-world performance

**Phase 1 output:** Sorted list of all known items with dimensions to compare, split by category.

#### Phase 2: Dimension Extraction

**Goal:** For each item, extract data across every dimension. Do NOT use delegate_task for this pattern — the items are too interconnected and you need side-by-side consistency.

Instead, do **iterative deep extraction**:

1. **Group sources by coverage** — some sources cover multiple items (comparison pages), some cover one item in depth (product pages, pricing pages)

2. **Extract systematically per dimension:**
   ```
   For each source:
     web_extract(source_url) → extract relevant dimension data
     For each item in that source:
       capture cost, usage limits, models available, etc.
   ```

3. **Backfill gaps** — when a source doesn't have data for an item, search specifically:
   ```
   web_search("[item name] pricing plans 2026")
   web_search("[item name] usage limits rate limits")
   ```

4. **Maintain consistency** — use the same dimension labels across all items. If one source says "prompts per 5h" and another says "requests/month", note both but standardize in your output.

#### Phase 3: Ranking & Synthesis

**Goal:** Turn extracted data into a ranking and comparison output.

1. **Sort by user's stated criteria** — if they said "cheap" → sort by ascending cost. If "best models" → sort by quality/benchmarks. Never default to alphabetical.

2. **Build tiered categories** — group by cost band or quality band:
   ```
   Tier 1: Free ($0)
   Tier 2: Ultra Budget (< $10/mo)
   Tier 3: Budget ($10-30/mo)
   ...
   ```

3. **Write the comparison document** using this structure:

   ```
   # 🏆 Topic — Comprehensive Comparison

   ## Quick Decision Guide (by use case)
   | Your Situation | Best Pick | Cost |
   |---|---|---|

   ## TIER N: Category Name
   ### Item Name
   | Detail | Value |
   |---|---|
   | **Cost** | |
   | **Usage** | |
   | **Models** | |
   | **Pros** | |
   | **Cons** | |
   | **🔥 Verdict** | |

   ## Side-by-Side Summary Table
   | Item | Cost | Usage | Models | Verdict |

   ## Top Recommendations (By Use Case)
   ```

4. **Include a dimension-specific deep-dive** — a matrix showing which items win on which axis:
   ```
   ### By Cost (Cheapest → Most Expensive)
   1. Provider A — $X
   2. Provider B — $Y
   ...

   ### By Quality (Best → Worst)
   1. Provider C — Feature Z
   ...
   ```

5. **Always include critical caveats** relevant to the context:
   - Hidden costs (overage fees, minimum commitments)
   - Quality/cost tradeoffs (cheaper models may need more retries)
   - Dependencies (one plan may require another subscription)

#### Phase 4: Save, Wiki, & Notify

1. Save the document to `~/athenaeum/Codex-God-thoth/research/{topic-slug}-{YYYYMMDD}/report.md`
2. **Wiki ingest** — extract durable knowledge (rankings, tier definitions, per-item profiles) into `~/wiki/comparisons/{slug}.md`. Update `~/wiki/index.md` and `~/wiki/log.md`.
3. If the research is a good template for future comparisons, add it as a reference under this skill:
   ```
   skill_manage(action="write_file", name="thoth-deep-research", 
     file_path="references/comparison-research-template.md",
     file_content="Concise template showing the comparison structure above")
   ```
4. Notify the user:
   ```
   god-notify thoth info "Comparative research complete" 
     "Compared N items across X dimensions. TL;DR: [key finding]. Full report at [path]"
   ```

### Pattern B Output Example

See `references/hermes-model-provider-comparison-2026-05.md` for a worked example comparing 25+ provider plans for Hermes Agent across cost, usage, and models.

---

## Output Structure

```
~/athenaeum/Codex-God-thoth/research/{topic-slug}/
├── outline.yaml       # Research plan (items + fields + config) — Pattern A
├── fields.yaml        # Field definitions per category — Pattern A
├── results/
│   ├── item-one.json  # Deep research result per item — Pattern A
│   ├── item-two.json
│   └── ...
└── report.md          # Synthesized markdown report — both patterns
```

---

## Example Session

**User:** "Thoth, deep dive into AI coding assistants"

**Thoth does (Pattern A):**
1. Generates framework: items = [GitHub Copilot, Cursor, Codeium, Amazon Q Developer, Cody, Tabnine, CodeGPT], fields = [Basic Info, Technical Features, Pricing, Performance]
2. Web searches to supplement — finds Replit Agent, Claude Code, adds field for "SWE-bench score"
3. Saves outline.yaml and fields.yaml
4. Spawns 3 delegate_task workers (2-3 items each) — all run in parallel
5. Workers each research their batch, output JSON files
6. Reads all JSON, runs report generator
7. Saves report.md and notifies user:
   > *Went down the AI coding assistant rabbit hole. Covered 9 products across 5 dimensions. TL;DR: Cursor leads on UX, Claude Code leads on SWE-bench, Copilot has distribution. Report's at ~/athenaeum/Codex-God-thoth/research/ai-coding-assistants/report.md*

**User:** "Compare AI model provider pricing plans ranked by cheapest"

**Thoth does (Pattern B):**
1. Extracts user-provided URL → gets baseline list of 27 providers
2. Searches for supplementary providers — finds Together AI, Fireworks, DeepInfra, Groq, SambaNova
3. Defines dimensions: monthly cost, per-token cost, usage limits, models available, tool-calling quality
4. Iteratively extracts data from each source, backfills gaps with targeted searches
5. Ranks by cost → organizes into 5 tiers (Free → Ultra Budget → Budget → Mid-Range → Premium)
6. Produces comparison document with quick-decision guide, tier-by-tier breakdown, dimension-specific matrices, and use-case recommendations
7. Saves report and notifies user with TL;DR

---

## Tuning Parameters

- **`batch_size`** in `outline.yaml`: items per delegate_task agent. Default 3. Lower = more agents but less work per agent. Higher = fewer agents but denser prompts. For 10+ items, use 3-4. For 3-5 items, use 2.

- **`max_concurrent_children` gate:** `delegate_task` has a config cap on parallel children. The Thoth profile has `max_concurrent_children: 5` (set in `~/.hermes/profiles/thoth/config.yaml`). If running under a different profile, check its delegation limits first. Plan your batch_size so your batches fit under the cap. If you exceed it, split into multiple `delegate_task` calls (e.g., 5 batches → round 1 with 3 tasks, round 2 with 2 tasks).

- **`detail_level`** in `fields.yaml`: controls depth. `brief` = single value, `moderate` = paragraph, `detailed` = multi-paragraph with sources.

- **Time range:** Auto-detected from context. If the topic is time-sensitive, Thoth should search with the last 6-12 months as default range. Evergreen topics get unlimited range.

- **For Pattern B:** No batch_size or fields.yaml needed. The dimensions emerge from the research. Use the tier structure to organize results.

---

## Common Pitfalls

1. **Over-splitting batches** — 1 item per agent wastes context. Each agent can reliably handle 3-4 items. Trust the parallelization.

2. **Under-defining fields** — "Tell me everything" produces sloppy results. Define 3-5 field categories with 2-4 fields each. Capture what matters.

3. **Not verifying subagent output** — `delegate_task` returns summaries, not raw data. Always check the actual JSON files were written with valid content.

4. **Forgetting the uncertain marker** — If a subagent can't find reliable data for a field, it should write `[uncertain]` explicitly, not fabricate. The report generator skips these.

5. **Output directory conflicts** — If the same topic-slug exists, either append a timestamp or warn that existing files may be overwritten. Prefer `{topic-slug}-{YYYYMMDD}` for unique paths.

6. **Missing the notification** — After report is done, use the god-notify script so the user knows research completed. Don't let it sit silently.

7. **Bumping into `max_concurrent_children` limits** — `delegate_task` has a cap on parallel children (default `max_concurrent_children: 3` in config). If you have more batches than the cap, split into **multiple `delegate_task` calls** (e.g., 5 batches → call 1 with 3 tasks, call 2 with 2 tasks). Do NOT try to cram 10+ items into one call — it will be rejected.

8. **Subagent-produced JSON is unreliable by default** — Subagents may produce malformed JSON, particularly using JavaScript object-literal syntax (`{key, value}`) instead of proper JSON key-value pairs (`{"key": "value"}`). Common offenders: `{key1, key2}` instead of `{"key1": "desc", "key2": "desc"}`, and bare `true/false` as values. Always: (a) verify all result JSON files are parseable with `json.loads()`, (b) have a cleanup/repair step that catches parse errors early, (c) read each file and wrap in try/except during report generation.

9. **Field key naming inconsistency across subagents** — Different subagents may use different key conventions for the same field (e.g., flat `"api_format": "..."` vs nested `"2_technical_details": {"api_format": "..."}`, or snake_case vs camelCase). The report generator MUST use **defensive accessor functions** that try multiple key patterns — see the `gv()` / `dig()` helper pattern in the report template below. Without this, the synthesized report will have sparse rows.

10. **Using delegate_task for comparison research (Pattern B antipattern)** — Don't delegate individual items to sub-agents for comparisons. Items are interconnected and need consistent dimension extraction. A sub-agent researching Provider A might capture pricing differently than one researching Provider B, making ranking impossible. Do sequential extraction yourself for consistency.

11. **Relying on a single source** — Comparison pages (like hermesguide.xyz) are a great starting point but often miss providers, have stale pricing, or use inconsistent categories. Always supplement with independent searches for at least 3-5 additional sources.

12. **Not date-stamping pricing research** — AI model pricing changes monthly. Always put the date of research in the document title and note when pricing was verified. This lets future sessions know if the data is fresh or stale.

13. **Ranking by wrong criterion** — If the user says "cheap" they might mean "low monthly subscription" or "low per-token cost" or "has a usable free tier." Clarify by asking or by ranking multiple ways (by monthly cost, by per-token cost, and by value ranking).

14. **Missing items from a user-provided source due to `web_extract` truncation** — Long comparison pages (20+ items) frequently exceed `web_extract`'s content limit. The result is a truncated list that *looks* complete but isn't. You'll produce confident-looking research that misses half the items. **Always check** whether the page was truncated before extracting data. If truncated, search for the missing content explicitly rather than proceeding with what you have.

15. **Treating mixed-type items as uniform in Pattern B** — Direct providers (model labs), aggregators (gateways/resellers), and plugins (IDE extensions) are fundamentally different categories. If you compare them all with the same row schema (e.g., "$ per 1M tokens" applied to both DeepSeek and Cursor), the comparison will be misleading and the user will spot it. See Phase 1 step 4 for how to split.

17. **Firecrawl is NOT available on this system** — Do not suggest or attempt to use Firecrawl for web extraction. The system cannot run it (hardware/network constraints). Use `web_search` + `web_extract` + `curl` for API-based extraction (arxiv, Semantic Scholar, GitHub) instead. See `references/lightweight-research-extraction.md` for exact API patterns.

18. **Not ingesting into the wiki after Pattern A/B** — Findings that are not written to `~/wiki/` are effectively lost. After every Pattern A or B research session, spend the extra minute to extract durable entities, concepts, and comparisons into the wiki. Future-you will thank past-you.

---

## External Skill Ecosystem Reference

When research involves sourcing or evaluating existing AI Agent skills (for loading into specialist profiles), see `references/external-agent-skill-ecosystem.md` for a structured catalog of 25+ major skill repositories, marketplaces, and per-domain resources across security, frontend, backend, research, outreach, and quantitative analysis. This reference is especially useful when:

- Building a new specialist profile and looking for pre-built skill libraries
- Comparing available skills across the ecosystem (skills.sh, Agensi, awesome-agent-skills, etc.)
- Evaluating whether a security audit, UI generation, or quant analysis skill already exists before building one
- Doing ecosystem reconnaissance before a multi-profile kanban deployment

## Verification Checklist

- [ ] `outline.yaml` has topic, items list, batch_size, output_dir — Pattern A
- [ ] `fields.yaml` has at least 2 categories with 2+ fields each — Pattern A
- [ ] Every item in outline.yaml has a matching JSON in results/ — Pattern A
- [ ] Each JSON file covers all fields (uncertain where needed) — Pattern A
- [ ] **Pattern B:** Master item list built from 3+ sources, not just one
- [ ] **Pattern B:** Every item has data for every comparison dimension
- [ ] **Pattern B:** Items are organized into clear tiers (cost/value/quality bands)
- [ ] **Pattern B:** Quick-decision guide answers "which should I pick" at a glance
- [ ] `report.md` has TOC + detailed sections
- [ ] User was notified with key findings summary
- [ ] Research is saved in Thoth's Codex for future reference
- [ ] Document is date-stamped so freshness is verifiable later