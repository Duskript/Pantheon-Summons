# External Agent Skill Ecosystem — Reconnaissance Reference

> Documented: 2026-05-19
> Purpose: Quick-reference catalog of external AI Agent Skills that can be loaded into specialist Hermes profiles. Updates as the ecosystem evolves.

## Skill Marketplaces & Directories

| Marketplace | Size | Curation | Security Review | Cost | URL |
|-------------|------|----------|-----------------|------|-----|
| **skills.sh** (Vercel) | ~2,000 | Community submissions | None | Free | https://skills.sh/ |
| **Agensi** | ~500+ | Curated + paid | Yes | Free + paid | https://www.agensi.io/ |
| **ClaudeSkills.info** | ~1,000 | Community-vetted | None | Free | https://claudeskills.info/ |
| **SkillsMP** | 800,000+ | Scraped (2+ stars) | None | Free | https://skillsmp.com/ |
| **Agent Skills** (agentskills.io) | Open standard | Specification, not a marketplace | N/A | Free | https://agentskills.io/ |
| **SkillsDirectory** | ~500+ | Scanned for injection/theft | Yes | Free | https://skillsdirectory.com/ |
| **awesome-agent-skills** (VoltAgent) | 1,100+ indexed | Hand-picked | None | Free | https://github.com/VoltAgent/awesome-agent-skills |

**Strategy recommendation:** Use two tiers: (1) `awesome-agent-skills` as the master index for discovery, (2) Agensi or ClaudeSkills.info for vetted/curated specific skills.

---

## Major Skill Repositories (by Domain)

### 🛡️ Security & Auditing — sec-ops profile

**Trail of Bits Skills** (~22 plugins)
- Repo: `trailofbits/skills` (2.1k stars)
- Focus: Professional security audit workflows — static analysis (CodeQL, Semgrep), differential review, false positive verification, variant analysis, supply-chain risk auditing, YARA authoring, constant-time analysis, mutation testing, mobile APK scanning, property-based testing
- Format: Claude Code plugin market (can be adapted to SKILL.md)
- URL: https://github.com/trailofbits/skills

**Anthropic Cybersecurity Skills** (754 skills, 26 domains)
- Repo: `mukul975/Anthropic-Cybersecurity-Skills`
- Coverage: Cloud Security (60), Threat Hunting (55), Web App Security (42), Malware Analysis (39), Digital Forensics (37), Network Security (40), Container Security (30), API Security (28), IAM (35), DevSecOps (17), + 16 more
- Framework-mapped: MITRE ATT&CK v18, NIST CSF 2.0, MITRE ATLAS, D3FEND, NIST AI RMF
- Format: agentskills.io standard (SKILL.md per skill)
- License: Apache 2.0
- URL: https://github.com/mukul975/Anthropic-Cybersecurity-Skills

**Agentic Pentesting Scanner**
- Repo: `splx-ai/agentic-radar` — scans agentic workflows for vulnerabilities
- URL: https://github.com/splx-ai/agentic-radar

### 🖥️ Frontend — frontend-dev profile

**Official Anthropic/Vercel Skills (install directly):**
- `anthropics/skills → frontend-design` — 110k+ weekly installs, bans generic AI slop (Inter, purple gradients). Forces deliberate aesthetic choices.
- `vercel-labs/agent-skills → vercel-react-best-practices` — 57 React performance rules
- `vercel-labs/agent-skills → web-design-guidelines` — 100+ accessibility/UX audit rules (ARIA, focus states, keyboard nav)
- `vercel-labs/agent-skills → composition-patterns` — compound components, replace boolean prop hell
- `vercel-labs/agent-skills → next-best-practices` — Next.js conventions

**Community/Platform Skills:**
- `stitch-design-taste` — Google Labs design-to-code with React + shadcn/ui
- `shadcn-ui` — shadcn/ui component conventions
- `playwright-best-practices` — browser testing with Playwright
- `remotion-best-practices` — programmatic video with React
- `extract-design-system` — extract design tokens from existing codebases
- Flutter (22 skills), Expo (6+), GSAP animation, Angular developer skill

**Agensi:**
- `frontend-design` — component generation + design system enforcement
- `canvas-design` — poster/art/static design

### 🖧 Backend — backend-dev profile

**Infrastructure & Database Skills:**
- `supabase-postgres-best-practices` — PostgreSQL patterns (skills.sh)
- `microsoft/azure-skills` — 133 skills across 6 languages (Azure, Cosmos DB, Entra ID, Key Vault, Service Bus, etc.)
- `hashicorp/terraform` — IaC patterns, state management, module design
- `mongodb` — Schema design, query optimization, Atlas Search/Vector
- `redis` — Data structures, caching, vector search
- `neon` — Serverless Postgres patterns
- `duckdb` — SQL querying, data analysis patterns
- `clickhouse` — architecture advisor, deployment, SQL engine
- `firebase` — Auth, Firestore, Hosting, Security Rules auditing
- `api-development` — REST APIs, GraphQL, auth flows (Agensi)

**Architecture Rules:**
- `bardiakhosravi/ai-agent-backend-standards` — 24 DDD + Hexagonal Architecture rules for Python backends. Ready-to-use `.cursorrules` / `CLAUDE.md`. URL: https://github.com/bardiakhosravi/ai-agent-backend-standards

**Development Methodology:**
- `obra/superpowers` (45.5k stars) — full SDLC: brainstorming → plan → TDD → code review. Skills: `/brainstorm`, `/write-plan`, `/execute-plan`, `using-git-worktrees`, `test-driven-development`

### 🔬 Research — researcher profile

**Existing Pantheon:**
- `thoth-deep-research` — structured deep research with parallel sub-agents (this skill)

**External:**
- `firecrawl` — reliable web scraping, search, browser automation (>80% content recall, handles JS)
- `brycewang-stanford/Awesome-Agent-Skills-for-Empirical-Research` — 119 repos, 23k+ skills for economics/political science/sociology research
- `content-strategy`, `seo-audit`, `product-marketing-context`, `pricing-strategy` (skills.sh)

### 📡 Outreach — outreach profile

- `cold-email` — email sequence patterns (skills.sh)
- `email-sequence` — drip campaign workflows (skills.sh)
- `content-strategy` / `product-marketing-context` — positioning, messaging (skills.sh)
- Google Workspace MCP — Gmail, Calendar, Sheets, Docs, Slides
- Release notes best practices: AnnounceKit guide, ProductPlan guide

**Note:** This profile will need the most **custom skill authoring** — the ecosystem is thinnest here.

### 📊 Quantitative Analysis — quant profile

**Open-Source Agent Platforms:**
- `AI4Finance/FinRobot` — multi-layer financial AI agent (Perception→Brain→Action)
- `AI4Finance/FinGPT` — financial LLM, sentiment analysis, RAG for finance
- `AI4Finance/FinRL` — reinforcement learning for financial trading
- `TradingAgents` (UCLA/MIT) — 7-role multi-agent framework (Fundamental/Sentiment/Technical/News analysts + Bull/Bear researchers + Risk Manager)

**Tooling Libraries (not skills, but knowledge for the agent):**
- `awesome-quant` — 200+ curated quant libraries (https://github.com/wilsonfreitas/awesome-quant)
- Python stack: `numpy`, `pandas`, `scipy.stats`, `statsmodels`, `arch`, `backtrader`/`pyfolio-reloaded`, `mplfinance`, `seaborn`
- Statistical testing: Pingouin (pandas-integrated), tea-tasting (A/B with CUPED)
- DCF modeling with Monte Carlo templates (e.g., BAndonova/Financial-Modeling-Analysis)
- Time series: ARIMA/GARCH workflow (statmodels.tsa + arch library)

**Note:** Zero pre-built SKILL.md files exist for quant workflows — this profile needs custom skill authoring.

---

## How to Use This Reference

When building a specialist Hermes Agent profile:

1. **Clone or install** the relevant skills from the repos above into the profile's skill directory:
   ```bash
   ~/.hermes/profiles/{profile-name}/skills/{skill-name}/SKILL.md
   ```

2. **Or** point the profile's `config.yaml` skills section at a shared skill pool:
   ```yaml
   skills:
     external_dirs:
       - ~/external-skills/trailofbits/
       - ~/external-skills/anthropic-cybersec/
   ```

3. **For the 754-skill cybersecurity library**: Clone the entire repo and symlink/select skills by domain. Don't dump all 754 into context — load only the subdomains relevant to the task (e.g., Web App Security + API Security for a web app audit).

4. **For custom skills** (quant, outreach thin areas): Use existing skills as templates for the SKILL.md structure (YAML frontmatter + progressive disclosure body). Follow the agentskills.io specification: https://agentskills.io/specification

5. **Verify compatibility**: Not all "skills" are pure SKILL.md format — some are Claude Code plugins (Trail of Bits), some are market-specific formats. Test installation with `hermes skills install` or manually copy the SKILL.md content into the profile's expected format.