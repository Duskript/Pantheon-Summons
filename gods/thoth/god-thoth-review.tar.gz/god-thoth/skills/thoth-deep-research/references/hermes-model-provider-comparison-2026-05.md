# Reference: Hermes Agent Model Provider Comparison (May 2026)

**Pattern demonstrated:** Comparative Research (Pattern B) — ranking N providers across cost, usage, and model dimensions.

**Full report:** `~/athenaeum/Codex-God-thoth/research/hermes-agent-provider-plans-20260517/report.md`
**Workspace copy:** `~/workspace/hermes-provider-plans-complete-2026.md`

## What This Covers

Compared **27 provider plans** across **100+ plan tiers** for use as Hermes Agent backends (10 direct providers + 17 aggregators & plugins). Dimensions: monthly cost, per-token pricing, usage limits, model availability, tool-calling quality.

## Method Used

1. **User-provided source:** hermesguide.xyz/coding-plans/ (27 providers in two sections)
2. **⚠️ First attempt mistake:** `web_extract` returned truncated content — only captured the 10 Direct Providers, missed the 17 Aggregators & Plugins section below it. Proceeded anyway → user called it out.
3. **Correction:** Re-extracted properly, searched supplementary sources for each aggregator/plugin individually
4. **Supplementary search:** Found 5+ additional providers not on the list (Together AI, Fireworks, DeepInfra, Groq, SambaNova) — these went into the pay-per-token rankings
5. **Dimensions per category:**
   - Direct Providers: monthly plan cost, per-token rates, context window, tool-calling quality, best use case
   - Aggregators/Plugins: subscription cost, model selection breadth, convenience features, markup/fees, Hermes compatibility
6. **Iterative extraction:** 15+ web_extract calls across provider pricing pages, Reddit discussions, and AI comparison sites
7. **Ranking:** By cost → organized into 5 tiers (Free → Ultra Budget → Budget → Mid-Range → Premium), then by value/quality
8. **Output:** Quick-decision guide + tier-by-tier breakdown (both categories) + side-by-side cost rankings + top-10 recommendations + critical caveats

## Key Structural Choices

- **Split into two parts** — Part 1: Direct Providers (10), Part 2: Aggregators & Plugins (17). Different dimension sets for each.
- **Quick Decision Guide first** — lets user jump straight to their budget band
- **🔥 Verdict per item** — gives one actionable takeaway per option
- **Ranking from multiple angles** — by monthly cost, by per-token cost, by value (quality ÷ cost)
- **Date stamping** — "May 2026" in title and path, because pricing changes monthly
- **Both locations** — Athenaeum for permanent record, workspace copy for quick access

## Top Findings

| Rank | Provider + Plan | Cost | Why |
|---|---|---|---|
| 🥇 | **GitHub Copilot Pro** | $10/mo | Claude Sonnet 4.6 for $10. Best quality-per-dollar in existence. |
| 🥈 | **DeepSeek V4 (OpenRouter)** | ~$3-8/mo | 90% of Claude quality at 3% of the price. 90% cache discount. |
| 🥉 | **OpenCode Go** | $10/mo | 20K req/5h of MiniMax M2.5. 13× more usage than Claude Max. |
| 4 | **Cerebras Free** | $0 | 1M tokens/day free. 2,600 TPS. No credit card. |
| 5 | **OpenRouter Free** | $0 | 25+ free models (Nemotron 3 Super, Qwen3 Coder 480B). |

## Reproduction Commands

```bash
# Extract baseline list — note: may truncate!
web_extract("https://hermesguide.xyz/coding-plans/")

# If truncated, search for missing sections:
web_search("hermesguide coding plans aggregators plugins 2026")
web_search("site:hermesguide.xyz coding plans")

# Find supplements
web_search("cheapest AI API providers 2026")
web_search("Hermes agent compatible model providers list 2026")
web_search("AI model provider subscription plans list 2026 coding agents cheap")

# Deep extract dimension data by category
web_extract("https://hermes-agent.nousresearch.com/docs/integrations/providers")

# Fill aggregator/plugin gaps
web_search("OpenCode Go pricing plans models 2026")
web_search("Nous Portal pricing credits plan 2026")
web_search("Kilo Pass AI pricing 2026")
web_search("LLM Gateway pricing plans 2026")
web_search("Cerebras AI pricing plans 2026 tokens")
web_search("Crof AI pricing subscription 2026")
web_search("BytePlus Lite pricing plans 2026")

# Rankings
web_search("cheapest AI API providers 2026 ranked lowest price")
web_search("LLM API comparison 2026 pricing speed features")
```

## Upstream Changes to Watch

- hermesguide.xyz/coding-plans/ may add/remove providers or restructure sections
- DeepSeek V4 cache discount (90%) is a major factor — verify current rate
- GitHub Copilot Pro pricing/inclusions change often
- New Chinese providers (GLM, Kimi, MiMo, StepFun) are rapidly iterating plans
- Cerebras free tier (1M tokens/day) may change as the service matures

## Lessons from This Session

1. **Always check for truncation** after web_extract on long comparison pages. A partial result looks complete but isn't.
2. **Split heterogeneous comparisons** — direct providers and aggregators need different dimension sets. One flat table for 27 items is wrong.
3. **When user calls out a missed skill, acknowledge and restart** — don't try to retroactively fit partial work into the skill framework.
4. **Save both to Athenaeum and workspace** — the workspace copy is what you point the user to for quick access.