# Hermes Memory Provider Architectural Synthesis — 2026-05-20
## Worked example: Pattern F (Cross-Provider Architectural Synthesis)

8 providers analyzed → 5 cross-cutting patterns identified → Hydra hybrid architecture designed → Process-vs-LLM analysis → 3 implementation phases.

---

## 1. Per-Provider Analysis (Condensed)

### 1.1 Honcho — Dialectic User Modeling
**Does best:** Models user reasoning patterns over time, not just facts.
**Core mechanisms:** Two-layer context (base + dialectic supplement), multi-pass (Profile→Audit→Reconcile), cost-aware cadence (contextCadence, dialecticCadence, dialecticDepth, empty-streak backoff), peer cards, lazy init, cron guard, observation directionality, session strategy, stale thread detection.
**What to steal:** Dialectic pass system for truth-weighing contradictions, cadence model with backoff, peer cards for per-god user understanding, observation directionality for god session isolation, session strategy for codex boundaries.

### 1.2 OpenViking — Filesystem Hierarchy + Tiered Loading
**Does best:** Organizes memory as progressive-detail filesystem (L0→L1→L2).
**Core mechanisms:** L0 (100t) → L1 (2k) → L2 (full) tiering, 6-category extraction (profile/preferences/entities/events/cases/patterns), viking:// URI scheme, atexit safety net, smart content fallback, background threading.
**What to steal:** L0/L1/L2 progressive retrieval protocol, 6-category taxonomy for compressed knowledge, URI scheme equivalent (athenaeum://).

### 1.3 Mem0 — Server-Side LLM Extraction
**Does best:** Fully automatic extraction — agent never decides what to remember.
**Core mechanisms:** Server-side LLM extraction on every add(), dual memory scope (session vs. user), cross-encoder reranking, deduplication, swappable stack (20 LLM providers, 10 embedders).
**What to steal:** Dual memory scope (already partially in AGENTS.md spec), cross-encoder reranking for ChromaDB, "automatic" extraction philosophy.

### 1.4 Hindsight — Knowledge Graph + Reflect Synthesis
**Does best:** Multi-strategy retrieval with cross-memory reflect.
**Core mechanisms:** Structured facts with entity resolution, 4-retriever strategy (semantic + BM25 + graph + temporal) merged via RRF, reflect tool (cross-memory synthesis), bundled embedder/reranker/PostgreSQL, recall_budget.
**What to steal:** Multi-strategy RRF retrieval (biggest single upgrade), reflect operation → maps to AGENTS.md connections/, recall budget concept.

### 1.5 Holographic — HRR Algebra + Trust Scoring
**Does best:** Zero-dependency, sub-ms algebraic memory with biological self-correction.
**Core mechanisms:** HRR vectors (superposition + algebraic recovery), trust scoring (gain on confirmation, decay on contradiction), SQLite-only, no LLM/no embedder/no network.
**What to steal:** Trust scoring dynamics (pantheon-shared-facts priority scoring is regex-level; this would add proper weight dynamics), importance score concept.

### 1.6 RetainDB — Hybrid Search (Vector + BM25 + Rerank)
**Does best:** Precision through parallel retrieval strategies.
**Core mechanisms:** Vector + BM25 + cross-encoder reranker in parallel → RRF, delta compression.
**What to steal:** Hybrid search pipeline (already partially done in Hindsight), delta compression for decision files.

### 1.7 ByteRover — Agent-Native Context Tree
**Does best:** LLM curates its own memory as typed markdown files. 96.1% LoCoMo (highest).
**Core mechanisms:** Context Tree (Domain→Topic→Subtopic→Entry as .md files), AKL (importance ι∈[0,100] +3 access/+5 update/0.995 daily decay + maturity tiers Draft→Validated→Core with hysteresis), 5-tier progressive retrieval (0: cache 0ms → 4: agentic 15s), OOD detection (θ<0.85→signal out-of-scope), memory ops as LLM reasoning tools, sequential execution layer (write-write conflict prevention).
**What to steal:** 5-tier progressive retrieval (most architecturally relevant), AKL lifecycle for codices, OOD detection, agent-native tool approach.

### 1.8 Supermemory — Multi-Container Partitioning
**Does best:** Memory scoped by container tag — no cross-project bleed.
**Core mechanisms:** Primary + custom container tags, auto-capture per turn, conversation ingest on session end, profile frequency (every N turns), entity context prompt (configurable "what to remember" instruction), metadata type detection.
**What to steal:** Codex-scoped recall, profile frequency concept, entity context prompt.

---

## 2. Five Cross-Cutting Patterns

1. **The Tiered Retrieval Ladder** — OpenViking L0/L1/L2, ByteRover 5-tier, Hindsight 4-parallel RRF → progressive escalation through increasingly expensive strategies.
2. **Cost-Conscious Cadence** — Honcho cadence knobs, Hindsight recall_budget, Supermemory profile_frequency, ByteRover tier budget → not every turn needs full recall.
3. **Structured vs. Raw Memory** — Chunk providers (Mem0, RetainDB, Supermemory) vs. structured providers (Hindsight entities, ByteRover typed markdown, OpenViking 6-category) → structure enables cross-memory synthesis.
4. **The Self-Correction Loop** — Holographic trust scoring, ByteRover AKL, Honcho dialectic resolve, Hindsight reflect → memory should converge toward reliability through weight adjustment, contradiction detection, and periodic synthesis.
5. **Memory Operations as Agent Tools** — ByteRover ADD/UPDATE/MERGE/DELETE, Honcho profile/search/reasoning/conclude, OpenViking search/read/browse/remember/add_resource → agent should have fine-grained memory tools, not just passive sync.

---

## 3. Process vs. LLM Footprint Analysis

This is a critical part of every Pattern F design. The Hydra system targets:

| Component | Engine | Cost | Notes |
|-----------|--------|------|-------|
| T0: Query Cache | Pure process | Free | Hash + Jaccard (already done in pantheon-shared-facts) |
| T1: BM25/FTS5 | Pure process | Free | SQLite built-in |
| T2: ChromaDB Vector | Small model | Tiny | nomic-embed-text ~50MB via Ollama |
| T3: Graph Traversal | Pure process | Free | SQL queries on existing graph.db |
| T4: Reflect/Synthesis | LLM fallback | Rare | Only on SYNTHESIS queries AND if cheaper tiers fail |
| Query Classifier | Pure process | Free | 20-line regex |
| RRF Fusion | Pure process | Free | Math |
| OOD Detection | Pure process | Free | Threshold comparison |
| AKL Scoring | Pure process | Free | Arithmetic + file reads |
| Priority Scoring | Pure process | Free | Already done in pantheon-shared-facts |
| Domain Guessing | Pure process | Free | Already done in pantheon-shared-facts |
| Cross-encoder reranker | Small model | Small | BERT-based ~100-400MB, ONNX |
| Entity extraction | Small model | Small | spaCy NER ~10MB or regex |
| Session-end ingestion | Pure process | Free | Uses priority/domain/dedup from above |

**The 90/10 Rule:**
- 90% of turns: T0 (cache) or T1 (BM25) → Free
- 8% of turns: T2 (ChromaDB) or T3 (graph) → Tiny cost
- 2% of turns: T4 (LLM reflect) → Only on explicit cross-memory queries

---

## 4. Hydra Hybrid Design (High-Level)

```
Query → Classifier → 5-Tier Retrieval (cache→BM25→Chroma→Graph→Reflect) → RRF Fusion → OOD Gate → Context
                      ↑                          ↑                          ↑
                 ByteRover ladder          Hindsight strategies     ByteRover OOD
```

Components by provider inspiration:
- **ByteRover** → 5-tier progressive retrieval, AKL lifecycle, OOD detection
- **Hindsight** → Multi-strategy RRF, reflect synthesis, entity resolution
- **OpenViking** → L0/L1/L2 content tiers, 6-category extraction taxonomy
- **Honcho** → Dialectic pass structure for reflect, cadence model with backoff, peer cards, observation directionality
- **Holographic** → Trust score dynamics for AKL
- **Supermemory** → Codex-scoped recall, profile frequency
- **Mem0** → Reranking, dual memory scope
- **RetainDB** → Delta compression for decision files

---

## 5. 3-Phase Implementation Plan

**Phase 0 — Quick Audit (hours):** Verify ChromaDB client compatibility, embedding model, graph.db schema.

**Phase 1 — Quick Wins (~1 week):** BM25 index over codices, query cache (hash + Jaccard), AKL metadata on decision files, cross-encoder reranker.

**Phase 2 — New Functions (~2 weeks):** Query classifier, RRF fusion, OOD detection, reflect tool, codex-scoped recall.

**Phase 3 — Integration (~1 week):** Wire tiered retrieval into Hermes prefetch(), wire AKL into compilation pipeline, wire reflect into Hades nightly, session-end LLM extraction.

---

For the full 20,000-word report with complete per-provider analyses, pattern map with cross-cutting analysis, architecture diagram with query classifier and tiered retrieval engine, AKL spec with event-driven scoring and hysteresis, and detailed migration checklist, see:
`~/athenaeum/Codex-God-thoth/research/hermes-memory-provider-architecture/report.md`