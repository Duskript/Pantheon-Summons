# Daily Research Digest Cron — Setup Reference

> Pipeline: Blogwatcher RSS feeds → Python script → Hermes cron job → WebUI notification
> First deployed: 2026-05-19 for Thoth profile

## Architecture

```
blogwatcher-cli scan        Collects new articles from all feeds
         ↓
thoth-daily-digest.py       Formats output with === SECTION_NAME === markers
         ↓
Hermes cron job             Injects script output as context, runs LLM prompt
         ↓
god-notify                  Pushes digest summary via WebUI notification
         ↓
blogwatcher-cli read-all    Marks all as read for next cycle
```

## The Python Script

Location: `~/.hermes/scripts/thoth-daily-digest.py`

```python
#!/usr/bin/env python3
import subprocess, os
from datetime import datetime

BLOGWATCHER = os.path.expanduser("~/.local/bin/blogwatcher-cli")

def run_bw(args, timeout=15):
    try:
        result = subprocess.run([BLOGWATCHER] + args,
            capture_output=True, text=True, timeout=timeout)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return "[TIMEOUT]"
    except FileNotFoundError:
        return "[ERROR] blogwatcher-cli not found"

def main():
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    print(f"=== FEED_STATUS ===")
    print(f"Generated: {today}")
    blogs = run_bw(["blogs"])
    print(blogs if blogs else "No feeds configured.")
    
    print(f"\n=== UNREAD_ARTICLES ===")
    articles = run_bw(["articles"], timeout=10)
    if articles and articles not in ("No unread articles.", ""):
        lines = articles.split("\n")
        print(f"Total unread: ~{len([l for l in lines if l.strip().startswith('[')])}")
        print("\nRecent articles:")
        shown = 0
        for line in lines:
            if shown >= 15:
                break
            print(line)
            if line.strip().startswith("[") and "]" in line:
                shown += 1
    else:
        print("No new unread articles.")

if __name__ == "__main__":
    main()
```

**Key design:**
- Fast path — reads blogwatcher SQLite DB, no network calls for unread listing
- Outputs `=== SECTION_NAME ===` markers for the cron prompt to reference
- Truncates to 15 articles to keep cron context manageable
- Won't block on missing binary — returns error messages instead of crashing

## The Cron Job

Created via `cronjob(toolkit)` in a Hermes session:

```python
cronjob(action="create",
    name="Thoth Daily Feed Digest",
    schedule="0 7 * * *",           # Every day at 7AM
    script="thoth-daily-digest.py", # Must live in ~/.hermes/scripts/
    deliver="local",
    enabled_toolsets=["web","terminal"],
    prompt="You are Thoth... compose a digest from the data below..."
)
```

**Key cron prompt instructions:**
1. Scan UNREAD_ARTICLES for the most interesting finds, prioritizing: AI agents, LLM research, software engineering, security, quantitative analysis
2. Compose a scannable digest with: headline stats → TOP 3-5 finds with précis → connections to existing wiki knowledge
3. Call `god-notify thoth info "Daily Feed Digest" "<summary>"` for the push notification
4. Run `blogwatcher-cli read-all --yes` to mark all read so tomorrow is fresh

## First-Run Considerations

On first scan after setup, there will be a **large backlog** (hundreds or thousands of articles from all feeds). This is normal — the cron handles it by showing the 15 most recent. Over subsequent days, the backlog clears as `read-all` marks everything read.

## Feed Recommendations

| Feed | URL | Notes |
|------|-----|-------|
| arXiv cs.AI | `https://rss.arxiv.org/rss/cs.AI` | Artificial Intelligence |
| arXiv cs.CL | `https://rss.arxiv.org/rss/cs.CL` | Computation & Language (NLP) |
| arXiv cs.LG | `https://rss.arxiv.org/rss/cs.LG` | Machine Learning |
| arXiv cs.CR | `https://rss.arxiv.org/rss/cs.CR` | Cryptography & Security |
| arXiv cs.SE | `https://rss.arxiv.org/rss/cs.SE` | Software Engineering |
| Hacker News | `https://hnrss.org/frontpage` | Tech news (feed format may need debugging) |

## Troubleshooting

**Feed not showing articles:** Some feeds need explicit `--feed-url` flag (blogwatcher auto-discovery doesn't always work). Check: `blogwatcher-cli scan "Feed Name"`.

**Script timeout:** The `blogwatcher-cli scan` command can take 30+ seconds on first run with many feeds. The digest script ONLY reads the DB (fast) and doesn't trigger a scan — that's the cron's job.

**Binary not found:** Under a Hermes profile, `~` may resolve to the profile home, not the user home. Use the absolute path or install to a location in the system PATH.