# Lightweight Research Extraction

> API-based extraction patterns for research when Firecrawl is unavailable.
> All commands use `curl` against free REST APIs — no API keys needed for basic use.

## arXiv Papers

### Search papers
```bash
# Search all fields for query, 5 results, newest first
curl -s "https://export.arxiv.org/api/query?search_query=all:YOUR+TOPIC&max_results=5&sortBy=submittedDate&sortOrder=descending"

# Search by category
curl -s "https://export.arxiv.org/api/query?search_query=cat:cs.AI+AND+all:reinforcement+learning&max_results=10"

# Parse XML to clean output
curl -s "https://export.arxiv.org/api/query?search_query=all:YOUR+TOPIC&max_results=5&sortBy=submittedDate&sortOrder=descending" | python3 -c "
import sys, xml.etree.ElementTree as ET
ns = {'a': 'http://www.w3.org/2005/Atom'}
root = ET.parse(sys.stdin).getroot()
for entry in root.findall('a:entry', ns):
    title = entry.find('a:title', ns).text.strip().replace('\\n', ' ')
    arxiv_id = entry.find('a:id', ns).text.strip().split('/abs/')[-1]
    published = entry.find('a:published', ns).text[:10]
    authors = ', '.join(a.find('a:name', ns).text for a in entry.findall('a:author', ns))
    print(f'[{arxiv_id}] {title} | {published} | {authors}')
"
```

### Read paper
```bash
# Abstract (fast, metadata)
web_extract(urls=["https://arxiv.org/abs/2402.03300"])

# Full PDF (via web_extract)
web_extract(urls=["https://arxiv.org/pdf/2402.03300"])
```

### Rate limit: ~1 req / 3 seconds

---

## Semantic Scholar (Citations + Related Work)

### Paper details
```bash
curl -s "https://api.semanticscholar.org/graph/v1/paper/arXiv:2402.03300?fields=title,authors,citationCount,influentialCitationCount,year,abstract" | python3 -m json.tool
```

### Who cited this paper
```bash
curl -s "https://api.semanticscholar.org/graph/v1/paper/arXiv:2402.03300/citations?fields=title,authors,year,citationCount&limit=10" | python3 -m json.tool
```

### What this paper references
```bash
curl -s "https://api.semanticscholar.org/graph/v1/paper/arXiv:2402.03300/references?fields=title,authors,year,citationCount&limit=20" | python3 -m json.tool
```

### Search
```bash
curl -s "https://api.semanticscholar.org/graph/v1/paper/search?query=GRPO+reinforcement+learning&limit=5&fields=title,authors,year,citationCount,externalIds" | python3 -m json.tool
```

### Paper recommendations
```bash
curl -s -X POST "https://api.semanticscholar.org/recommendations/v1/papers/" \
  -H "Content-Type: application/json" \
  -d '{"positivePaperIds": ["arXiv:2402.03300"], "negativePaperIds": []}' | python3 -m json.tool
```

### Author profile
```bash
curl -s "https://api.semanticscholar.org/graph/v1/author/search?query=Yann+LeCun&fields=name,hIndex,citationCount,paperCount" | python3 -m json.tool
```

### Rate limit: 1 req/sec without key, 100/sec with API key

---

## Blogwatcher (RSS/Feed Monitoring)

### Add feeds
```bash
blogwatcher-cli add "Feed Name" https://example.com/feed.xml
# With auto-discovery fallback:
blogwatcher-cli add "Blog Name" https://example.com
```

### Scan all feeds for new articles
```bash
blogwatcher-cli scan
```

### List unread articles
```bash
blogwatcher-cli articles
blogwatcher-cli articles --blog "arXiv cs.AI"   # filter by feed
blogwatcher-cli articles --all                    # all articles, not just unread
```

### Thoth's current tracked feeds (as of 2026-05-19):
- arXiv cs.AI → `https://rss.arxiv.org/rss/cs.AI`
- arXiv cs.CL → `https://rss.arxiv.org/rss/cs.CL`
- arXiv cs.LG → `https://rss.arxiv.org/rss/cs.LG`
- Hacker News Front Page → `https://hnrss.org/frontpage`
- Lilian Weng's Blog → `https://lilianweng.github.io/feed.xml`

### Binary location: `~/.local/bin/blogwatcher-cli` (path may resolve differently under profile — call with absolute path if needed)
### Database: `~/.blogwatcher-cli/blogwatcher-cli.db`

---

## GitHub (Code search, READMEs, Issues)

### Search repos
```bash
curl -s "https://api.github.com/search/repositories?q=YOUR+TOPIC+in:name,description&sort=stars&order=desc&per_page=10" | python3 -m json.tool
```

### Get repo README
```bash
curl -s "https://api.github.com/repos/owner/repo/readme" -H "Accept: application/vnd.github.raw+json" | python3 -m json.tool
# Or raw markdown:
curl -s "https://raw.githubusercontent.com/owner/repo/main/README.md"
```

### Rate limit: 60 req/hr unauthenticated, 5000/hr with token

---

## web_extract (Standard Pages)

For any page not covered by a dedicated API:
```python
web_extract(urls=["https://example.com/page"])
```

**Watch for truncation** — `web_extract` has a content limit. On long pages (comparison tables, documentation, article lists):
- Check for mid-sentence cutoffs, "..." truncation markers, or missing table rows
- Follow up with targeted `web_search` for the missing data
- Split extraction: hit the same page with different section anchors if possible

---

## Complete Research Workflow (No Firecrawl)

```
1. Discover → web_search() for broad queries, blogwatcher scan for feed updates
2. Deep-dive → curl for arxiv/Semantic Scholar/GitHub APIs
3. Read → web_extract() for pages and PDFs
4. Verify → multi-source cross-reference (3+ sources minimum)
5. Synthesize → structured report with citations
6. Store → wiki ingest for durable knowledge
```

This stack covers academic papers, blog posts, documentation, news, code repos, and books. No Firecrawl, no Playwright, no browser automation needed.