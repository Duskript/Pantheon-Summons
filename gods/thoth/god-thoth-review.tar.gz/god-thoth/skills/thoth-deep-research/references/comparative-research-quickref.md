# Comparative Research — Quick Reference

Use when comparing N items across the same dimensions (pricing, features, specs, usage).
**Do NOT use delegate_task** — do sequential extraction for dimension consistency.

## Workflow at a Glance

```
Source page → extract baseline list
    ↓
Search for supplements (3-5 more sources)
    ↓
Define comparison dimensions (cost / usage / models / quality)
    ↓
Iteratively extract data for each item × dimension
    ↓
Rank by user's criterion (cheapest, best quality, best value)
    ↓
Organize into tiers (Free → Budget → Premium)
    ↓
Write: Quick Decision Guide → Tier-by-Tier Breakdown → Side-by-Side Summary → Caveats
    ↓
Save + Notify
```

## Dimension Extraction Template

For each item, capture:

```yaml
item: "Provider Name"
cost:
  monthly_plan: "$X/mo"
  pay_per_token: "$X/$Y per 1M tokens"
  free_tier: "Yes/No — limits"
usage:
  rate_limit: "X req per 5h" or "X requests/day"
  concurrent_agents: "1-2 agents"
  total_volume: "X prompts/month"
models:
  available: ["Model A", "Model B"]
  context_window: "X tokens"
  tool_calling: "Excellent/Good/Moderate"
quality:
  benchmark_score: "X% on SWE-bench"
  best_for: "Description of what it excels at"
verdict: "🔥 One-liner recommendation"
pros: ["Pro 1", "Pro 2"]
cons: ["Con 1", "Con 2"]
```

## Report Structure Template

```markdown
# 🏆 Topic — Comprehensive Comparison

## Quick Decision Guide
| Your Situation | Best Pick | Effective Cost |
|---|---|---|

## TIER 1: Free ($0)
### Item Name
| Detail | Value |
|---|---|
| **Cost** | |
| **Usage** | |
| **Models** | |
| **🔥 Verdict** | |

## Side-by-Side Summary
| Rank | Item | Cost | Usage | Models | Verdict |
|---|---|---|---|---|---|

## Dimension-Specific Rankings
### By Cost (Cheapest → Most Expensive)
### By Quality (Best → Worst)
### By Best Value (Sweet Spot)

## ⚠️ Critical Caveats
- Hidden costs, tradeoffs, dependencies
```

## Common Pitfalls

- **Single source:** Comparison pages miss items. Always search for 3-5 supplementary sources.
- **Wrong rank criterion:** Cheap = low subscription OR low per-token OR free tier? When ambiguous, rank multiple ways and note the user's likely intent.
- **Stale pricing:** Date-stamp everything. Pricing changes monthly.
- **delegate_task trap:** Don't parallelize comparison research. Sub-agents won't extract dimensions consistently.
- **Missing caveats:** Always note quality/cost tradeoffs (cheaper model may need more retries → effective cost higher).