# DNS-Based Domain Availability Checking

When `whois` is unavailable (common), use `host` and `dig` as proxies for domain availability checking.

## Tool Availability

```bash
which whois dig host nslookup
# → /usr/bin/dig /usr/bin/nslookup /usr/bin/host  (whois absent)
```

## Primary Check: `host`

```bash
host example.com 2>&1 | head -2
```

| Output Pattern | Meaning |
|---------------|---------|
| `NXDOMAIN` / `not found` | **Likely available** — domain has no DNS records |
| `has address` / `has IPv6 address` / `mail is handled` | **Registered** — domain has active DNS |
| `is an alias` | **Registered** — domain is a CNAME |
| `SERVFAIL` | **Uncertain** — DNS server error, retry |
| Empty output (no text at all) | **Uncertain** — some registered .com domains return nothing from `host`. Re-check with `dig` |

## Fallback: `dig`

For domains where `host` returned empty:

```bash
dig example.com ANY +short 2>&1 | head -3
```

| Output Pattern | Meaning |
|---------------|---------|
| Empty (no output) | **Likely available** — no DNS records at all |
| Any record (A, NS, MX, etc.) | **Registered** — domain has DNS |
| `NXDOMAIN` | **Available** |

## Batch Processing Pattern

```python
from hermes_tools import terminal

for domain in candidates:
    result = terminal(f"host {domain} 2>&1 | head -2")
    output = result.get('output', '')
    if 'NXDOMAIN' in output or 'not found' in output.lower():
        print(f"🟡 AVAIL: {domain}")
    elif 'has address' in output or 'has IPv6' in output or 'mail is handled' in output or 'is an alias' in output:
        pass  # registered
    elif not output.strip():
        # Re-check with dig
        dig_result = terminal(f"dig {domain} ANY +short 2>&1 | head -3")
        if not dig_result.get('output', '').strip():
            print(f"🟡 NO DNS (likely avail): {domain}")
        else:
            print(f"🔴 REGISTERED (dig found DNS): {domain}")
```

## Limitations

- **Not 100% accurate** — A domain can be registered but have no DNS configured (parked/undeveloped). DNS checking is a strong heuristic, not a guarantee.
- **No registrar info** — Unlike whois, you can't see registration dates, expiry, or owner details.
- **No TLD-specific logic** — Works best for .com. Some TLDs have different DNS behavior.
- **Rate limit yourself** — Batch checking 30+ domains rapidly is fine for `host` but don't hammer DNS servers with thousands of queries.

## When to Use vs whois

| Situation | Best Tool |
|-----------|-----------|
| Quick batch availability check | `host` / `dig` |
| Need registration expiry date | `whois` (install if needed) |
| Need registrant contact info | `whois` |
| Legal/trademark due diligence | Paid domain checking service |