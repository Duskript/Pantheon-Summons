# Deep Research Quick Reference

## Data Structures

### outline.yaml

```yaml
topic: "AI Agents Market Overview"
created: "2026-05-16"
items:
  - name: "Claude Code"
    category: "AI Coding Agent"
    description: "Anthropic's terminal-native AI coding agent with ACP"
  - name: "OpenAI Operator"
    category: "Browser Agent"
    description: "OpenAI's browser automation agent"
  - name: "Cursor"
    category: "AI IDE"
    description: "AI-first IDE with deep codebase understanding"
batch_size: 3
output_dir: "results"
```

### fields.yaml

```yaml
categories:
  - name: "Basic Info"
    fields:
      - name: "Company"
        description: "Company that developed the product"
        detail_level: "brief"
      - name: "Release Date"
        description: "Initial public release date"
        detail_level: "brief"
      - name: "Website"
        description: "Official product URL"
        detail_level: "brief"
  - name: "Technical Features"
    fields:
      - name: "Underlying Model"
        description: "Base LLM model powering the product"
        detail_level: "moderate"
      - name: "Architecture"
        description: "Technical architecture overview"
        detail_level: "detailed"
      - name: "Context Window"
        description: "Maximum context size supported"
        detail_level: "moderate"
  - name: "Pricing"
    fields:
      - name: "Free Tier"
        description: "Free usage limits"
        detail_level: "brief"
      - name: "Paid Plans"
        description: "Pricing tiers and what they include"
        detail_level: "moderate"
  - name: "Performance"
    fields:
      - name: "SWE-bench Score"
        description: "Performance on SWE-bench verified"
        detail_level: "moderate"
      - name: "Key Differentiators"
        description: "What sets it apart from competitors"
        detail_level: "detailed"
```

### Result JSON (per item)

```json
{
  "name": "Claude Code",
  "Company": "Anthropic",
  "Release Date": "2025-07-12",
  "Website": "https://claude.ai/code",
  "Underlying Model": "Claude 4 Sonnet / Claude 4 Opus",
  "Architecture": "Terminal-native agent using the ACP protocol. ...",
  "Context Window": "200K tokens",
  "Free Tier": "Limited free tier via Claude.ai",
  "Paid Plans": "Pro $20/mo, Max $100-200/mo",
  "SWE-bench Score": "72.3% (verified)",
  "Key Differentiators": "Terminal-native, ACP protocol, deep codebase editing",
  "uncertain": []
}
```

## Quick Commands

### Generate outline
```
web_search topic recent developments, verify items list, 
save to ~/athenaeum/Codex-God-thoth/research/{slug}/outline.yaml
```

### Launch deep research batch
```
delegate_task with each batch of items, 
goal: "Research items and output JSON to results/ directory"
```

### Check results
```
# in results/ dir
ls *.json
# Check for uncertain values
grep -l "uncertain" *.json | head
```

### Generate report
```
execute_code with the Python report generator template
```

## category-detail_level Mapping

| detail_level | Expected Output |
|---|---|
| brief | Single value, one line |
| moderate | Paragraph (2-4 sentences) |
| detailed | Multi-paragraph with sources |

## Uncertain Value Handling

- `[uncertain]` in a field value → skip in report
- Field name in the `uncertain` array → skip in report
- Empty string or None → skip in report
- If an item has >50% fields uncertain, flag for retry

## Output Path Convention

```
~/athenaeum/Codex-God-thoth/research/{topic-slug}-{YYYYMMDD}/
```